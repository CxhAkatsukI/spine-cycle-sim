import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd

# --- 配置常量 ---
# CSV 文件路径
CSV_FILE = 'data_shuffle_data.csv'  # CSV文件名

# 系列样式 - 使用不同灰度
SERIES_STYLES = [
    {'hatch': '///', 'hatch_color': '#ff7f0e'},   # 深灰 - SwiftGraph w/ Data Shuffling
    {'hatch': '\\\\\\', 'hatch_color': '#1f77b4'}  # 中灰 - SwiftGraph w/o Data Shuffling
]

BAR_FACECOLOR = 'white'
BAR_EDGECOLOR = 'black'

# --- 图形和坐标轴样式 ---
FIG_SIZE = (12, 5)
Y_LABEL = 'GTEPS'  # 修改为 GTEPS
Y_LIMITS = (0, 13)  # 相应调整范围 (除以1000)
Y_TICKS = [0, 2, 4, 6, 8, 10, 12]
X_AXIS_MARGIN = 0.01

# --- 字体配置 ---
FONT_FAMILY = ['Arial', 'DejaVu Sans', 'sans-serif']
FONT_SIZE_GENERAL = 15
FONT_SIZE_LABEL = 18
FONT_SIZE_TICK = 15
FONT_SIZE_LEGEND = 17
X_TICK_ROTATION = 0

# --- 条形图样式 ---
BAR_WIDTH = 0.1  # 更窄的条形
INTRA_GROUP_GAP = 0.0
BAR_EDGE_WIDTH = 1.5
INTER_GROUP_SPACING = 0.4

# --- OoM 标记样式 ---
OOM_TAG_TEXT = 'OoM'
OOM_TAG_FONTSIZE = 13
OOM_TAG_COLOR = 'black'  # 改为黑色
OOM_TAG_WEIGHT = 'normal'
OOM_TAG_Y_POSITION = 0.2  # Y轴位置 (调整为GTEPS单位)
OOM_TAG_ROTATION = 90  # 垂直显示

# --- 可选的水平线 ---
HORIZONTAL_LINE_Y = None
HORIZONTAL_LINE_COLOR = 'black'
HORIZONTAL_LINE_STYLE = '--'
HORIZONTAL_LINE_WIDTH = 1.2

# --- 网格样式 ---
AXES_LINEWIDTH = 1.5
GRID_AXIS = 'y'
GRID_MAJOR_ENABLED = True
GRID_MAJOR_STYLE = '--'
GRID_MAJOR_COLOR = 'grey'
GRID_MAJOR_ALPHA = 0.5

# --- 刻度样式 ---
TICK_DIRECTION = 'in'
TICK_LENGTH_MAJOR = 5
TICK_LENGTH_MINOR = 2
TICK_ON_TOP = True
TICK_ON_RIGHT = True
TICK_LABELS_ON_TOP = False
TICK_LABELS_ON_RIGHT = False

# --- 图例样式 ---
LEGEND_NCOL = 2
LEGEND_LOCATION = 'upper center'
LEGEND_BBOX_TO_ANCHOR = (0.5, 1.15)
LEGEND_FRAME_ON = False
LEGEND_HANDLETEXTPAD = 0.2
LEGEND_COLUMNSPACING = 0.8
LEGEND_HANDLE_LENGTH = 1.8
LENGEND_EDGE_WIDTH = 2

# --- 布局调整 ---
TIGHT_LAYOUT_RECT = [0, 0, 1, 0.95]
SAVE_FILENAME = 'data_shuffle_compare.pdf'

# --- Speedup配置 ---
SPEEDUP_NUMERATOR = 'SwiftGraph w/ Data Shuffling'
SPEEDUP_DENOMINATOR = 'SwiftGraph w/o Data Shuffling'

# --- 读取CSV数据 ---
def read_data_from_csv(csv_file):
    """从CSV文件读取数据
    
    CSV格式应为:
    dataset,SwiftGraph w/ Data Shuffling,SwiftGraph w/o Data Shuffling,simple_name
    graph500-scale23-ef16_adj,12217,1406.7,G23
    ...
    
    Returns:
        tuple: (simple_names, series_data)
            - simple_names: 简化的数据集名称列表
            - series_data: [(系列名, 值列表, 错误标记列表), ...]
    """
    df = pd.read_csv(csv_file)
    
    # 获取简化名称
    simple_names = df.iloc[:, -1].tolist()  # 最后一列是简化名称
    
    # 获取系列名称 (除了第一列dataset和最后一列simple_name)
    series_names = df.columns[1:-1].tolist()
    
    # 准备系列数据
    series_data = []
    for series_name in series_names:
        values = []
        errors = []
        
        for val in df[series_name]:
            if pd.isna(val) or str(val).lower() == 'error':
                values.append(None)
                errors.append('error')
            else:
                try:
                    # 转换为GTEPS (除以1000)
                    values.append(float(val) / 1000.0)
                    errors.append(None)
                except:
                    values.append(None)
                    errors.append('error')
        
        series_data.append((series_name, values, errors))
    
    return simple_names, series_data

# --- 主绘图函数 ---
def compute_speedups(simple_names, series_data):
    """计算 SwiftGraph w/ Data Shuffling 相对 w/o 的加速比。"""
    series_map = {name: values for name, values, _ in series_data}
    numerator = series_map.get(SPEEDUP_NUMERATOR)
    denominator = series_map.get(SPEEDUP_DENOMINATOR)

    if numerator is None or denominator is None:
        print("警告: 缺少计算加速比所需的数据列。")
        return []

    def ratio(num, den):
        if num is None or den in (None, 0):
            return None
        return num / den

    rows = []
    for idx, dataset in enumerate(simple_names):
        num_val = numerator[idx] if idx < len(numerator) else None
        den_val = denominator[idx] if idx < len(denominator) else None
        rows.append({
            'dataset': dataset,
            'ratio': ratio(num_val, den_val)
        })
    return rows


def create_bar_chart():
    """根据配置生成分组条形图，保存为矢量PDF并显示。"""

    # 1. 读取数据
    try:
        simple_names, series_data = read_data_from_csv(CSV_FILE)
    except FileNotFoundError:
        print(f"错误: 找不到文件 '{CSV_FILE}'")
        print("请确保CSV文件存在，格式如下:")
        print("dataset,Optimized SwiftGraph,Naive SwiftGraph,Regraph,simple_name")
        print("amazon-2008,1900.43,706.037,1267.37,Amazon")
        return
    except Exception as e:
        print(f"读取CSV文件时出错: {e}")
        return

    # 输出加速比信息
    speedup_rows = compute_speedups(simple_names, series_data)
    if speedup_rows:
        print(f"Speedup ({SPEEDUP_NUMERATOR} / {SPEEDUP_DENOMINATOR}):")
        total = 0
        count = 0
        for row in speedup_rows:
            ratio_txt = f"x{row['ratio']:.2f}" if row['ratio'] is not None else 'N/A'
            print(f"  {row['dataset']}: {ratio_txt}")
            if row['ratio'] is not None:
                total += row['ratio']
                count += 1
        if count > 0:
            avg = total / count
            print(f"Average Speedup: x{avg:.2f}")

    # 2. 应用全局样式设置
    plt.style.use('default')
    plt.rcParams.update({
        'font.size': FONT_SIZE_GENERAL,
        'axes.labelsize': FONT_SIZE_LABEL,
        'xtick.labelsize': FONT_SIZE_TICK,
        'ytick.labelsize': FONT_SIZE_TICK,
        'legend.fontsize': FONT_SIZE_LEGEND,
        'font.family': 'sans-serif',
        'font.sans-serif': FONT_FAMILY,
        'hatch.linewidth': 1,
        'axes.linewidth': AXES_LINEWIDTH
    })

    # 3. 准备数据和位置
    n_categories = len(simple_names)
    n_series = len(series_data)

    # 计算X轴各组中心位置
    x_pos = [i * INTER_GROUP_SPACING for i in range(n_categories)]

    # 计算每个系列条形的起始偏移量
    total_group_width = n_series * BAR_WIDTH
    start_offset = -total_group_width / 2 + BAR_WIDTH / 2

    # 4. 创建图形和坐标轴
    fig, ax = plt.subplots(figsize=FIG_SIZE)

    # 5. 绘制条形图
    legend_handles = []

    for i, (series_name, values, errors) in enumerate(series_data):
        style = SERIES_STYLES[i % len(SERIES_STYLES)]
        bar_positions = [pos + start_offset + i * BAR_WIDTH for pos in x_pos]

        # 处理数据：将None替换为0用于绘图
        plot_values = [v if v is not None else 0 for v in values]

        # --- 绘制过程 1: 白色背景，无边框 (底层) ---
        base_bars = ax.bar(bar_positions, plot_values, BAR_WIDTH,
                           facecolor=BAR_FACECOLOR,
                           edgecolor='none',
                           linewidth=0,
                           zorder=1)

        # --- 绘制过程 2: 透明背景，灰色填充图案 (中层) ---
        hatch_bars = ax.bar(bar_positions, plot_values, BAR_WIDTH,
                            facecolor='none',
                            edgecolor=style['hatch_color'],
                            linewidth=0,
                            hatch=style['hatch'],
                            zorder=2)

        # --- 绘制过程 3: 透明背景，黑色边框 (顶层) ---
        edge_bars = ax.bar(bar_positions, plot_values, BAR_WIDTH,
                           facecolor='none',
                           edgecolor=BAR_EDGECOLOR,
                           linewidth=BAR_EDGE_WIDTH,
                           hatch=None,
                           zorder=3)

        # --- 创建图例句柄 ---
        patch = mpatches.Patch(facecolor=BAR_FACECOLOR,
                               edgecolor=style['hatch_color'],
                               hatch=style['hatch'],
                               label=series_name,
                               linewidth=LENGEND_EDGE_WIDTH)
        legend_handles.append(patch)

        # --- 添加OoM标记 (不添加数值注释) ---
        for j, (bar, val, err) in enumerate(zip(base_bars, values, errors)):
            if err == 'error':
                # 绘制垂直的 OoM 标记
                ax.text(bar.get_x() + bar.get_width() / 2., OOM_TAG_Y_POSITION,
                        OOM_TAG_TEXT,
                        ha='center', va='bottom',
                        fontsize=OOM_TAG_FONTSIZE,
                        color=OOM_TAG_COLOR,
                        weight=OOM_TAG_WEIGHT,
                        rotation=OOM_TAG_ROTATION,  # 垂直显示
                        zorder=4)

    # 6. 配置坐标轴外观
    ax.set_ylabel(Y_LABEL)
    ax.set_ylim(Y_LIMITS)
    ax.set_yticks(Y_TICKS)

    # 配置X轴刻度和标签 - 使用简化名称
    ax.set_xticks(x_pos)
    ax.set_xticklabels(simple_names, rotation=X_TICK_ROTATION, ha='center')
    ax.tick_params(axis='x', which='major', length=0)

    # 调整X轴边距
    ax.margins(x=X_AXIS_MARGIN)

    # 确保所有坐标轴边框线可见
    for spine in ax.spines.values():
        spine.set_visible(True)

    # 7. 添加可选的水平参考线
    if HORIZONTAL_LINE_Y is not None:
        ax.axhline(HORIZONTAL_LINE_Y,
                   color=HORIZONTAL_LINE_COLOR,
                   linestyle=HORIZONTAL_LINE_STYLE,
                   linewidth=HORIZONTAL_LINE_WIDTH,
                   zorder=0)

    # 8. 配置刻度线外观
    ax.tick_params(axis='x', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                    top=TICK_ON_TOP, bottom=False,
                    labeltop=TICK_LABELS_ON_TOP, labelbottom=True)
    ax.tick_params(axis='y', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                    right=TICK_ON_RIGHT, left=True,
                    labelright=TICK_LABELS_ON_RIGHT, labelleft=True)

    ax.minorticks_off()

    # 9. 配置网格线
    ax.grid(False, axis='both', which='both')
    ax.set_axisbelow(True)
    if GRID_MAJOR_ENABLED:
        ax.grid(True, axis=GRID_AXIS, which='major',
                linestyle=GRID_MAJOR_STYLE,
                color=GRID_MAJOR_COLOR,
                alpha=GRID_MAJOR_ALPHA,
                zorder=0)

    # 10. 创建图例
    ax.legend(handles=legend_handles,
              loc=LEGEND_LOCATION,
              bbox_to_anchor=LEGEND_BBOX_TO_ANCHOR,
              ncol=LEGEND_NCOL,
              frameon=LEGEND_FRAME_ON,
              handletextpad=LEGEND_HANDLETEXTPAD,
              columnspacing=LEGEND_COLUMNSPACING,
              handlelength=LEGEND_HANDLE_LENGTH)

    # 11. 最终布局调整
    fig.tight_layout(rect=TIGHT_LAYOUT_RECT)

    # 12. 保存和显示图形
    plt.savefig(SAVE_FILENAME, format='pdf', bbox_inches='tight')
    print(f"图形已保存为矢量PDF: {SAVE_FILENAME}")
    plt.show()

# --- 执行入口 ---
if __name__ == "__main__":
    create_bar_chart()
