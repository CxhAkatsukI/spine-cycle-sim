import matplotlib.pyplot as plt
import pandas as pd
import os
import numpy as np
from typing import List, Dict, Tuple
import matplotlib.font_manager as fm
import matplotlib.patches as mpatches

# 字体配置
FONT_FAMILY = ['Arial', 'DejaVu Sans', 'sans-serif']
FONT_SIZE_GENERAL = 12
FONT_SIZE_LABEL = 16
FONT_SIZE_TICK = 16
FONT_SIZE_LEGEND = 14
FONT_SIZE_ANNOTATION = 10
X_TICK_ROTATION = 25

# 条形图样式
BAR_FACECOLOR = 'white'
BAR_EDGECOLOR = 'black'
BAR_WIDTH = 0.15  # 更窄的条形，因为有更多的条形
INTRA_GROUP_GAP = 0.0  # 组内间隙
BAR_EDGE_WIDTH = 1.5
BAR_ANNOTATION_OFFSET = 50
INTER_GROUP_SPACING = 1.2  # 组间距

# 网格样式
AXES_LINEWIDTH = 2
GRID_AXIS = 'y'  # 只显示Y轴网格
GRID_MAJOR_ENABLED = True
GRID_MAJOR_STYLE = '--'
GRID_MAJOR_COLOR = 'grey'
GRID_MAJOR_ALPHA = 0.7

# 刻度样式
TICK_DIRECTION = 'in'
TICK_LENGTH_MAJOR = 5
TICK_ON_TOP = True
TICK_ON_RIGHT = True
TICK_LABELS_ON_TOP = False
TICK_LABELS_ON_RIGHT = False

# 图例样式
LEGEND_FRAME_ON = False
LEGEND_HANDLETEXTPAD = 0.2
LEGEND_COLUMNSPACING = 0.8
LEGEND_HANDLE_LENGTH = 1.8
LEGEND_EDGE_WIDTH = 2
LEGEND_LOCATION = 'upper center'  # 改为上方居中
LEGEND_BBOX_TO_ANCHOR = (0.5, 1.15)  # 设置图例位置在图表上方
LEGEND_NCOL = 2  # 设置图例为2列，因为有6个图例项（3引擎×2指标）

# X轴边距
X_AXIS_MARGIN = 0.01

# 颜色配置
COLORS = {
    "SunCake": "#ff7f0e",  # 橙色
    "vLLM": "#1f77b4",     # 蓝色
    "Parrot": "#2ca02c"    # 绿色
}

# 填充图案配置
HATCHES = {
    "SunCake": "xxx",
    "vLLM": "///",
    "Parrot": "\\\\\\"
}

# 标签映射
LABEL_DICT = {
    "SunCake": "SunCake",
    "vLLM": "vLLM",
}

# 模型标签映射
MODEL_DICT = {
    "Qwen2.5-14B": "Qwen2.5-14B",
    "Qwen2.5-32B": "Qwen2.5-32B"
}

# 指标标签映射
METRIC_DICT = {
    "prompt_throughput": "Prompt Throughput",
    "generation_throughput": "Generation Throughput"
}

ENGINE_ORDER = ['SunCake', 'vLLM', 'Parrot']

# 应用全局样式设置
plt.style.use('default')
plt.rcParams.update({
    'font.size': FONT_SIZE_GENERAL,
    'axes.labelsize': FONT_SIZE_LABEL,
    'xtick.labelsize': FONT_SIZE_TICK,
    'ytick.labelsize': FONT_SIZE_TICK,
    'legend.fontsize': FONT_SIZE_LEGEND,
    'font.family': 'sans-serif',
    'font.sans-serif': FONT_FAMILY,
    'hatch.linewidth': 1,  # 填充图案线条宽度
    'axes.linewidth': AXES_LINEWIDTH,
    'axes.unicode_minus': False
})


def load_metrics_data(file_path: str) -> pd.DataFrame:
    """加载metrics CSV数据"""
    return pd.read_csv(file_path)


def create_simple_throughput_chart(df: pd.DataFrame, output_path: str, model_filter=None, dataset_filter=None, task_filter=None):
    """创建简化版的吞吐量对比图（单个图表）"""
    fig_size = (12, 8)

    # 构建输出文件名
    filename_parts = ["throughput_simple_comparison"]
    if task_filter:
        filename_parts.append(task_filter)
    if model_filter:
        filename_parts.append(model_filter)
    if dataset_filter:
        filename_parts.append(dataset_filter)

    # 数据筛选
    if task_filter:
        df = df[df['task'] == task_filter]
    if model_filter:
        df = df[df['model'] == model_filter]
    if dataset_filter:
        df = df[df['dataset'] == dataset_filter]

    # 颜色配置 - 引擎颜色
    # 使用统一颜色字典


    # 填充图案配置 - 指标图案
    metric_hatches = {
        "prompt_throughput": "///",
        "generation_throughput": "\\\\\\",
    }

    fig, ax = plt.subplots(figsize=fig_size)

    engines_unique = list(df['engine'].unique())
    engines = [e for e in ENGINE_ORDER if e in engines_unique]
    qps_values = sorted(df['qps'].unique())
    metrics = ['prompt_throughput', 'generation_throughput']

    # 计算X轴位置
    x_pos = np.arange(len(qps_values))

    # 计算条形位置 - 每个QPS下有 engines * metrics 个条形
    n_bars_per_group = len(engines) * len(metrics)
    total_group_width = n_bars_per_group * BAR_WIDTH
    start_offset = -total_group_width / 2 + BAR_WIDTH / 2

    legend_handles = []
    bar_idx = 0

    # 重新组织图例创建逻辑 - 按指标分组，让布局更均匀
    for metric in metrics:
        for engine in engines:
            engine_data = df[df['engine'] == engine]

            if engine_data.empty:
                continue

            # 按QPS排序并获取对应指标值
            throughput_values = []
            for qps in qps_values:
                qps_data = engine_data[engine_data['qps'] == qps]
                if not qps_data.empty:
                    # 如果有多条记录，取平均值
                    avg_value = qps_data[metric].mean()
                    throughput_values.append(avg_value)
                else:
                    throughput_values.append(0)

            color = COLORS[engine]
            hatch = HATCHES[engine]

            # 计算当前条形的位置
            bar_positions = x_pos + start_offset + bar_idx * BAR_WIDTH

            # 三层绘制方法
            # 1. 白色背景层
            base_bars = ax.bar(
                bar_positions,
                throughput_values,
                BAR_WIDTH,
                facecolor=BAR_FACECOLOR,
                edgecolor='none',
                linewidth=0,
                zorder=1
            )

            # 2. 彩色填充图案层
            ax.bar(
                bar_positions,
                throughput_values,
                BAR_WIDTH,
                facecolor='none',
                edgecolor=color,
                linewidth=0,
                hatch=hatch,
                zorder=2
            )

            # 3. 黑色边框层
            ax.bar(
                bar_positions,
                throughput_values,
                BAR_WIDTH,
                facecolor='none',
                edgecolor=BAR_EDGECOLOR,
                linewidth=BAR_EDGE_WIDTH,
                hatch=None,
                zorder=3
            )

            # 创建图例句柄
            patch = mpatches.Patch(
                facecolor=BAR_FACECOLOR,
                edgecolor=color,
                hatch=hatch,
                label=f"{LABEL_DICT[engine]} - {METRIC_DICT[metric]}",
                linewidth=LEGEND_EDGE_WIDTH
            )
            legend_handles.append(patch)

            # 添加数值注释
            for bar, value in zip(base_bars, throughput_values):
                if value > 0:
                    height = bar.get_height()
                    # 只为较高的值添加注释
                    max_value = max(throughput_values) if throughput_values else 0
                    if value > max_value * 0.5:  # 只标注超过最大值50%的条形
                        ax.text(
                            bar.get_x() + bar.get_width()/2.,
                            height + BAR_ANNOTATION_OFFSET,
                            f'{value:.0f}',
                            ha='center',
                            va='bottom',
                            fontsize=FONT_SIZE_ANNOTATION,
                            zorder=4
                        )

            bar_idx += 1

    # 配置坐标轴
    ax.set_xlabel('QPS', fontsize=FONT_SIZE_LABEL)
    ax.set_ylabel('Throughput (tokens/s)', fontsize=FONT_SIZE_LABEL)

    # 设置标题
    title_parts = []
    if task_filter:
        title_parts.append(f'{task_filter}')
    if model_filter:
        title_parts.append(f'{MODEL_DICT[model_filter]}')
    if dataset_filter:
        title_parts.append(f'{dataset_filter}')

    if title_parts:
        title = f"Throughput Comparison - {' - '.join(title_parts)}"
    else:
        title = "Throughput Comparison"

    # ax.set_title(title, fontsize=FONT_SIZE_LABEL)

    # 设置X轴刻度和标签
    ax.set_xticks(x_pos)
    ax.set_xticklabels([str(qps) for qps in qps_values])

    # 调整X轴边距
    ax.margins(x=X_AXIS_MARGIN)

    # 配置图例
    ax.legend(
        handles=legend_handles,
        loc=LEGEND_LOCATION,
        bbox_to_anchor=LEGEND_BBOX_TO_ANCHOR,
        frameon=LEGEND_FRAME_ON,
        handletextpad=LEGEND_HANDLETEXTPAD,
        columnspacing=LEGEND_COLUMNSPACING,
        handlelength=LEGEND_HANDLE_LENGTH,
        ncol=LEGEND_NCOL
    )

    # 配置网格线
    ax.grid(False, axis='both', which='both')  # 先禁用所有网格
    ax.set_axisbelow(True)  # 确保网格线绘制在图形元素下方
    if GRID_MAJOR_ENABLED:
        ax.grid(
            True,
            axis=GRID_AXIS,
            which='major',
            linestyle=GRID_MAJOR_STYLE,
            color=GRID_MAJOR_COLOR,
            alpha=GRID_MAJOR_ALPHA,
            zorder=0
        )

    # 配置刻度线
    ax.tick_params(
        axis='x',
        which='major',
        direction=TICK_DIRECTION,
        length=TICK_LENGTH_MAJOR,
        top=TICK_ON_TOP,
        bottom=True,
        labeltop=TICK_LABELS_ON_TOP,
        labelbottom=True
    )
    ax.tick_params(
        axis='y',
        which='major',
        direction=TICK_DIRECTION,
        length=TICK_LENGTH_MAJOR,
        right=TICK_ON_RIGHT,
        left=True,
        labelright=TICK_LABELS_ON_RIGHT,
        labelleft=True
    )

    # 关闭次刻度
    ax.minorticks_off()

    # 确保所有坐标轴边框线可见
    for spine in ax.spines.values():
        spine.set_visible(True)

    plt.tight_layout(rect=[0, 0, 1, 0.88])  # 为上方图例留出空间
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Simple throughput comparison chart saved to {output_path}")


def plot_throughput_comparison(csv_file_path: str):
    """主函数：绘制吞吐量对比图"""
    # 创建输出目录
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # 加载数据
    df = load_metrics_data(csv_file_path)

    print(f"Loaded data with {len(df)} rows")
    print(f"Engines: {df['engine'].unique()}")
    print(f"Tasks: {df['task'].unique()}")
    print(f"Models: {df['model'].unique()}")
    print(f"Datasets: {df['dataset'].unique()}")
    print(f"QPS values: {sorted(df['qps'].unique())}")

    # 为每个 task 创建单独的对比图
    for task in df['task'].unique():
        # 为当前 task 创建包含所有 model-dataset 组合的图表
        task_df = df[df['task'] == task]

        # 为每个 task-model-dataset 组合创建简化图表
        for model in task_df['model'].unique():
            for dataset in task_df['dataset'].unique():
                subset = task_df[(task_df['model'] == model) & (task_df['dataset'] == dataset)]
                if not subset.empty:
                    output_path = os.path.join(OUTPUT_DIR, f"compute_{task}_{model}_{dataset}.png")
                    os.makedirs(os.path.dirname(output_path), exist_ok=True)
                    create_simple_throughput_chart(df, output_path, model, dataset, task)


if __name__ == "__main__":
    # 使用统一的 CSV_FILE
    CSV_FILE = "data/gpu_usage.csv"
    OUTPUT_DIR = "img/gpu_compute"

    if os.path.exists(CSV_FILE):
        plot_throughput_comparison(CSV_FILE)
    else:
        print(f"Error: CSV file {CSV_FILE} not found!")