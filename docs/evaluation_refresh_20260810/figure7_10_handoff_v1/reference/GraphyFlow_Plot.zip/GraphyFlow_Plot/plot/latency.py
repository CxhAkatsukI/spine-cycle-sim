import matplotlib.pyplot as plt
import os
import csv
import math

# --- 线条数据和颜色配置 ---
SERIES_MARKERS = ['o', 's', '^', 'D', 'X', 'P', '*']
SERIES_COLORS = ['#377eb8', '#ff7f00', '#4daf4a', '#f781bf', '#a65628', '#984ea3', '#999999']
SERIES_COLORS_DICT = {
    "SunCake": '#ff7f00',
    "vLLM": '#377eb8',
    "LightLLM": '#4daf4a',
    "other": '#f781bf',
}
MARKER_SIZE = 12       # Size of the scatter markers
MARKER_EDGECOLOR = 'black' # Color of the marker edges
MARKER_EDGEWIDTH = 1.0   # Width of the marker edges

# --- 图形和坐标轴样式 ---
FIG_SIZE = (8.5, 4)
X_LABEL = 'QPS(application/s)'
Y_LABEL = 'Average Latency (s)'
# 可选：设置固定限制，否则让Matplotlib自动确定
X_LIMITS = None
Y_LIMITS = None
# 可选：设置特定刻度，否则让Matplotlib自动确定
X_TICKS = None
Y_TICKS = None
Y_AXIS_LOG_SCALE = False
X_AXIS_MARGIN = 0.05

# --- 字体配置 ---
FONT_FAMILY = ['Arial', 'DejaVu Sans', 'sans-serif']
FONT_SIZE_GENERAL = 12
FONT_SIZE_LABEL = 16
FONT_SIZE_TICK = 16
FONT_SIZE_LEGEND = 16

# --- 大图字体（论文用） ---
BIG_FONT_SIZE_GENERAL = 20
BIG_FONT_SIZE_LABEL = 24
BIG_FONT_SIZE_TICK = 22
BIG_FONT_SIZE_LEGEND = 22

# --- 可选水平线 ---
HORIZONTAL_LINE_Y = None
HORIZONTAL_LINE_STYLE = '--'
HORIZONTAL_LINE_WIDTH = 1.0
HORIZONTAL_LINE_COLOR = 'grey'

# --- 网格样式 ---
AXES_LINEWIDTH = 2
GRID_AXIS = 'y'
GRID_MAJOR_ENABLED = True
GRID_MAJOR_STYLE = '--'
GRID_MAJOR_COLOR = 'grey'
GRID_MAJOR_ALPHA = 0.7

# --- 刻度样式 ---
TICK_DIRECTION = 'in'
TICK_LENGTH_MAJOR = 5
TICK_LENGTH_MINOR = 2
TICK_ON_TOP = True      # 在顶部轴线显示刻度
TICK_ON_RIGHT = True    # 在右侧轴线显示刻度
TICK_LABELS_ON_TOP = False # 在顶部轴显示刻度标签
TICK_LABELS_ON_RIGHT = False # 在右侧轴显示刻度标签

# --- 图例样式 ---
LEGEND_LOCATION = 'lower center'
LEGEND_BBOX_TO_ANCHOR = (0.5, 1.02) # 将图例定位在图表上方
LEGEND_FRAME_ON = False
LEGEND_HANDLETEXTPAD = 0.4 # 标记和文本之间的间距
LEGEND_COLUMNSPACING = 0.8 # 列之间的间距（如果LEGEND_NCOL > 1）
LEGEND_HANDLE_LENGTH = 1.0 # 图例中线条/标记的长度

# --- 布局调整 ---
TIGHT_LAYOUT_RECT = [0, 0, 1, 0.95] # tight_layout的区域 [左, 下, 右, 上] - 调整顶部为图例留出空间

# --- 线条样式 ---
LINE_WIDTH = 2

ENGINE_DICT = {
    "suncake": "SunCake",
    "vllm_base": "vLLM",
    "lightllm_base": "LightLLM",
}

TASK_DICT = {
    "code": "CodeWriter",
    "research": "DeepResearch",
}

MODEL_DICT = {
    "a100": "Qwen2.5-14B",
    "h200": "Qwen2.5-32B",
}

DATASET_DICT = {
    "20": "D1",
    "30": "D2",
}

def create_qps_latency_plot(num_requests, qps_data, model, task_name, output_path = f"img/latency/latency.png"):
    """为特定请求数量创建QPS vs 平均延迟的对比图"""

    # 1. 应用全局样式设置
    plt.style.use('default')
    plt.rcParams.update({
        'font.size': FONT_SIZE_GENERAL,
        'axes.labelsize': FONT_SIZE_LABEL,
        'xtick.labelsize': FONT_SIZE_TICK,
        'ytick.labelsize': FONT_SIZE_TICK,
        'legend.fontsize': FONT_SIZE_LEGEND,
        'font.family': 'sans-serif',
        'font.sans-serif': FONT_FAMILY,
        'axes.linewidth': AXES_LINEWIDTH
    })

    # 2. 创建图表和坐标轴
    fig, ax = plt.subplots(figsize=FIG_SIZE)

    # 获取所有QPS值并排序，用于创建均匀分布的x轴
    all_qps_values = sorted(qps_data.keys())
    x_positions = range(len(all_qps_values))

    # 获取所有测试对象类型
    all_types = set()
    for qps_dict in qps_data.values():
        all_types.update(qps_dict.keys())
    all_types = sorted(all_types)

    # 动态设置图例列数
    LEGEND_NCOL = len(all_types)

    # 3. 绘图逻辑 - 为每个测试对象绘制一条线
    for i, test_type in enumerate(all_types):
        x_plot_positions = []
        latency_values = []

        # 收集该测试对象在所有QPS下的数据
        for j, qps in enumerate(all_qps_values):
            if test_type in qps_data[qps]:
                x_plot_positions.append(j)  # 使用索引位置而不是实际QPS值
                latency_values.append(qps_data[qps][test_type])

        if x_plot_positions and latency_values:
            ax.plot(
                x_plot_positions,
                latency_values,
                marker=SERIES_MARKERS[i % len(SERIES_MARKERS)],
                linewidth=LINE_WIDTH,
                markersize=MARKER_SIZE,
                markeredgecolor=MARKER_EDGECOLOR,
                markeredgewidth=MARKER_EDGEWIDTH,
                color=SERIES_COLORS_DICT[test_type],
                label=f"{test_type}",
                zorder=3  # 确保线条在网格之上
            )

    # 4. 配置坐标轴外观
    ax.set_xlabel(X_LABEL)
    ax.set_ylabel(Y_LABEL)

    if X_LIMITS:
        ax.set_xlim(X_LIMITS)
    if Y_LIMITS:
        ax.set_ylim(Y_LIMITS)

    # 设置y轴刻度（线性或对数）
    if Y_AXIS_LOG_SCALE:
        ax.set_yscale('log')
        # 如果手动设置，确保Y_LIMITS对对数刻度是正数
        current_ylim = ax.get_ylim()
        if current_ylim[0] <= 0:
            print(f"Warning: 底部Y限制 ({current_ylim[0]}) 是非正数，对对数刻度无效。正在调整。")
            # 尝试从数据中找到合理的最小值 > 0
            all_positive_y = [qps_data[qps][test_type] for qps in qps_data.keys()
                            for test_type in qps_data[qps].keys() if qps_data[qps][test_type] > 0]
            new_bottom = min(all_positive_y) * 0.8 if all_positive_y else 0.1 # 如果没有正数据则回退
            ax.set_ylim(bottom=new_bottom)
            print(f"底部Y限制调整为 {ax.get_ylim()[0]:.2g}")
    else:
        ax.set_yscale('linear') # 显式设置线性刻度
        if Y_TICKS:
            ax.set_yticks(Y_TICKS) # 仅在定义时设置特定刻度

    # 设置x轴刻度和标签
    ax.set_xticks(x_positions)
    ax.set_xticklabels([str(qps) for qps in all_qps_values])

    # 如果特别提供则设置X刻度
    if X_TICKS:
        ax.set_xticks(X_TICKS)

    # 调整X轴边距
    ax.margins(x=X_AXIS_MARGIN)

    # 确保所有边框线（坐标轴框架线）都可见
    for spine in ax.spines.values():
        spine.set_visible(True)

    # 5. 添加可选水平参考线
    if HORIZONTAL_LINE_Y is not None:
        ax.axhline(HORIZONTAL_LINE_Y, color=HORIZONTAL_LINE_COLOR,
                   linestyle=HORIZONTAL_LINE_STYLE, linewidth=HORIZONTAL_LINE_WIDTH,
                   zorder=0) # 绘制在图表元素后面

    # 6. 配置刻度外观
    ax.tick_params(axis='x', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                   top=TICK_ON_TOP, bottom=True, # 保持底部刻度可见
                   labeltop=TICK_LABELS_ON_TOP, labelbottom=True)
    ax.tick_params(axis='y', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                   right=TICK_ON_RIGHT, left=True,
                   labelright=TICK_LABELS_ON_RIGHT, labelleft=True)
    ax.minorticks_off() # 默认禁用次要刻度

    # 7. 配置网格线
    ax.grid(False, axis='both', which='both') # 首先禁用所有网格
    ax.set_axisbelow(True) # 确保网格在数据点下方
    if GRID_MAJOR_ENABLED:
        ax.grid(True, axis=GRID_AXIS, which='major',
                linestyle=GRID_MAJOR_STYLE, color=GRID_MAJOR_COLOR,
                alpha=GRID_MAJOR_ALPHA, zorder=0)

    # # 8. 创建图例
    legend_options = {
        'loc': LEGEND_LOCATION,
        'bbox_to_anchor': LEGEND_BBOX_TO_ANCHOR,
        'ncol': LEGEND_NCOL,
        'frameon': LEGEND_FRAME_ON,
        'handletextpad': LEGEND_HANDLETEXTPAD,
        'columnspacing': LEGEND_COLUMNSPACING,
        'handlelength': LEGEND_HANDLE_LENGTH,
    }
    ax.legend(**legend_options)

    # 添加图例标题
    dataset = DATASET_DICT[str(int(num_requests))]
    ax.text(0.5, 1.05, f"{task_name} {model} on Dataset {dataset}",
            ha='center', va='bottom',
            transform=ax.transAxes,
            fontsize=FONT_SIZE_LEGEND,
            fontweight='bold')
    output_path = f"img/latency/{task_name}_{model}_{dataset}.png"
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    # 9. 最终布局调整
    try:
        # 根据图例位置调整tight_layout中的rect参数
        fig.tight_layout(rect=TIGHT_LAYOUT_RECT)
    except ValueError:
        print("Warning: tight_layout失败，可能由于极端的Bbox限制或重叠元素。回退到默认tight_layout。")
        fig.tight_layout() # 应用默认tight layout作为回退

    # 10. 保存图表
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"QPS对比图已保存至 {output_path}")

# --- 数据加载辅助函数 ---

def load_latency_data_from_csv(csv_path):
    """从 CSV 加载数据并转换为绘图需要的嵌套字典结构"""
    data_by_requests = {}
    model = None
    task_name = None
    with open(csv_path, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            num_requests = int(row["num_requests"])
            qps = float(row["qps"])
            engine = row["engine"]
            avg_latency = float(row["avg_latency"])
            model = row["model"]
            task_name = row["task"]

            data_by_requests.setdefault(num_requests, {}).setdefault(qps, {})[
                engine
            ] = avg_latency
    return data_by_requests, model, task_name

# ======================= 按 Task/Device/Dataset 排列的 8 子图大图 =======================

def plot_latency_task_device_grid(devices, tasks, datasets):
    """按照 task 行、device+dataset 列排版，生成 8 子图 (2×4) 大图。"""

    # 计算网格尺寸
    n_rows = len(tasks)
    n_cols = len(devices) * len(datasets)

    fig_width = 4.5 * n_cols
    fig_height = 4.0 * n_rows

    # 大字体样式
    plt.style.use('default')
    plt.rcParams.update({
        'font.size': BIG_FONT_SIZE_GENERAL,
        'axes.labelsize': BIG_FONT_SIZE_LABEL,
        'xtick.labelsize': BIG_FONT_SIZE_TICK,
        'ytick.labelsize': BIG_FONT_SIZE_TICK,
        'legend.fontsize': BIG_FONT_SIZE_LEGEND,
        'font.family': 'sans-serif',
        'font.sans-serif': FONT_FAMILY,
        'axes.linewidth': AXES_LINEWIDTH,
    })

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(fig_width, fig_height), squeeze=False)

    handles, labels_collected = [], []

    # 遍历任务 (行)
    for r, task in enumerate(tasks):
        task_name = TASK_DICT[task]

        for d_idx, device in enumerate(devices):
            model = MODEL_DICT[device]

            csv_path = f"data/latency/latency_{device}_{task}.csv"
            if not os.path.exists(csv_path):
                print(f"[WARN] CSV 不存在: {csv_path}")
                continue

            data_by_requests, _, _ = load_latency_data_from_csv(csv_path)

            # 遍历数据集 (列中的次级)
            for ds_idx, ds in enumerate(datasets):
                num_requests = int(ds)
                col = d_idx * len(datasets) + ds_idx
                ax = axes[r][col]

                if num_requests not in data_by_requests:
                    ax.set_visible(False)
                    continue

                qps_data = data_by_requests[num_requests]

                test_types = sorted({k for q in qps_data.values() for k in q.keys()})

                for i, test_type in enumerate(test_types):
                    x_vals, y_vals = [], []
                    for qps in sorted(qps_data.keys()):
                        if test_type in qps_data[qps]:
                            x_vals.append(qps)
                            y_vals.append(qps_data[qps][test_type])
                    if x_vals:
                        h, = ax.plot(
                            x_vals, y_vals,
                            marker=SERIES_MARKERS[i % len(SERIES_MARKERS)],
                            linewidth=LINE_WIDTH,
                            markersize=MARKER_SIZE,
                            markeredgecolor=MARKER_EDGECOLOR,
                            markeredgewidth=MARKER_EDGEWIDTH,
                            color=SERIES_COLORS_DICT.get(test_type, '#000000'),
                            label=test_type,
                        )
                        if test_type not in labels_collected:
                            handles.append(h)
                            labels_collected.append(test_type)

                dataset_label = DATASET_DICT.get(str(ds), str(ds))
                ax.set_title(f"{model} {dataset_label}")
                ax.grid(True, linestyle=GRID_MAJOR_STYLE, color=GRID_MAJOR_COLOR, alpha=GRID_MAJOR_ALPHA)

        # 在行最左侧加任务标签
        axes[r][0].annotate(task_name, xy=(0, 0.5), xytext=(-axes[r][0].yaxis.labelpad - 40, 0),
                            xycoords=axes[r][0].yaxis.label, textcoords='offset points',
                            size=BIG_FONT_SIZE_LABEL, ha='right', va='center', rotation=90)

    fig.legend(handles, labels_collected,
               loc='upper center', bbox_to_anchor=(0.5, 1.01),
               ncol=len(labels_collected), frameon=False,
               handletextpad=LEGEND_HANDLETEXTPAD,
               columnspacing=LEGEND_COLUMNSPACING,
               handlelength=LEGEND_HANDLE_LENGTH,
               prop={'size': BIG_FONT_SIZE_LEGEND + 4})

    # 统一轴标签
    fig.text(0.5, 0.01, X_LABEL, ha='center', va='center', fontsize=BIG_FONT_SIZE_LABEL)
    fig.text(0.06, 0.5, Y_LABEL, ha='center', va='center', rotation='vertical', fontsize=BIG_FONT_SIZE_LABEL)

    # fig.suptitle("Latency Comparison by Task / Device / Dataset", fontsize=BIG_FONT_SIZE_LEGEND, y=1.06)

    try:
        fig.tight_layout(rect=[0, 0, 1, 0.95])
    except ValueError:
        fig.tight_layout()

    out_path = "img/latency/latency_grid_task_device.png"
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    plt.savefig(out_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Task/Device 大图已保存至 {out_path}")

# ======================= 单张对比图批量绘制 =======================

def plot_latency_comparison_from_csv(csv_path):
    """读取 CSV 并分别为每个 num_requests 生成单张对比图"""

    data_by_requests, model, task_name = load_latency_data_from_csv(csv_path)
    for num_requests in sorted(data_by_requests.keys()):
        create_qps_latency_plot(
            num_requests,
            data_by_requests[num_requests],
            model,
            task_name,
        )

# --- 执行入口 ---
if __name__ == "__main__":
    for device in ["a100", "h200"]:
        for task in ["code", "research"]:
            model = MODEL_DICT[device]
            task_name = TASK_DICT[task]
            csv_path = f"data/latency/latency_{device}_{task}.csv"

            plot_latency_comparison_from_csv(csv_path)

    # 生成 (task 行 × device+dataset 列) 的 8 子图大图
    plot_latency_task_device_grid(list(MODEL_DICT.keys()), list(TASK_DICT.keys()), list(DATASET_DICT.keys()))
