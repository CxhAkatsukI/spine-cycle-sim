import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import pandas as pd
import numpy as np
import os

# --- 配置常量 ---
# 系列数据和名称 (定义顺序): 每个元组包含 (系列名称, [数据值列表])
SERIES_DATA = [
    ('suncake', []),
    ('vllm', []),
    ('lightllm', []),
]

# 颜色与图案映射，参考 compute_bar.py 的风格
TYPE_COLORS = {
    'suncake': '#ff7f0e',    # 橙色
    'vllm': '#1f77b4',  # 蓝色
    'lightllm': '#2ca02c', # 绿色
}

TYPE_HATCHES = {
    'suncake': 'xxx',
    'vllm': '///',
    'lightllm': '\\\\\\',
}

# X轴类别名称: 用于 X 轴刻度标签的字符串列表
CATEGORIES = []  # 将在数据处理后填充

BAR_FACECOLOR = 'white'  # 条形图填充颜色
BAR_EDGECOLOR = 'black'  # 条形图边框颜色

# --- 图形和坐标轴样式 ---
FIG_SIZE = (12, 7)  # 图形尺寸 (英寸)
Y_LABEL = 'Abnormal Agent Count'  # Y轴标签文本
Y_LIMITS = (0, None)  # Y轴显示范围 (最小值, 最大值)
X_AXIS_MARGIN = 0.03  # X轴左右边距 (占总宽度的比例)

# --- 字体配置 ---
FONT_FAMILY = ['Arial', 'DejaVu Sans', 'sans-serif']  # 字体系列
FONT_SIZE_GENERAL = 18  # 全局默认字体大小 (可根据需要统一调节)
FONT_SIZE_LABEL = 26    # 坐标轴标签字体大小
FONT_SIZE_TICK = 22     # 刻度标签字体大小
FONT_SIZE_LEGEND = 26   # 图例字体大小
FONT_SIZE_ANNOTATION = 20  # 条形图上方注释文字字体大小
X_TICK_ROTATION = 0  # X轴刻度标签旋转角度

# --- 条形图样式 ---
BAR_WIDTH = 0.35  # 单个条形的宽度
INTRA_GROUP_GAP = 0.0  # 同组内条形之间的间隙
BAR_EDGE_WIDTH = 3.0  # 条形图边框线宽
BAR_ANNOTATION_OFFSET = 1  # 注释文字距离条形顶部的垂直偏移量
INTER_GROUP_SPACING = 1.2  # 组中心点之间的距离

# --- 图形和坐标轴样式 ---
AXES_LINEWIDTH = 2  # 坐标轴和边框线宽
GRID_AXIS = 'y'  # 网格线应用于哪个轴
GRID_MAJOR_ENABLED = True  # 是否启用主网格线
GRID_MAJOR_STYLE = '--'  # 主网格线样式
GRID_MAJOR_COLOR = 'grey'  # 主网格线颜色
GRID_MAJOR_ALPHA = 0.7  # 主网格线透明度

# --- 刻度样式 ---
TICK_DIRECTION = 'in'  # 刻度线方向
TICK_LENGTH_MAJOR = 5  # 主刻度线长度
TICK_ON_TOP = True  # 是否在顶部显示X轴刻度线
TICK_ON_RIGHT = True  # 是否在右侧显示Y轴刻度线
TICK_LABELS_ON_TOP = False  # 是否在顶部显示X轴刻度标签
TICK_LABELS_ON_RIGHT = False  # 是否在右侧显示Y轴刻度标签

# --- 图例样式（改为与 compute_bar 相同的布局） ---
LEGEND_NCOL = len(SERIES_DATA)
LEGEND_LOCATION = 'upper center'
LEGEND_BBOX_TO_ANCHOR = (0.5, 1.22)
LEGEND_FRAME_ON = False
LEGEND_HANDLETEXTPAD = 0.2
LEGEND_COLUMNSPACING = 0.8
LEGEND_HANDLE_LENGTH = 1.8
LENGEND_EDGE_WIDTH = 2

# --- 布局调整 ---
TIGHT_LAYOUT_RECT = [0, 0.05, 1, 0.90]
# 保存目录
IMG_DIR = 'img/abnormal'
os.makedirs(IMG_DIR, exist_ok=True)

LABEL_DICT = {
    "suncake": "SunCake",
    "vllm": "vLLM",
    "lightllm": "LightLLM"
}

# 模型标签映射
MODEL_DICT = {
    "a100": "Qwen2.5-14B",
    "h200": "Qwen2.5-32B",
}

LABEL_DICT = {
    "mcp_file_write": "File Write",
    "reviser": "Reviser",
    "mcp_external_test": "External Test",
    "mcp_external_tool_eval": "Tool Eval",
    "reviewer": "Reviewer"
}

ENGINE_DICT = {
    "suncake": "SunCake",
    "vllm": "vLLM",
    "lightllm": "LightLLM"
}

ENGINE_ORDER = ['suncake', 'vllm', 'lightllm']

def create_bar_charts_per_config():
    """遍历 data/abnormal 中所有 CSV，为每个配置绘制柱状图并保存"""

    csv_dir = 'data/abnormal'
    if not os.path.isdir(csv_dir):
        print(f"目录不存在: {csv_dir}")
        return

    # 公共样式
    plt.style.use('default')
    plt.rcParams.update({
        'font.size': FONT_SIZE_GENERAL,
        'axes.labelsize': FONT_SIZE_LABEL,
        'xtick.labelsize': FONT_SIZE_TICK,
        'ytick.labelsize': FONT_SIZE_TICK,
        'legend.fontsize': FONT_SIZE_LEGEND,
        'font.family': 'sans-serif',
        'font.sans-serif': FONT_FAMILY,
        'hatch.linewidth': 1,
        'axes.linewidth': AXES_LINEWIDTH,
        'axes.unicode_minus': False,
    })

    for csv_file in sorted(os.listdir(csv_dir)):
        if not csv_file.endswith('.csv'):
            continue

        csv_path = os.path.join(csv_dir, csv_file)
        df = pd.read_csv(csv_path)

        # 所有 agent 类型
        all_types = sorted(df['type'].unique())

        # 先统计各 engine 对每个 type 的计数
        engines_unique = list(df['engine'].unique())
        engines = [e for e in ENGINE_ORDER if e in engines_unique]
        type_counts_by_engine = {
            engine: {t: int(df[(df['engine'] == engine) & (df['type'] == t)]['count'].sum()) for t in all_types}
            for engine in engines
        }

        # 过滤：如果所有 engine 对该 type 的计数都为 0，则移除
        filtered_types = [t for t in all_types if any(type_counts_by_engine[e][t] > 0 for e in engines)]

        # 选择总数最多的前5个 type
        total_counts = {t: sum(type_counts_by_engine[e][t] for e in engines) for t in filtered_types}
        top_types = sorted(total_counts.keys(), key=lambda x: total_counts[x], reverse=True)[:5]
        agent_types = top_types

        # 重新构造 series_data
        series_data = []
        for engine in engines:
            counts = [type_counts_by_engine[engine][a] for a in agent_types]
            series_data.append((engine, counts))

        n_types = len(agent_types)
        n_series = len(series_data)

        x_pos = [i * INTER_GROUP_SPACING for i in range(n_types)]
        total_group_width = n_series * BAR_WIDTH
        start_offset = -total_group_width / 2 + BAR_WIDTH / 2

        fig, ax = plt.subplots(figsize=FIG_SIZE)

        legend_handles = []

        for i, (engine_name, counts) in enumerate(series_data):
            color = TYPE_COLORS.get(engine_name, '#377eb8')
            hatch = TYPE_HATCHES.get(engine_name, '///')
            bar_positions = [pos + start_offset + i * BAR_WIDTH for pos in x_pos]

            # 三层绘制方式
            base_bars = ax.bar(bar_positions, counts, BAR_WIDTH, facecolor=BAR_FACECOLOR,
                               edgecolor='none', linewidth=0, zorder=1)
            ax.bar(bar_positions, counts, BAR_WIDTH, facecolor='none', edgecolor=color,
                   linewidth=0, hatch=hatch, zorder=2)
            ax.bar(bar_positions, counts, BAR_WIDTH, facecolor='none', edgecolor=BAR_EDGECOLOR,
                   linewidth=BAR_EDGE_WIDTH, hatch=None, zorder=3)

            legend_label = ENGINE_DICT.get(engine_name, engine_name)
            patch = mpatches.Patch(facecolor=BAR_FACECOLOR, edgecolor=color, hatch=hatch,
                                   label=legend_label, linewidth=LENGEND_EDGE_WIDTH)
            legend_handles.append(patch)

            # 注释
            for bar, value in zip(base_bars, counts):
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width() / 2., height + BAR_ANNOTATION_OFFSET,
                        f'{int(value)}', ha='center', va='bottom', fontsize=FONT_SIZE_ANNOTATION,
                        zorder=4)

        # 给 y 轴留出 20% 头部空间，避免文字被遮挡
        max_val = max(max(c) for _, c in series_data) if series_data else 0
        ax.set_ylim(0, max_val * 1.15)

        # 轴设置
        ax.set_ylabel(Y_LABEL)
        ax.set_ylim(Y_LIMITS)
        ax.set_xticks(x_pos)
        display_types = [LABEL_DICT[t] for t in agent_types]
        ax.set_xticklabels(display_types, rotation=X_TICK_ROTATION, ha='center', fontsize=FONT_SIZE_TICK)
        ax.margins(x=X_AXIS_MARGIN)

        for spine in ax.spines.values():
            spine.set_visible(True)

        ax.tick_params(axis='x', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                       top=TICK_ON_TOP, bottom=False, labeltop=TICK_LABELS_ON_TOP, labelbottom=True)
        ax.tick_params(axis='y', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                       right=TICK_ON_RIGHT, left=True, labelright=TICK_LABELS_ON_RIGHT, labelleft=True)

        ax.minorticks_off()

        if GRID_MAJOR_ENABLED:
            ax.grid(True, axis=GRID_AXIS, which='major', linestyle=GRID_MAJOR_STYLE,
                    color=GRID_MAJOR_COLOR, alpha=GRID_MAJOR_ALPHA, zorder=0)

        ax.legend(handles=legend_handles, loc=LEGEND_LOCATION, bbox_to_anchor=LEGEND_BBOX_TO_ANCHOR,
                  ncol=len(legend_handles), frameon=LEGEND_FRAME_ON, handletextpad=LEGEND_HANDLETEXTPAD,
                  columnspacing=LEGEND_COLUMNSPACING, handlelength=LEGEND_HANDLE_LENGTH)

        fig.tight_layout(rect=TIGHT_LAYOUT_RECT)

        # 保存文件
        base_name = os.path.splitext(csv_file)[0]
        png_path = os.path.join(IMG_DIR, f"abnormal_compare_{base_name}.png")
        # pdf_path = os.path.join(IMG_DIR, f"{base_name}.pdf")
        plt.savefig(png_path, format='png', bbox_inches='tight', dpi=300)
        # plt.savefig(pdf_path, format='pdf', bbox_inches='tight')
        print(f"Saved png to: {png_path}")
        plt.close(fig)

# --- 执行入口 ---
if __name__ == "__main__":
    create_bar_charts_per_config()
