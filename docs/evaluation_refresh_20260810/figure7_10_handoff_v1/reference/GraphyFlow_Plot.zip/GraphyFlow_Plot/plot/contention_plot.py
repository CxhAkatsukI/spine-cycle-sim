import csv
from pathlib import Path
from collections import defaultdict

import matplotlib.pyplot as plt

# ---------- 全局美化设置 ----------
plt.style.use('default')
plt.rcParams.update({
    'font.size': 12,          # 普通文字
    'axes.labelsize': 14,    # 轴标签
    'axes.titlesize': 16,    # 标题
    'xtick.labelsize': 12,
    'ytick.labelsize': 12,
    'legend.fontsize': 12,
    'axes.linewidth': 2,     # 坐标轴线宽
    'lines.linewidth': 2.5,  # 折线宽度
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'DejaVu Sans', 'sans-serif'],
})

CSV_PATH = Path("data/contention_analysis.csv")
IMG_PATH = Path("img/contention_plot.png")
if not IMG_PATH.parent.exists():
    IMG_PATH.parent.mkdir(parents=True, exist_ok=True)

if not CSV_PATH.exists():
    raise FileNotFoundError(f"CSV 文件不存在: {CSV_PATH}")

# 数据容器
all_times = []  # 所有事件时间
content_times = []  # victim_pri > preempt_pri
normal_times = []  # victim_pri <= preempt_pri

with CSV_PATH.open("r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        t = float(row[reader.fieldnames[0]])  # 第一列是时间差（秒）
        pre_pri = int(row["preempt_priority"])
        vic_pri = int(row["victim_priority"])
        all_times.append(t)
        if vic_pri > pre_pri:
            content_times.append(t)
        else:
            normal_times.append(t)

# 将时间排序，计算累积数量

def cum_counts(times_list):
    counts = []
    times_sorted = sorted(times_list)
    for idx, _ in enumerate(times_sorted, 1):
        counts.append(idx)
    return times_sorted, counts

x_all, y_all = cum_counts(all_times)
x_content, y_content = cum_counts(content_times)
x_normal, y_normal = cum_counts(normal_times)

# 可调参数
FIG_SIZE = (4, 4)  # 宽度缩小一半，保持高度
# 若只想截取前 N 秒的数据窗口，设置为正数，例如 10；否则为 None 显示全部
TIME_WINDOW: float | None = None
# --------------------------------

plt.figure(figsize=FIG_SIZE)  # 瘦长型
plt.plot(x_all, y_all, label="Total", color="#377eb8")
plt.plot(x_content, y_content, label="Inversion", color="#e41a1c")
plt.plot(x_normal, y_normal, label="Normal", color="#4daf4a")

plt.xlabel("Time (s)")
plt.ylabel("Cumulative Count")
plt.title("Contention Analysis")

# 只在 y 轴加轻微网格，提升可读性
plt.grid(True, axis='y', linestyle='--', alpha=0.6)

# 图例放置在图内右上角，避免遮挡标题
plt.legend(loc='upper left', bbox_to_anchor=(0.02, 0.98), ncol=1, frameon=False, prop={'size':14})

# 如果指定了时间窗口，则仅显示该窗口范围，并减少 X 轴刻度数量
if TIME_WINDOW is not None:
    plt.xlim(0, TIME_WINDOW)

# 减少 x 轴刻度数量，避免刻度重叠
plt.locator_params(axis="x", nbins=6)

plt.tight_layout()

# 保存图片到同级目录
out_png = IMG_PATH
plt.savefig(out_png, dpi=300)
print(f"图已保存至 {out_png}")
