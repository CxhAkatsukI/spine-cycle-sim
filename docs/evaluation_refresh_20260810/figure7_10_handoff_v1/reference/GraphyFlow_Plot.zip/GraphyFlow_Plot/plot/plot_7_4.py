import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import pandas as pd
import numpy as np
import os

# --- 1. 数据配置 (使用您提供的最新版本) ---
# X轴类别名称
CATEGORIES = ['1024', '2048', '3072', '4096', '5120']

# 系列数据和名称
SERIES_DATA = [
    ('offload_time',  [5.997, 15.900, 18.563, 31.552, 36.841]),
    ('upload_time', [5.902, 15.540, 18.338, 28.956, 29.169]),
    ('compute_time', [2211.294, 4462.152, 6708.758, 8943.916, 11199.923]),
]

# 标签字典 (用于图例显示)
LABEL_DICT = {
    "offload_time":  "Offload",
    "compute_time":  "Compute",
    "upload_time": "Upload",
}

# --- 2. 风格配置 (大部分保留，关键部分修改) ---
# 颜色与图案映射
TYPE_COLORS = {
    'offload_time':  '#ff7f0e', # 橙色
    'compute_time':  '#1f77b4', # 蓝色
    'upload_time': '#2ca02c',   # 绿色
}

TYPE_HATCHES = {
    'offload_time':  'xxx',
    'compute_time':  '///',
    'upload_time': '\\\\\\',
}

BAR_FACECOLOR = 'white'
BAR_EDGECOLOR = 'black'

# 图形和坐标轴样式
FIG_SIZE = (12, 7)
Y_LABEL = 'Time (ms, log scale)'  # <--- 改动: Y轴标签更新，注明对数坐标
Y_LIMITS = (1, 30000)             # <--- 改动: Y轴范围修改，对数坐标最小值不能为0
X_AXIS_MARGIN = 0.03

# 字体配置
FONT_FAMILY = ['Arial', 'DejaVu Sans', 'sans-serif']
FONT_SIZE_GENERAL = 18
FONT_SIZE_LABEL = 26
FONT_SIZE_TICK = 22
FONT_SIZE_LEGEND = 28
FONT_SIZE_ANNOTATION = 20
X_TICK_ROTATION = 0

# 条形图样式
BAR_WIDTH = 0.25
INTRA_GROUP_GAP = 0.0
BAR_EDGE_WIDTH = 3.0
# BAR_ANNOTATION_OFFSET = 100 # 在对数坐标下不再需要固定偏移
INTER_GROUP_SPACING = 0.85

# 坐标轴样式
AXES_LINEWIDTH = 2
GRID_AXIS = 'y'
GRID_MAJOR_ENABLED = True
GRID_MAJOR_STYLE = '--'
GRID_MAJOR_COLOR = 'grey'
GRID_MAJOR_ALPHA = 0.7

# 刻度样式
TICK_DIRECTION = 'in'
TICK_LENGTH_MAJOR = 5
TICK_ON_TOP = True
TICK_ON_RIGHT = True
TICK_LABELS_ON_TOP = False
TICK_LABELS_ON_RIGHT = False

# 图例样式
LEGEND_NCOL = len(SERIES_DATA)
LEGEND_LOCATION = 'upper center'
LEGEND_BBOX_TO_ANCHOR = (0.5, 1.22)
LEGEND_FRAME_ON = False
LEGEND_HANDLETEXTPAD = 0.2
LEGEND_COLUMNSPACING = 0.8
LEGEND_HANDLE_LENGTH = 1.8
LENGEND_EDGE_WIDTH = 2

# 布局和保存
TIGHT_LAYOUT_RECT = [0, 0.05, 1, 0.90]
IMG_DIR = 'img/time_tradeoff'
os.makedirs(IMG_DIR, exist_ok=True)


# --- 3. 绘图函数 ---
def create_time_tradeoff_chart_log_scale():
    """使用指定风格绘制对数坐标轴的、包含三个系列的对比图"""

    plt.style.use('default')
    plt.rcParams.update({
        'font.size': FONT_SIZE_GENERAL,
        'axes.labelsize': FONT_SIZE_LABEL,
        'xtick.labelsize': FONT_SIZE_TICK,
        'ytick.labelsize': FONT_SIZE_TICK,
        'legend.fontsize': FONT_SIZE_LEGEND,  # 图例字体改小
        'font.family': 'sans-serif',
        'font.sans-serif': FONT_FAMILY,
        'hatch.linewidth': 1,
        'axes.linewidth': AXES_LINEWIDTH,
        'axes.unicode_minus': False,
    })

    n_categories = len(CATEGORIES)
    n_series = len(SERIES_DATA)

    x_pos = [i * INTER_GROUP_SPACING for i in range(n_categories)]
    total_group_width = n_series * BAR_WIDTH
    start_offset = -total_group_width / 2 + BAR_WIDTH / 2

    fig, ax = plt.subplots(figsize=FIG_SIZE)
    legend_handles = []

    for i, (series_name, counts) in enumerate(SERIES_DATA):
        color = TYPE_COLORS.get(series_name)
        hatch = TYPE_HATCHES.get(series_name)
        bar_positions = [pos + start_offset + i * (BAR_WIDTH + INTRA_GROUP_GAP) for pos in x_pos]

        base_bars = ax.bar(bar_positions, counts, BAR_WIDTH, facecolor=BAR_FACECOLOR,
                               edgecolor='none', linewidth=0, zorder=1)
        ax.bar(bar_positions, counts, BAR_WIDTH, facecolor='none', edgecolor=color,
               linewidth=0, hatch=hatch, zorder=2)
        ax.bar(bar_positions, counts, BAR_WIDTH, facecolor='none', edgecolor=BAR_EDGECOLOR,
               linewidth=BAR_EDGE_WIDTH, hatch=None, zorder=3)

        legend_label = LABEL_DICT.get(series_name, series_name)
        patch = mpatches.Patch(facecolor=BAR_FACECOLOR, edgecolor=color, hatch=hatch,
                               label=legend_label, linewidth=LENGEND_EDGE_WIDTH)
        legend_handles.append(patch)

        for bar, value in zip(base_bars, counts):
            height = bar.get_height()
            display_value = f'{int(value)}' if value >= 100 else f'{value:.0f}'
            # <--- 改动: 调整注释位置以适应对数坐标 (按比例而非固定值)
            ax.text(bar.get_x() + bar.get_width() / 2., height * 1.1,
                    display_value, ha='center', va='bottom', fontsize=FONT_SIZE_ANNOTATION, zorder=4)

    # --- 设置坐标轴和图表样式 ---
    ax.set_yscale('log')  # <--- 核心改动: 设置Y轴为对数坐标

    ax.set_ylabel(Y_LABEL, fontsize=FONT_SIZE_LABEL)  # 保持Y轴标签字体大小
    ax.set_xlabel('Block Size', fontsize=FONT_SIZE_LABEL)  # 添加X轴说明，字体略小
    ax.set_ylim(Y_LIMITS)
    ax.set_xticks(x_pos)
    ax.set_xticklabels(CATEGORIES, rotation=X_TICK_ROTATION, ha='center', fontsize=FONT_SIZE_TICK - 2)  # 坐标轴字体改小
    ax.margins(x=X_AXIS_MARGIN)

    # 确保所有边框可见并设置样式
    for spine in ['top', 'right', 'bottom', 'left']:
        ax.spines[spine].set_visible(True)
        ax.spines[spine].set_linewidth(AXES_LINEWIDTH)
        ax.spines[spine].set_color('black')

    ax.tick_params(axis='x', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                   top=TICK_ON_TOP, bottom=True, labeltop=TICK_LABELS_ON_TOP, labelbottom=True)
    ax.tick_params(axis='y', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                   right=TICK_ON_RIGHT, left=True, labelright=TICK_LABELS_ON_RIGHT, labelleft=True)

    ax.minorticks_off() # 在对数坐标下通常不显示次刻度

    if GRID_MAJOR_ENABLED:
        ax.grid(True, axis=GRID_AXIS, which='major', linestyle=GRID_MAJOR_STYLE,
                color=GRID_MAJOR_COLOR, alpha=GRID_MAJOR_ALPHA, zorder=0)

    ax.legend(handles=legend_handles, loc=LEGEND_LOCATION, bbox_to_anchor=LEGEND_BBOX_TO_ANCHOR,
              ncol=len(legend_handles), frameon=LEGEND_FRAME_ON, handletextpad=LEGEND_HANDLETEXTPAD,
              columnspacing=LEGEND_COLUMNSPACING, handlelength=LEGEND_HANDLE_LENGTH, fontsize=FONT_SIZE_LEGEND - 4)  # 图例字体改小

    fig.tight_layout(rect=TIGHT_LAYOUT_RECT)

    png_path = os.path.join(IMG_DIR, "time_tradeoff_log_scale.png")
    plt.savefig(png_path, format='png', bbox_inches='tight', dpi=300)
    print(f"图表已保存到: {png_path}")
    
    # plt.show()


# --- 4. 执行入口 ---
if __name__ == "__main__":
    create_time_tradeoff_chart_log_scale()