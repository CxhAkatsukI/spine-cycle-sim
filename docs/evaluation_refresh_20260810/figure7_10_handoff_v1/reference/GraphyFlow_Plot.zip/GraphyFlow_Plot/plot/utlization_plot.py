import csv
from pathlib import Path
from typing import List, Dict, Tuple

import matplotlib.pyplot as plt
import matplotlib as mpl

# 基础字体
BASE_FONT_SIZE = 12
# 标题、坐标轴、图例字体(相对基础)
TITLE_SIZE = 14
LABEL_SIZE = 14
TICK_SIZE = 12
LEGEND_SIZE = 8

# 画布尺寸 (英寸)
FIG_SIZE = (4, 4)
FIG_DPI = 300

# 标注点数量
NOTATION_NUM = 7

LABEL_DICT = {
    "mcp_conditional_execution": "Cond Execution",
    "mcp_external_test": "External Test",
    "mcp_external_tool_eval": "External Tool Eval",
    "mcp_file_query": "File Query",
    "mcp_file_write": "File Write",
    "mcp_search": "Search",
    "mcp_user_confirm": "User Confirm",
}

CSV_PATH = Path("data/utlization_clean.csv")
OUTPUT_IMG = Path("img/utlization_plot.png")

# GPU KV cache 总 block 数
TOTAL_BLOCKS = 14266

# Matplotlib 全局风格
mpl.rcParams.update({
    "figure.dpi": FIG_DPI,
    "font.size": BASE_FONT_SIZE,
    "axes.titlesize": TITLE_SIZE,
    "axes.labelsize": LABEL_SIZE,
    "xtick.labelsize": TICK_SIZE,
    "ytick.labelsize": TICK_SIZE,
    "legend.fontsize": LEGEND_SIZE,
    "axes.linewidth": 2,
    "lines.linewidth": 2.5,
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "DejaVu Sans", "sans-serif"],
    "axes.grid": True,
    "grid.alpha": 0.3,
    "grid.linestyle": "--",
})

def load_csv(path: Path) -> Tuple[List[int], List[str], List[Dict[str, int]], List[float]]:
    """读取 CSV，返回时间序列、agent 列表、agent block 数据、GPU usage%."""
    times: List[int] = []
    agent_cols: List[str] = []
    agent_data: List[Dict[str, int]] = []
    usages: List[float] = []

    with path.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        # 提取 agent 列名（排除 time 和 gpu_kv_usage）
        fieldnames = reader.fieldnames or []
        agent_cols = [c for c in fieldnames if c not in ("time", "gpu_kv_usage")]

        for row in reader:
            times.append(int(row["time"]))
            agent_data.append({agent: int(row[agent]) for agent in agent_cols})
            usage_str = row.get("gpu_kv_usage", "")
            usages.append(float(usage_str) if usage_str else None)

    return times, agent_cols, agent_data, usages


def compute_series(agent_cols: List[str], agent_data: List[Dict[str, int]], usages: List[float]) -> Tuple[List[List[float]], List[float]]:
    """根据 agent 数据和 usage% 计算堆叠曲线 (cumulative) 及 total_blocks 曲线。"""
    series = {agent: [] for agent in agent_cols}
    total_used_blocks: List[float] = []

    for i, data in enumerate(agent_data):
        # total used blocks 根据 usage% 计算；若缺失则用各 agent 之和
        if usages[i] is not None:
            total_used = usages[i] * TOTAL_BLOCKS / 100.0
        else:
            total_used = sum(data.values())
        # total_used_blocks.append(total_used)
        total = total_used

        sum_agents = sum(data.values())
        # scale = (total_used / sum_agents) if sum_agents > 0 else 1.0
        scale = 1.0

        total = 0
        for agent in agent_cols:
            scaled_val = data.get(agent, 0) * scale
            series[agent].append(scaled_val)
            total += scaled_val
        total_used_blocks.append(total)

    # 按顺序计算 cumulative
    cumulative: List[List[float]] = []
    running_sum = [0.0] * len(agent_data)
    for agent in agent_cols:
        running_sum = [r + v for r, v in zip(running_sum, series[agent])]
        cumulative.append(running_sum.copy())
    return cumulative, total_used_blocks


# ----------------- 绘图 -----------------

def plot_utilization():
    times, agent_cols, agent_data, usages = load_csv(CSV_PATH)
    if not times:
        raise RuntimeError("CSV 数据为空，无法绘图")

    cumulative, total_used_blocks = compute_series(agent_cols, agent_data, usages)

    # ----------------- 选择 500s 最大平均使用窗口 -----------------
    window_sec = 1000

    if len(times) > 1 and (times[-1] - times[0]) > window_sec:
        print("data enough, total length: ", (times[-1] - times[0]))
        # 使用双指针查找最大平均值窗口
        prefix_sum = [0]
        for v in total_used_blocks:
            prefix_sum.append(prefix_sum[-1] + v)

        best_avg = -1
        best_start = 0
        best_end = len(times) - 1

        j = 0
        for i, t_start in enumerate(times):
            # 移动 j 直到超过窗口
            while j < len(times) and times[j] - t_start <= window_sec:
                j += 1
            # 现在区间为 [i, j-1]
            total = prefix_sum[j] - prefix_sum[i]
            length = j - i
            if length > 0:
                avg = total / length
                if avg > best_avg:
                    best_avg = avg
                    best_start, best_end = i, j - 1

        # 截取窗口数据
        start = (best_start + best_end) // 2
        # start = best_start
        end = best_end
        print(f"start: {start}, end: {end}")
        times = times[start:end + 1]
        total_used_blocks = total_used_blocks[start:end + 1]
        cumulative = [series[start:end + 1] for series in cumulative]
    else:
        print("data not enough, total length: ", len(times))
        # 截取窗口数据
        start = len(times) // 2 
        # start = best_start
        end = len(times)
        print(f"start: {start}, end: {end}")
        times = times[start:end + 1]
        total_used_blocks = total_used_blocks[start:end + 1]
        cumulative = [series[start:end + 1] for series in cumulative]
    # 若数据不足窗口，则使用全部

    plt.figure(figsize=FIG_SIZE)
    colors = plt.cm.tab20.colors  # 取前 N 个颜色

    # 绘制 stacked 折线（线之间填充）
    prev = [0] * len(times)
    for idx, agent in enumerate(agent_cols):
        curr = cumulative[idx]
        display_label = LABEL_DICT.get(agent, agent)
        plt.fill_between(times, prev, curr, color=colors[idx % len(colors)], alpha=0.5, label=display_label)
        prev = curr

    # 最上层总使用量黑线
    # plt.plot(times, total_used_blocks, color="black", linewidth=2, label="Total KV Cache Block Count")

    # ----------------- 标注若干总使用量比例点 -----------------
    num_labels = NOTATION_NUM
    if num_labels > 0 and len(times) > 1:
        t_start, t_end = times[0], times[-1]
        interval = (t_end - t_start) / (num_labels - 1) if num_labels > 1 else 0

        target_times = [t_start + i * interval for i in range(num_labels)]

        # 为每个目标时间找到最近的实际时间点索引
        for tgt in target_times:
            # 移动 idx 到离 tgt 最近的时间点
            idx = 0
            min_diff = float("inf")
            for i in range(len(times)):
                diff = abs(times[i] - tgt)
                if diff < min_diff:
                    min_diff = diff
                    idx = i

            while total_used_blocks[idx] == 0:
                idx += 1
                if idx >= len(times):
                    break
            x = times[idx]
            y = total_used_blocks[idx]
            ratio = y / TOTAL_BLOCKS * 100
            plt.scatter([x], [y], color="black", s=25, zorder=3)
            plt.text(x, y, f"{ratio:.1f}%", fontsize=TICK_SIZE, ha="center", va="bottom")

    plt.title("Underutilized Block Count")
    plt.xlabel("Elapsed Time (s)")
    plt.ylabel("KV Cache Block Count")
    # Y 轴最大值设为窗口内最大总使用
    max_value = max(max(series) for series in cumulative + [total_used_blocks])
    plt.ylim(0, max_value * 1.05)
    # 让图例放置在图内右上角，半透明背景
    plt.legend(loc="upper left", framealpha=0.9, fancybox=True)
    plt.tight_layout()

    OUTPUT_IMG.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(OUTPUT_IMG, dpi=FIG_DPI)
    print(f"Plot saved to {OUTPUT_IMG}")


if __name__ == "__main__":
    plot_utilization()
