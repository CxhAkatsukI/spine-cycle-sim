import os
import csv
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from typing import Dict, List

FIG_SIZE = (12, 8)

# 字体配置（保持与 gpu_memory_plot.py 一致）
FONT_FAMILY = ['Arial', 'DejaVu Sans', 'sans-serif']
FONT_SIZE_GENERAL = 18
FONT_SIZE_LABEL = 18
FONT_SIZE_TICK = 20
FONT_SIZE_LEGEND = 21
FONT_SIZE_ANNOTATION = 22
X_TICK_ROTATION = 0

COMBINE_LABEL_SIZE = 34
COMBINE_LEGEND_SIZE = 34
COMBINE_TICK_SIZE = 28
COMBINE_SUBTITLE_SIZE = 28

# 条形图样式
BAR_FACECOLOR = 'white'
BAR_EDGECOLOR = 'black'
BAR_WIDTH = 0.35
INTRA_GROUP_GAP = 0.0  # 组内间隙
BAR_EDGE_WIDTH = 3.0
BAR_ANNOTATION_OFFSET = 0.5
INTER_GROUP_SPACING = 1.4  # 组间距

# 网格样式
AXES_LINEWIDTH = 2
GRID_AXIS = 'y'  # 只显示Y轴网格
GRID_MAJOR_ENABLED = True
GRID_MAJOR_STYLE = '--'
GRID_MAJOR_COLOR = 'grey'
GRID_MAJOR_ALPHA = 0.7

# 刻度样式
TICK_DIRECTION = 'in'
TICK_LENGTH_MAJOR = 5
TICK_ON_TOP = True
TICK_ON_RIGHT = True
TICK_LABELS_ON_TOP = False
TICK_LABELS_ON_RIGHT = False

# 图例样式
LEGEND_FRAME_ON = False
LEGEND_HANDLETEXTPAD = 0.2
LEGEND_COLUMNSPACING = 0.8
LEGEND_HANDLE_LENGTH = 1.8
LEGEND_EDGE_WIDTH = 2
LEGEND_LOCATION = 'upper center'
LEGEND_BBOX_TO_ANCHOR = (0.5, 1.02)
LEGEND_NCOL = 3

# X轴边距（增大以让柱状图两侧留出更宽的白边）
X_AXIS_MARGIN = 0.03

LABEL_DICT = {
    "suncake": "SunCake",
    "vllm_base": "vLLM",
    "lightllm_base": "LightLLM",
    "other": "Other"
}

AGENT_DICT = {
    "architect": "Architect",
    "programmer": "Programmer",
    "reviser": "Reviser",
    "reviewer": "Reviewer",
    "conditional_execution": "Branch",
    "external_test": "Test",
    "external_tool_eval": "Eval",
    "file_query": "FileQuery",
    "file_write": "FileWrite",
    "search": "Search",
    "user_confirm": "UserConfirm",
    "text_generator": "TextGen",
    "img_generator": "ImgGen",
    "data_analysis": "DataAnalysis",
    "planner": "Planner",
    "summary": "Summary",
    "reflection": "Reflection",
}

COLORS = {
    "suncake": "#ff7f0e",
    "vllm_base": "#1f77b4",
    "lightllm_base": "#2ca02c",
    "other": "#984ea3"
}

HATCHES = {
    "suncake": "xxx",
    "vllm_base": "///",
    "lightllm_base": "\\\\\\",
    "other": "xxx"
}

# 引擎绘制顺序
ENGINE_ORDER = ["suncake", "vllm_base", "lightllm_base"]

CSV_INPUT_PATH = "data/agent_latency.csv"
OUTPUT_BASE_DIR = "img/agent_average"

# 应用全局样式设置
plt.style.use('default')
plt.rcParams.update({
    'font.size': FONT_SIZE_GENERAL,
    'axes.labelsize': FONT_SIZE_LABEL,
    'xtick.labelsize': FONT_SIZE_TICK,
    'ytick.labelsize': FONT_SIZE_TICK,
    'legend.fontsize': FONT_SIZE_LEGEND,
    'font.family': 'sans-serif',
    'font.sans-serif': FONT_FAMILY,
    'hatch.linewidth': 1,  # 填充图案线条宽度
    'axes.linewidth': AXES_LINEWIDTH,
    'axes.unicode_minus': False
})


def load_data_from_csv(csv_path: str):
    """加载 CSV，返回 {(model, task, qps, num_req, engine): {agent_type: {average_latency}}} 结构"""
    combos: Dict[tuple, Dict[str, Dict]] = {}

    with open(csv_path, newline="") as fp:
        reader = csv.DictReader(fp)
        for row in reader:
            model = row["model"]
            task = row["task"]
            qps = row["qps"]
            num_req = row["num_requests"]
            engine = row["engine"]

            combo_key = (model, task, qps, num_req, engine)

            agent_type = row["agent_type"]
            avg_latency = float(row["average_latency"])

            combos.setdefault(combo_key, {})[agent_type] = {"average_latency": avg_latency}

    return combos


def create_latency_comparison_chart(model: str, task: str, qps: str, num_requests: str,
                                   data_by_engine: Dict[str, Dict[str, float]], file_path: str):

    os.makedirs(os.path.dirname(file_path), exist_ok=True)

    # 仅保留 SunCake 最大延迟的前5个 agent_type
    sun_stats = data_by_engine.get("suncake", {})
    if sun_stats:
        top5 = sorted(sun_stats.items(), key=lambda x: x[1], reverse=True)[:5]
        selected_agent_types = [k for k, _ in top5]
    else:
        # 若无 suncake 数据，退化为所有 agent_type
        selected_agent_types = list({k for stats in data_by_engine.values() for k in stats.keys()})

    # 统一 agent type 列表使用上述筛选，并保持原顺序
    all_agent_types = selected_agent_types

    # agent type 显示标签
    display_labels = [AGENT_DICT.get(a.replace("mcp_", ""), a.replace("mcp_", "")) for a in all_agent_types]

    fig, ax = plt.subplots(figsize=FIG_SIZE)

    # X 轴位置: 每个 agent type 为一个组
    n_groups = len(all_agent_types)
    x_pos = [i * INTER_GROUP_SPACING for i in range(n_groups)]

    n_engines = len(ENGINE_ORDER)
    total_group_width = n_engines * BAR_WIDTH
    start_offset = -total_group_width / 2 + BAR_WIDTH / 2

    legend_handles = []

    for eng_idx, engine in enumerate(ENGINE_ORDER):
        eng_stats = data_by_engine.get(engine, {})
        latencies = [eng_stats.get(a, 0) for a in all_agent_types]

        color = COLORS.get(engine, COLORS["other"])
        hatch = HATCHES.get(engine, HATCHES["other"])

        bar_positions = [p + start_offset + eng_idx * BAR_WIDTH for p in x_pos]

        # 三层绘制
        base_bars = ax.bar(bar_positions, latencies, BAR_WIDTH,
                           facecolor=BAR_FACECOLOR, edgecolor='none', linewidth=0, zorder=1)

        ax.bar(bar_positions, latencies, BAR_WIDTH,
               facecolor='none', edgecolor=color, linewidth=0, hatch=hatch, zorder=2)

        ax.bar(bar_positions, latencies, BAR_WIDTH,
               facecolor='none', edgecolor=BAR_EDGECOLOR, linewidth=BAR_EDGE_WIDTH, zorder=3)

        # 图例
        legend_handles.append(mpatches.Patch(facecolor=BAR_FACECOLOR, edgecolor=color, hatch=hatch,
                                             label=LABEL_DICT.get(engine, engine), linewidth=LEGEND_EDGE_WIDTH))

        # 数值注释
        for bar, latency in zip(base_bars, latencies):
            if latency > 0:
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height + BAR_ANNOTATION_OFFSET,
                        f'{latency:.2f}s', ha='center', va='bottom', fontsize=FONT_SIZE_ANNOTATION, zorder=4)

    # 坐标轴配置
    ax.set_xlabel('Agent Type', fontsize=FONT_SIZE_LABEL)
    ax.set_ylabel('Average Latency(s)', fontsize=FONT_SIZE_LABEL)
    ax.set_xticks(x_pos)
    ax.set_xticklabels(display_labels, rotation=X_TICK_ROTATION, ha='center')

    title = f'Latency Comparison ({model}, {task}, QPS={qps}, Req={num_requests})'
    # ax.set_title(title, fontsize=FONT_SIZE_LABEL)

    # X 边距
    ax.margins(x=X_AXIS_MARGIN)

    # 图例
    ax.legend(handles=legend_handles, loc=LEGEND_LOCATION, frameon=LEGEND_FRAME_ON,
              handletextpad=LEGEND_HANDLETEXTPAD, columnspacing=LEGEND_COLUMNSPACING,
              handlelength=LEGEND_HANDLE_LENGTH, ncol=LEGEND_NCOL, bbox_to_anchor=LEGEND_BBOX_TO_ANCHOR)

    # 网格
    ax.grid(False, axis='both')
    ax.set_axisbelow(True)
    if GRID_MAJOR_ENABLED:
        ax.grid(True, axis=GRID_AXIS, which='major', linestyle=GRID_MAJOR_STYLE,
                color=GRID_MAJOR_COLOR, alpha=GRID_MAJOR_ALPHA, zorder=0)

    # 刻度
    ax.tick_params(axis='x', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                   top=TICK_ON_TOP, bottom=True, labeltop=TICK_LABELS_ON_TOP, labelbottom=True)
    ax.tick_params(axis='y', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                   right=TICK_ON_RIGHT, left=True, labelright=TICK_LABELS_ON_RIGHT, labelleft=True)
    ax.minorticks_off()
    for spine in ax.spines.values():
        spine.set_visible(True)

    plt.tight_layout()
    plt.savefig(file_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Saved latency comparison chart to {file_path}")


# ========= 子图绘制工具 =========

def _draw_latency_subplot(ax, task: str, data_by_engine: Dict[str, Dict[str, float]]):
    """在给定 ax 上绘制单个任务的 latency 条形图，返回 legend_handles"""

    # 替换任务名称
    task_display_name = "Code Writer" if task.lower() == "code" else "Deep Research"

    # 仅取 SunCake 最大延迟前5 agent_type
    sun_stats = data_by_engine.get("suncake", {})
    if sun_stats:
        top5 = sorted(sun_stats.items(), key=lambda x: x[1], reverse=True)[:4]
        agent_types = [k for k, _ in top5]
    else:
        agent_types = list({k for stats in data_by_engine.values() for k in stats.keys()})

    n_groups = len(agent_types)
    x_pos = [i * INTER_GROUP_SPACING for i in range(n_groups)]

    total_group_width = len(ENGINE_ORDER) * BAR_WIDTH
    start_offset = -total_group_width / 2 + BAR_WIDTH / 2

    legend_handles = []

    for eng_idx, engine in enumerate(ENGINE_ORDER):
        eng_stats = data_by_engine.get(engine, {})
        latencies = [eng_stats.get(a, 0) for a in agent_types]

        color = COLORS.get(engine, COLORS["other"])
        hatch = HATCHES.get(engine, HATCHES["other"])
        bar_positions = [p + start_offset + eng_idx * BAR_WIDTH for p in x_pos]

        base_bars = ax.bar(bar_positions, latencies, BAR_WIDTH, facecolor=BAR_FACECOLOR,
                           edgecolor='none', linewidth=0, zorder=1)
        ax.bar(bar_positions, latencies, BAR_WIDTH, facecolor='none', edgecolor=color,
               linewidth=0, hatch=hatch, zorder=2)
        ax.bar(bar_positions, latencies, BAR_WIDTH, facecolor='none', edgecolor=BAR_EDGECOLOR,
               linewidth=BAR_EDGE_WIDTH, zorder=3)

        legend_handles.append(mpatches.Patch(facecolor=BAR_FACECOLOR, edgecolor=color, hatch=hatch,
                                             label=LABEL_DICT.get(engine, engine), linewidth=LEGEND_EDGE_WIDTH))

        for bar, latency in zip(base_bars, latencies):
            if latency > 0:
                ax.text(bar.get_x() + bar.get_width()/2., latency + BAR_ANNOTATION_OFFSET,
                        f'{latency:.0f}', ha='center', va='bottom', fontsize=FONT_SIZE_ANNOTATION, zorder=4)

    # 调整 Y 轴上限，留出 15% 头部空间
    all_latencies = [v for stats in data_by_engine.values() for v in stats.values()]
    if all_latencies:
        max_latency = max(all_latencies)
        if max_latency > 800:
            ax.set_ylim(0, 1000)
        else:
            ax.set_ylim(0, 100)

    display_labels = [AGENT_DICT.get(a.replace("mcp_", ""), a.replace("mcp_", "")) for a in agent_types]
    ax.set_xticks(x_pos)
    ax.set_xticklabels(display_labels, rotation=X_TICK_ROTATION, ha='center', fontsize=COMBINE_TICK_SIZE)

    # 将标题移到子图下方
    ax.set_xlabel(task_display_name, fontsize=COMBINE_SUBTITLE_SIZE, labelpad=5)

    ax.margins(x=X_AXIS_MARGIN)
    ax.grid(False, axis='both')
    ax.set_axisbelow(True)
    if GRID_MAJOR_ENABLED:
        ax.grid(True, axis=GRID_AXIS, which='major', linestyle=GRID_MAJOR_STYLE,
                color=GRID_MAJOR_COLOR, alpha=GRID_MAJOR_ALPHA, zorder=0)

    ax.tick_params(axis='x', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                   top=TICK_ON_TOP, bottom=True, labeltop=TICK_LABELS_ON_TOP, labelbottom=True)
    ax.tick_params(axis='y', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                   right=TICK_ON_RIGHT, left=True, labelright=TICK_LABELS_ON_RIGHT, labelleft=True,
                   labelsize=COMBINE_TICK_SIZE)
    ax.minorticks_off()
    for spine in ax.spines.values():
        spine.set_visible(True)

    return legend_handles


def create_combined_latency_chart(
    model: str, 
    qps: str, 
    num_requests: str,
    code_data: Dict[str, Dict[str, float]],
    research_data: Dict[str, Dict[str, float]],
    file_path: str
):
    # 调整为上下布局
    combo_figsize = (FIG_SIZE[0] * 1.2, FIG_SIZE[1] * 1.8)
    fig, axs = plt.subplots(2, 1, figsize=combo_figsize)

    handles = _draw_latency_subplot(axs[0], "Code", code_data)
    _draw_latency_subplot(axs[1], "Research", research_data)

    # fig.supxlabel('Agent Type', fontsize=COMBINE_LABEL_SIZE, y=0.06)
    fig.supylabel('Average Latency(s)', fontsize=COMBINE_LABEL_SIZE, x=0.04)

    fig.legend(
        handles=handles,
        loc='upper center',
        bbox_to_anchor=(0.5, 1.0),
        frameon=LEGEND_FRAME_ON,
        handletextpad=LEGEND_HANDLETEXTPAD,
        columnspacing=LEGEND_COLUMNSPACING,
        handlelength=LEGEND_HANDLE_LENGTH,
        ncol=LEGEND_NCOL,
        prop={"size": COMBINE_LEGEND_SIZE},
    )

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    fig.subplots_adjust(hspace=0.25, wspace=0.12)

    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    plt.savefig(file_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Saved combined latency chart to {file_path}")

def plot_from_csv(csv_path: str = CSV_INPUT_PATH):
    records = load_data_from_csv(csv_path)

    # 以 (model, task, qps, num_req) 为 key，聚合各 engine 的 agent stats
    aggregated: Dict[tuple, Dict[str, Dict[str, float]]] = {}

    for (model, task, qps, num_req, engine), agent_stats in records.items():
        if float(qps) != 1.0 or int(num_req) not in {20, 30}:
            continue

        key = (model, task, qps, num_req)
        aggregated.setdefault(key, {})[engine] = {k: v["average_latency"] for k, v in agent_stats.items()}

    # 单任务图
    for (model, task, qps, num_req), data_by_engine in aggregated.items():
        output_dir = os.path.join(OUTPUT_BASE_DIR, f"{model}/{task}")
        file_path = os.path.join(output_dir, f"qps_{qps}_req_{num_req}.png")
        # create_latency_comparison_chart(model, task, qps, num_req, data_by_engine, file_path)

    # 组合 code & research
    for (model, qps, num_req) in {(m, q, n) for (m, t, q, n) in aggregated.keys()}:
        code_data = aggregated.get((model, "code", qps, num_req), {})
        research_data = aggregated.get((model, "research", qps, num_req), {})
        if code_data and research_data:
            combined_path = os.path.join(OUTPUT_BASE_DIR, f"{model}", f"agent_request_qps_{qps}_req_{num_req}.png")
            create_combined_latency_chart(model, qps, num_req, code_data, research_data, combined_path)


if __name__ == "__main__":
    plot_from_csv(CSV_INPUT_PATH)
