import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# --- 1. 数据读取与处理 ---
CSV_PATH = './data/scheduler_time.csv'
# 设置只选取前 n 行数据，若为 None 则使用全部数据
MAX_ITEMS = 5

df = pd.read_csv(CSV_PATH)
# 清理可能存在的空行
# 先去掉空行，然后根据 MAX_ITEMS 进行截取
_df_clean = df.dropna(how='any')

# 仅保留前 MAX_ITEMS 行（如果设置了值）
if MAX_ITEMS is not None:
    _df_clean = _df_clean.head(MAX_ITEMS)

test_nums = _df_clean['test_num'].astype(int).astype(str).tolist()
# 将秒转换为毫秒，便于与其它图保持一致
series_columns = ['offload_opt', 'upload_opt', 'offload_old', 'upload_old']
_df_ms = _df_clean.copy()
_df_ms[series_columns] = _df_clean[series_columns] * 1000  # 秒 -> 毫秒

SERIES_DATA = [(col, _df_ms[col].tolist()) for col in series_columns]
LABEL_DICT = {
    'offload_opt': 'Offload (Opt)',
    'upload_opt': 'Upload (Opt)',
    'offload_old': 'Offload (Baseline)',
    'upload_old': 'Upload (Baseline)',
}

# --- 2. 风格配置（大部分参考 plot_7_4） ---
TYPE_COLORS = {
    'offload_opt': '#ff7f0e',    # 橙色
    'upload_opt':  '#2ca02c',    # 绿色
    'offload_old': '#1f77b4',    # 蓝色
    'upload_old':  '#d62728',    # 红色
}

TYPE_HATCHES = {
    'offload_opt': 'xxx',
    'upload_opt': '\\\\',
    'offload_old': '///',
    'upload_old': '---',
}

BAR_FACECOLOR = 'white'
BAR_EDGECOLOR = 'black'

FIG_SIZE = (12, 7)
Y_LABEL = 'Time (ms, log scale)'
# 默认最小值 1，最大值会在绘图时根据数据动态调整
Y_LIMIT_MIN = 1

X_AXIS_MARGIN = 0.03

FONT_FAMILY = ['Arial', 'DejaVu Sans', 'sans-serif']
FONT_SIZE_GENERAL = 18
FONT_SIZE_LABEL = 26
FONT_SIZE_TICK = 22
FONT_SIZE_LEGEND = 24
FONT_SIZE_ANNOTATION = 20
X_TICK_ROTATION = 0

BAR_WIDTH = 0.25
INTRA_GROUP_GAP = 0.0
BAR_EDGE_WIDTH = 3.0
INTER_GROUP_SPACING = 1.2
BAR_ANNOTATION_OFFSET = 1  # 与 abnormal_compare 保持一致

AXES_LINEWIDTH = 2
GRID_AXIS = 'y'
GRID_MAJOR_ENABLED = True
GRID_MAJOR_STYLE = '--'
GRID_MAJOR_COLOR = 'grey'
GRID_MAJOR_ALPHA = 0.7

TICK_DIRECTION = 'in'
TICK_LENGTH_MAJOR = 5
TICK_ON_TOP = True
TICK_ON_RIGHT = True
TICK_LABELS_ON_TOP = False
TICK_LABELS_ON_RIGHT = False

LEGEND_LOCATION = 'upper center'
LEGEND_BBOX_TO_ANCHOR = (0.5, 0.98)  # figure 坐标系下的锚点
LEGEND_FRAME_ON = False
LEGEND_HANDLETEXTPAD = 0.2
LEGEND_COLUMNSPACING = 0.8
LEGEND_HANDLE_LENGTH = 1.8
LENGEND_EDGE_WIDTH = 2

TIGHT_LAYOUT_RECT = [0, 0.05, 1, 0.90]
IMG_PATH = "img/scheduler_time.png"


# --- 3. 绘图函数 ---

def create_scheduler_time_chart_log_scale():
    plt.style.use('default')
    plt.rcParams.update({
        'font.size': FONT_SIZE_GENERAL,
        'axes.labelsize': FONT_SIZE_LABEL,
        'xtick.labelsize': FONT_SIZE_TICK,
        'ytick.labelsize': FONT_SIZE_TICK,
        'legend.fontsize': FONT_SIZE_LEGEND,
        'font.family': 'sans-serif',
        'font.sans-serif': FONT_FAMILY,
        'hatch.linewidth': 1,
        'axes.linewidth': AXES_LINEWIDTH,
        'axes.unicode_minus': False,
    })

    n_categories = len(test_nums)
    n_series = len(SERIES_DATA)

    x_pos = [i * INTER_GROUP_SPACING for i in range(n_categories)]
    total_group_width = n_series * BAR_WIDTH
    start_offset = -total_group_width / 2 + BAR_WIDTH / 2

    fig, ax = plt.subplots(figsize=FIG_SIZE)
    legend_handles = []

    for i, (series_name, counts) in enumerate(SERIES_DATA):
        color = TYPE_COLORS.get(series_name)
        hatch = TYPE_HATCHES.get(series_name)
        bar_positions = [pos + start_offset + i * (BAR_WIDTH + INTRA_GROUP_GAP) for pos in x_pos]

        base_bars = ax.bar(bar_positions, counts, BAR_WIDTH, facecolor=BAR_FACECOLOR,
                           edgecolor='none', linewidth=0, zorder=1)
        ax.bar(bar_positions, counts, BAR_WIDTH, facecolor='none', edgecolor=color,
               linewidth=0, hatch=hatch, zorder=2)
        ax.bar(bar_positions, counts, BAR_WIDTH, facecolor='none', edgecolor=BAR_EDGECOLOR,
               linewidth=BAR_EDGE_WIDTH, hatch=None, zorder=3)

        legend_label = LABEL_DICT.get(series_name, series_name)
        patch = mpatches.Patch(facecolor=BAR_FACECOLOR, edgecolor=color, hatch=hatch,
                               label=legend_label, linewidth=LENGEND_EDGE_WIDTH)
        legend_handles.append(patch)

        for bar, value in zip(base_bars, counts):
            height = bar.get_height()
            display_value = f'{int(value)}' if value >= 100 else f'{value:.1f}'
            ax.text(bar.get_x() + bar.get_width() / 2., height + BAR_ANNOTATION_OFFSET,
                    display_value, ha='center', va='bottom', fontsize=FONT_SIZE_ANNOTATION, zorder=4)

    # --- 坐标轴与样式 ---
    ax.set_yscale('log')
    ax.set_ylabel(Y_LABEL)
    ax.set_xlabel('Test Block Num')
    # 动态设置 y 轴上限，留 20% 余量
    y_max_dynamic = max(max(vals) for _, vals in SERIES_DATA) * 3 # 增加上限余量，避免文字超出
    ax.set_ylim(Y_LIMIT_MIN, y_max_dynamic)
    ax.set_xticks(x_pos)
    ax.set_xticklabels(test_nums, rotation=X_TICK_ROTATION, ha='center')
    ax.margins(x=X_AXIS_MARGIN)

    for spine in ['top', 'right', 'bottom', 'left']:
        ax.spines[spine].set_visible(True)
        ax.spines[spine].set_linewidth(AXES_LINEWIDTH)
        ax.spines[spine].set_color('black')

    ax.tick_params(axis='x', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                   top=TICK_ON_TOP, bottom=True, labeltop=TICK_LABELS_ON_TOP, labelbottom=True)
    ax.tick_params(axis='y', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                   right=TICK_ON_RIGHT, left=True, labelright=TICK_LABELS_ON_RIGHT, labelleft=True)

    ax.minorticks_off()

    if GRID_MAJOR_ENABLED:
        ax.grid(True, axis=GRID_AXIS, which='major', linestyle=GRID_MAJOR_STYLE,
                color=GRID_MAJOR_COLOR, alpha=GRID_MAJOR_ALPHA, zorder=0)

    ax.legend(handles=legend_handles, loc=LEGEND_LOCATION, bbox_to_anchor=LEGEND_BBOX_TO_ANCHOR,
              bbox_transform=fig.transFigure,
              ncol=2, frameon=LEGEND_FRAME_ON, handletextpad=LEGEND_HANDLETEXTPAD,
              columnspacing=LEGEND_COLUMNSPACING, handlelength=LEGEND_HANDLE_LENGTH)

    fig.tight_layout(rect=TIGHT_LAYOUT_RECT)  # 新增，确保布局一致

    # 取消动态调整避免尺寸变化
    plt.savefig(IMG_PATH, format='png', dpi=300)  # 固定尺寸保存
    print(f"图表已保存到: {IMG_PATH}")


# --- 4. 执行入口 ---
if __name__ == '__main__':
    create_scheduler_time_chart_log_scale()
