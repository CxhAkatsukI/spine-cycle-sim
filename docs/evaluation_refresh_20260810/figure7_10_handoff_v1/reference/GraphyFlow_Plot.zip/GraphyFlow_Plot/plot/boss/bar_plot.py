import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# --- 配置常量 ---
# 系列数据和名称 (定义顺序): 每个元组包含 (系列名称, [数据值列表])
SERIES_DATA = [
    ('Baseline', [39.4, 37.5, 39.3, 38.7]),
    ('Cicero-6', [38.2, 36.8, 38.0, 37.7]),
    ('Cicero-16', [37.7, 36.5, 37.5, 37.2]),
    ('DS-2',  [37.6, 36.3, 37.5, 37.1]),
    ('Temp-16', [36.7, 36.0, 36.1, 36.3]),
]
# 系列样式: 包含样式字典的列表，顺序必须与 SERIES_DATA 严格对应
SERIES_STYLES = [
    {'hatch': '---', 'hatch_color': '#AAAAAA'}, # 系列1的样式
    {'hatch': '///', 'hatch_color': '#FFC000'}, # 系列2的样式
    {'hatch': '\\\\\\', 'hatch_color': '#00B050'}, # 系列3的样式
    {'hatch': '|||', 'hatch_color': '#C00000'}, # 系列4的样式
    {'hatch': 'xxx', 'hatch_color': '#7030A0'}  # 系列5的样式
]
# X轴类别名称: 用于 X 轴刻度标签的字符串列表
CATEGORIES = ['Instant-NGP', 'DirectVoxGO', 'TensoRF', 'Average']

BAR_FACECOLOR = 'white' # 条形图填充颜色
BAR_EDGECOLOR = 'black' # 条形图边框颜色

# --- 图形和坐标轴样式 ---
FIG_SIZE = (8.5, 3) # 图形尺寸 (英寸)
Y_LABEL = 'PSNR (dB)' # Y轴标签文本
Y_LIMITS = (30, 46) # Y轴显示范围 (最小值, 最大值)
Y_TICKS = [30, 35, 40, 45] # Y轴刻度线位置列表
X_AXIS_MARGIN = 0.01 # X轴左右边距 (占总宽度的比例)

# --- 字体配置 ---
FONT_FAMILY = ['Arial', 'DejaVu Sans', 'sans-serif'] # 字体系列 (优先使用列表中靠前的可用字体)
FONT_SIZE_GENERAL = 12 # 全局默认字体大小
FONT_SIZE_LABEL = 16 # 坐标轴标签字体大小
FONT_SIZE_TICK = 16 # 刻度标签字体大小
FONT_SIZE_LEGEND = 16 # 图例字体大小
FONT_SIZE_ANNOTATION = 12 # 条形图上方注释文字字体大小
X_TICK_ROTATION = 0 # X轴刻度标签旋转角度

# --- 条形图样式 ---
BAR_WIDTH = 0.2 # 单个条形的宽度
INTRA_GROUP_GAP = 0.0 # 同组内条形之间的间隙 (0表示边缘重叠)
BAR_EDGE_WIDTH = 1.5 # 条形图边框线宽
BAR_ANNOTATION_OFFSET = 0.2 # 注释文字距离条形顶部的垂直偏移量
INTER_GROUP_SPACING = 1.1 # 组中心点之间的距离 (控制组间距, >1.0 创建间隙)

# --- 可选的水平线 ---
HORIZONTAL_LINE_Y = None # 水平参考线Y坐标 (设置为 None 则不绘制)
HORIZONTAL_LINE_STYLE = '--' # 水平参考线样式 ('--', '-', ':', 等)
HORIZONTAL_LINE_WIDTH = 1.0 # 水平参考线宽度
HORIZONTAL_LINE_COLOR = 'grey' # 水平参考线颜色

# --- 网格样式 ---
AXES_LINEWIDTH = 2 # 坐标轴和边框线宽
GRID_AXIS = 'y' # 网格线应用于哪个轴 ('x', 'y', 'both')
GRID_MAJOR_ENABLED = True # 是否启用主网格线
GRID_MAJOR_STYLE = '--' # 主网格线样式
GRID_MAJOR_COLOR = 'grey' # 主网格线颜色
GRID_MAJOR_ALPHA = 0.7 # 主网格线透明度

# --- 刻度样式 ---
TICK_DIRECTION = 'in' # 刻度线方向 ('in', 'out', 'inout')
TICK_LENGTH_MAJOR = 5 # 主刻度线长度
TICK_LENGTH_MINOR = 2 # 次刻度线长度 (当前未启用次刻度)
TICK_ON_TOP = True # 是否在顶部显示X轴刻度线
TICK_ON_RIGHT = True # 是否在右侧显示Y轴刻度线
TICK_LABELS_ON_TOP = False # 是否在顶部显示X轴刻度标签
TICK_LABELS_ON_RIGHT = False # 是否在右侧显示Y轴刻度标签

# --- 图例样式 ---
LEGEND_NCOL = len(SERIES_DATA) # 图例列数 (根据系列数量自动计算)
LEGEND_LOCATION = 'lower center' # 图例位置 (字符串或元组)
LEGEND_BBOX_TO_ANCHOR = (0.5, 0.95) # 图例锚点 (精确定位图例框相对位置)
LEGEND_FRAME_ON = False # 是否显示图例边框
LEGEND_HANDLETEXTPAD = 0.2 # 图例句柄(图例中的样本)和文字的间距
LEGEND_COLUMNSPACING = 0.8 # 图例各列之间的间距
LEGEND_HANDLE_LENGTH = 1.8 # 图例句柄的长度
LENGEND_EDGE_WIDTH = 2 # 图例中样本图形的边框宽度

# --- 布局调整 ---
TIGHT_LAYOUT_RECT = [0, 0.05, 1, 0.90] # tight_layout 应用的矩形区域 [左, 底, 右, 顶] (归一化坐标)
SAVE_FILENAME = 'bar_chart_vector.pdf' # 保存图形的文件名 (推荐 .pdf, .svg 等矢量格式)

# --- 主绘图函数 ---
def create_bar_chart():
    """根据配置生成分组条形图，保存为矢量PDF并显示。"""

    # 1. 应用全局样式设置
    plt.style.use('default')
    plt.rcParams.update({
        'font.size': FONT_SIZE_GENERAL,
        'axes.labelsize': FONT_SIZE_LABEL,
        'xtick.labelsize': FONT_SIZE_TICK,
        'ytick.labelsize': FONT_SIZE_TICK,
        'legend.fontsize': FONT_SIZE_LEGEND,
        'font.family': 'sans-serif',
        'font.sans-serif': FONT_FAMILY,
        'hatch.linewidth': 1, # 填充图案线条宽度
        'axes.linewidth': AXES_LINEWIDTH
    })

    # 2. 准备数据和位置
    n_categories = len(CATEGORIES)
    n_series = len(SERIES_DATA)

    # 计算X轴各组中心位置
    x_pos = [i * INTER_GROUP_SPACING for i in range(n_categories)]

    # 计算每个系列条形的起始偏移量
    total_group_width = n_series * BAR_WIDTH
    start_offset = -total_group_width / 2 + BAR_WIDTH / 2

    # 3. 创建图形和坐标轴
    fig, ax = plt.subplots(figsize=FIG_SIZE)

    # 4. 绘制条形图和注释 (使用三次绘制技巧实现彩色填充图案和独立边框)
    legend_handles = []

    # 按照 SERIES_DATA 定义的顺序迭代
    for i, (series_name, values) in enumerate(SERIES_DATA):
        # 获取对应的样式
        style = SERIES_STYLES[i]
        # 计算当前系列所有条形的位置
        bar_positions = [pos + start_offset + i * BAR_WIDTH for pos in x_pos]

        # --- 绘制过程 1: 白色背景，无边框 (底层) ---
        base_bars = ax.bar(bar_positions, values, BAR_WIDTH,
                           facecolor=BAR_FACECOLOR,
                           edgecolor='none',
                           linewidth=0,
                           zorder=1)

        # --- 绘制过程 2: 透明背景，彩色填充图案 (中层) ---
        hatch_bars = ax.bar(bar_positions, values, BAR_WIDTH,
                            facecolor='none',
                            edgecolor=style['hatch_color'], # 填充图案颜色
                            linewidth=0,                    # 此层无线条边框
                            hatch=style['hatch'],           # 应用填充图案
                            zorder=2)

        # --- 绘制过程 3: 透明背景，黑色边框 (顶层) ---
        edge_bars = ax.bar(bar_positions, values, BAR_WIDTH,
                           facecolor='none',
                           edgecolor=BAR_EDGECOLOR,       # 最终的黑色边框
                           linewidth=BAR_EDGE_WIDTH,      # 边框宽度
                           hatch=None,                    # 此层不需填充图案
                           zorder=3)

        # --- 创建图例句柄 ---
        patch = mpatches.Patch(facecolor=BAR_FACECOLOR,
                               edgecolor=style['hatch_color'], # 图例样本边框使用填充色
                               hatch=style['hatch'],           # 图例样本使用填充图案
                               label=series_name,              # 使用系列名称作为标签
                               linewidth=LENGEND_EDGE_WIDTH)   # 图例样本边框宽度
        legend_handles.append(patch)

        # --- 在每个条形上方添加数值注释 ---
        for bar in base_bars: # 使用 base_bars 获取坐标和高度
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width() / 2., height + BAR_ANNOTATION_OFFSET,
                    f'{height:.1f}',                # 显示格式化后的数值
                    ha='center', va='bottom',       # 水平居中，垂直底部对齐
                    fontsize=FONT_SIZE_ANNOTATION,  # 注释字体大小
                    zorder=4)                       # 确保注释在最顶层

    # 5. 配置坐标轴外观
    ax.set_ylabel(Y_LABEL)
    ax.set_ylim(Y_LIMITS)
    ax.set_yticks(Y_TICKS)

    # 配置X轴刻度和标签
    ax.set_xticks(x_pos) # 在每个组的中心设置刻度
    ax.set_xticklabels(CATEGORIES, rotation=X_TICK_ROTATION, ha='center') # 设置标签文本和旋转
    ax.tick_params(axis='x', which='major', length=0) # 隐藏X轴主刻度线本身 (保留标签)

    # 调整X轴边距
    ax.margins(x=X_AXIS_MARGIN)

    # 确保所有坐标轴边框线可见
    for spine in ax.spines.values():
        spine.set_visible(True)

    # 6. 添加可选的水平参考线
    if HORIZONTAL_LINE_Y is not None:
        ax.axhline(HORIZONTAL_LINE_Y,
                   color=HORIZONTAL_LINE_COLOR,
                   linestyle=HORIZONTAL_LINE_STYLE,
                   linewidth=HORIZONTAL_LINE_WIDTH,
                   zorder=0) # 绘制在条形图之下

    # 7. 配置刻度线外观
    # X轴主刻度
    ax.tick_params(axis='x', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                    top=TICK_ON_TOP, bottom=False, # bottom=False隐藏底部刻度线
                    labeltop=TICK_LABELS_ON_TOP, labelbottom=True)
    # Y轴主刻度
    ax.tick_params(axis='y', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                    right=TICK_ON_RIGHT, left=True,
                    labelright=TICK_LABELS_ON_RIGHT, labelleft=True)

    # 关闭次刻度
    ax.minorticks_off()

    # 8. 配置网格线
    ax.grid(False, axis='both', which='both') # 先禁用所有网格
    ax.set_axisbelow(True) # 关键：确保网格线绘制在图形元素下方
    if GRID_MAJOR_ENABLED:
        ax.grid(True, axis=GRID_AXIS, which='major',
                linestyle=GRID_MAJOR_STYLE,
                color=GRID_MAJOR_COLOR,
                alpha=GRID_MAJOR_ALPHA,
                zorder=0) # zorder=0 配合 set_axisbelow

    # 9. 创建图例
    ax.legend(handles=legend_handles,
              loc=LEGEND_LOCATION,
              bbox_to_anchor=LEGEND_BBOX_TO_ANCHOR,
              ncol=LEGEND_NCOL,
              frameon=LEGEND_FRAME_ON,
              handletextpad=LEGEND_HANDLETEXTPAD,
              columnspacing=LEGEND_COLUMNSPACING,
              handlelength=LEGEND_HANDLE_LENGTH)

    # 10. 最终布局调整
    fig.tight_layout(rect=TIGHT_LAYOUT_RECT) # 应用 tight_layout 并限制区域

    # 11. 保存和显示图形
    plt.savefig(SAVE_FILENAME, format='pdf', bbox_inches='tight') # bbox_inches='tight' 裁剪边缘空白
    print(f"图形已保存为矢量PDF: {SAVE_FILENAME}")
    plt.show()

# --- 执行入口 ---
if __name__ == "__main__":
    create_bar_chart()