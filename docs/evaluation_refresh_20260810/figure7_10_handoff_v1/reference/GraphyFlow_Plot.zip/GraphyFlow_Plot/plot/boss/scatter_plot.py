import matplotlib.pyplot as plt

# --- Configuration Constants ---

# Series data and names: Each tuple contains (series_name, [(x1, y1), (x2, y2), ...])
# Note: X values can differ between series.
SERIES_DATA = [
    ('Experiment A', [(1, 39.4), (2, 37.5), (3.5, 39.3), (4, 38.7)]),
    ('Experiment B', [(1.1, 38.2), (2.2, 36.8), (3.0, 38.0), (4.1, 37.7)]),
    ('Experiment C', [(0.9, 37.7), (1.8, 36.5), (3.2, 37.5), (3.9, 37.2)]),
    ('Simulation 1', [(1.5, 37.6), (2.5, 36.3), (3.6, 37.5), (4.5, 37.1)]),
    ('Simulation 2', [(0.8, 36.7), (2.1, 36.0), (2.9, 36.1), (4.2, 36.3)]),
]

# --- Scatter Plot Styles ---
# Define markers and colors for each series, order must match SERIES_DATA
SERIES_MARKERS = ['o', 's', '^', 'D', 'X', 'P', '*'] # Add more if needed: circle, square, triangle_up, diamond, x, plus (filled), star
SERIES_COLORS = ['#377eb8', '#ff7f00', '#4daf4a', '#f781bf', '#a65628', '#984ea3', '#999999'] # Example color palette (Colorbrewer Set1)
MARKER_SIZE = 70       # Size of the scatter markers
MARKER_EDGECOLOR = 'black' # Color of the marker edges (set to None for no edge)
MARKER_EDGEWIDTH = 1.0   # Width of the marker edges

# --- Figure and Axes Style ---
FIG_SIZE = (8.5, 4)     # Figure size (inches) - Adjusted height slightly
X_LABEL = 'Time (s)'    # X-axis label text <<< SET YOUR X-AXIS LABEL
Y_LABEL = 'PSNR (dB)'   # Y-axis label text
# Optional: Set fixed limits, otherwise let Matplotlib determine them automatically
X_LIMITS = None #(0, 5)      # X-axis display range (min, max) or None
Y_LIMITS = (30, 46)     # Y-axis display range (min, max). Adjust if using log scale!
# Optional: Set specific ticks, otherwise let Matplotlib determine them
X_TICKS = None #[0, 1, 2, 3, 4, 5] # X-axis tick locations or None
Y_TICKS = [30, 35, 40, 45] # Y-axis tick locations. May need adjustment for log scale.
Y_AXIS_LOG_SCALE = False # <<< SET TO True FOR LOGARITHMIC Y-AXIS <<<
X_AXIS_MARGIN = 0.05    # X-axis left/right margin (proportion of total width)

# --- Font Configuration ---
FONT_FAMILY = ['Arial', 'DejaVu Sans', 'sans-serif']
FONT_SIZE_GENERAL = 12
FONT_SIZE_LABEL = 16
FONT_SIZE_TICK = 16
FONT_SIZE_LEGEND = 16
# X_TICK_ROTATION removed, generally not needed for numerical axes

# --- Optional Horizontal Line ---
HORIZONTAL_LINE_Y = None #38.0
HORIZONTAL_LINE_STYLE = '--'
HORIZONTAL_LINE_WIDTH = 1.0
HORIZONTAL_LINE_COLOR = 'grey'

# --- Grid Style ---
AXES_LINEWIDTH = 2
GRID_AXIS = 'y'         # Apply grid to 'x', 'y', or 'both'
GRID_MAJOR_ENABLED = True
GRID_MAJOR_STYLE = '--'
GRID_MAJOR_COLOR = 'grey'
GRID_MAJOR_ALPHA = 0.7

# --- Tick Style ---
TICK_DIRECTION = 'in'
TICK_LENGTH_MAJOR = 5
TICK_LENGTH_MINOR = 2 # (Currently unused as minorticks_off() is called)
TICK_ON_TOP = True      # Show ticks on top axis line
TICK_ON_RIGHT = True    # Show ticks on right axis line
TICK_LABELS_ON_TOP = False # Show tick labels on top axis
TICK_LABELS_ON_RIGHT = False # Show tick labels on right axis

# --- Legend Style ---
LEGEND_NCOL = 1 #len(SERIES_DATA) # Adjust number of columns as needed
LEGEND_LOCATION = 'lower center' #'best' # Consider 'best' or fine-tune location
LEGEND_BBOX_TO_ANCHOR = (0.5, 1.02) # Position legend above plot (adjust as needed)
LEGEND_FRAME_ON = False
LEGEND_HANDLETEXTPAD = 0.4 # Spacing between marker and text
LEGEND_COLUMNSPACING = 0.8 # Spacing between columns (if LEGEND_NCOL > 1)
LEGEND_HANDLE_LENGTH = 1.0 # Length of the line/marker in the legend
LEGEND_SCATTERPOINTS = 1   # Number of markers per legend entry

# --- Layout Adjustment ---
TIGHT_LAYOUT_RECT = [0, 0, 1, 0.95] # Area for tight_layout [left, bottom, right, top] - adjust top to make space for legend if above

# --- Output Filename ---
SAVE_FILENAME = "scatter_plot_vector.pdf" # Specific filename

# --- Main Plotting Function ---
def create_scatter_plot():
    """Generates a scatter plot based on the configuration."""

    # 1. Apply Global Style Settings
    plt.style.use('default')
    plt.rcParams.update({
        'font.size': FONT_SIZE_GENERAL,
        'axes.labelsize': FONT_SIZE_LABEL,
        'xtick.labelsize': FONT_SIZE_TICK,
        'ytick.labelsize': FONT_SIZE_TICK,
        'legend.fontsize': FONT_SIZE_LEGEND,
        'font.family': 'sans-serif',
        'font.sans-serif': FONT_FAMILY,
        'axes.linewidth': AXES_LINEWIDTH
    })

    # 2. Create Figure and Axes
    fig, ax = plt.subplots(figsize=FIG_SIZE)

    # 3. Plotting Logic - Iterate through series and plot scatter points
    if len(SERIES_MARKERS) < len(SERIES_DATA) or len(SERIES_COLORS) < len(SERIES_DATA):
        print("Warning: Not enough unique markers or colors defined for all series. Styles will repeat.")

    for i, (series_name, data_points) in enumerate(SERIES_DATA):
        if not data_points: # Skip empty series
             print(f"Warning: Series '{series_name}' has no data points. Skipping.")
             continue

        # Extract x and y values, handling potential errors
        try:
            x_values = [p[0] for p in data_points]
            y_values = [p[1] for p in data_points]
        except (IndexError, TypeError) as e:
            print(f"Error processing data for series '{series_name}': {e}. Ensure data is a list of (x, y) tuples/lists.")
            continue # Skip this series if data is malformed

        ax.scatter(x_values, y_values,
                   s=MARKER_SIZE,
                   marker=SERIES_MARKERS[i % len(SERIES_MARKERS)], # Cycle through markers
                   color=SERIES_COLORS[i % len(SERIES_COLORS)],   # Cycle through colors
                   edgecolor=MARKER_EDGECOLOR,
                   linewidth=MARKER_EDGEWIDTH,
                   label=series_name,             # Label for automatic legend
                   zorder=3)                      # Ensure points are above grid

    # 4. Configure Axes Appearance
    ax.set_xlabel(X_LABEL)
    ax.set_ylabel(Y_LABEL)

    if X_LIMITS:
        ax.set_xlim(X_LIMITS)
    if Y_LIMITS:
        ax.set_ylim(Y_LIMITS)

    # Set y-axis scale (linear or log)
    if Y_AXIS_LOG_SCALE:
        ax.set_yscale('log')
        # Ensure Y_LIMITS are positive for log scale if set manually
        current_ylim = ax.get_ylim()
        if current_ylim[0] <= 0:
            print(f"Warning: Bottom Y limit ({current_ylim[0]}) is non-positive, which is invalid for log scale. Adjusting.")
            # Attempt to find a reasonable minimum from data > 0
            all_positive_y = [p[1] for s in SERIES_DATA for p in s[1] if p[1] > 0]
            new_bottom = min(all_positive_y) * 0.8 if all_positive_y else 0.1 # Fallback if no positive data
            ax.set_ylim(bottom=new_bottom)
            print(f"Bottom Y limit adjusted to {ax.get_ylim()[0]:.2g}")
    else:
        ax.set_yscale('linear') # Explicitly set linear scale
        if Y_TICKS:
            ax.set_yticks(Y_TICKS) # Set specific ticks only if defined

    # Set X ticks if specifically provided
    if X_TICKS:
        ax.set_xticks(X_TICKS)

    # Adjust X-axis margins
    ax.margins(x=X_AXIS_MARGIN)

    # Ensure all spines (axes frame lines) are visible
    for spine in ax.spines.values():
        spine.set_visible(True)

    # 5. Add Optional Horizontal Reference Line
    if HORIZONTAL_LINE_Y is not None:
        ax.axhline(HORIZONTAL_LINE_Y, color=HORIZONTAL_LINE_COLOR,
                   linestyle=HORIZONTAL_LINE_STYLE, linewidth=HORIZONTAL_LINE_WIDTH,
                   zorder=0) # Draw behind plot elements

    # 6. Configure Tick Appearance
    ax.tick_params(axis='x', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                   top=TICK_ON_TOP, bottom=True, # Keep bottom ticks visible
                   labeltop=TICK_LABELS_ON_TOP, labelbottom=True)
    ax.tick_params(axis='y', which='major', direction=TICK_DIRECTION, length=TICK_LENGTH_MAJOR,
                   right=TICK_ON_RIGHT, left=True,
                   labelright=TICK_LABELS_ON_RIGHT, labelleft=True)
    ax.minorticks_off() # Disable minor ticks by default

    # 7. Configure Grid Lines
    ax.grid(False, axis='both', which='both') # Disable all grids first
    ax.set_axisbelow(True) # Ensure grid is behind data points
    if GRID_MAJOR_ENABLED:
        ax.grid(True, axis=GRID_AXIS, which='major',
                linestyle=GRID_MAJOR_STYLE, color=GRID_MAJOR_COLOR,
                alpha=GRID_MAJOR_ALPHA, zorder=0)

    # 8. Create Legend
    legend_options = {
        'loc': LEGEND_LOCATION,
        'bbox_to_anchor': LEGEND_BBOX_TO_ANCHOR,
        'ncol': LEGEND_NCOL,
        'frameon': LEGEND_FRAME_ON,
        'handletextpad': LEGEND_HANDLETEXTPAD,
        'columnspacing': LEGEND_COLUMNSPACING,
        'handlelength': LEGEND_HANDLE_LENGTH,
        'scatterpoints': LEGEND_SCATTERPOINTS # Number of markers in legend
    }
    ax.legend(**legend_options)

    # 9. Final Layout Adjustment
    try:
        # Adjust rect argument in tight_layout based on legend position
        fig.tight_layout(rect=TIGHT_LAYOUT_RECT)
    except ValueError:
        print("Warning: tight_layout failed, possibly due to extreme Bbox limits or overlapping elements. Falling back to default tight_layout.")
        fig.tight_layout() # Apply default tight layout as a fallback


    # 10. Save and Show Figure
    plt.savefig(SAVE_FILENAME, format='pdf', bbox_inches='tight', dpi=300) # Added dpi for potential raster parts in PDF
    print(f"Scatter plot saved as vector PDF: {SAVE_FILENAME}")
    plt.show()

# --- Execution Entry Point ---
if __name__ == "__main__":
    create_scatter_plot()
