
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [0:0] axis_block_sigs;
wire [6:0] inst_idle_sigs;
wire [2:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~grp_cross_row_pipeline_fu_158.publish_row_segments_U0.grp_publish_row_segments_Pipeline_publish_half_loop_fu_110.edge_burst_out_TDATA_blk_n;

assign inst_idle_sigs[0] = grp_cross_row_pipeline_fu_158.entry_proc_U0.ap_idle;
assign inst_block_sigs[0] = (grp_cross_row_pipeline_fu_158.entry_proc_U0.ap_done & ~grp_cross_row_pipeline_fu_158.entry_proc_U0.ap_continue) | ~grp_cross_row_pipeline_fu_158.entry_proc_U0.part_vertex_count_c_blk_n;
assign inst_idle_sigs[1] = grp_cross_row_pipeline_fu_158.read_row_segments_U0.ap_idle;
assign inst_block_sigs[1] = (grp_cross_row_pipeline_fu_158.read_row_segments_U0.ap_done & ~grp_cross_row_pipeline_fu_158.read_row_segments_U0.ap_continue) | ~grp_cross_row_pipeline_fu_158.read_row_segments_U0.loaded_blk_n | ~grp_cross_row_pipeline_fu_158.read_row_segments_U0.grp_read_row_segments_Pipeline_read_cached_sources_loop_fu_220.loaded_blk_n;
assign inst_idle_sigs[2] = grp_cross_row_pipeline_fu_158.publish_row_segments_U0.ap_idle;
assign inst_block_sigs[2] = (grp_cross_row_pipeline_fu_158.publish_row_segments_U0.ap_done & ~grp_cross_row_pipeline_fu_158.publish_row_segments_U0.ap_continue) | ~grp_cross_row_pipeline_fu_158.publish_row_segments_U0.loaded_blk_n | ~grp_cross_row_pipeline_fu_158.publish_row_segments_U0.part_vertex_count_blk_n;

assign inst_idle_sigs[3] = 1'b0;
assign inst_idle_sigs[4] = grp_cross_row_pipeline_fu_158.ap_idle;
assign inst_idle_sigs[5] = grp_cross_row_pipeline_fu_158.publish_row_segments_U0.ap_idle;
assign inst_idle_sigs[6] = grp_cross_row_pipeline_fu_158.publish_row_segments_U0.grp_publish_row_segments_Pipeline_publish_half_loop_fu_110.ap_idle;

pma_to_regraph_adapter_hls_deadlock_idx0_monitor pma_to_regraph_adapter_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
