run all
quit
