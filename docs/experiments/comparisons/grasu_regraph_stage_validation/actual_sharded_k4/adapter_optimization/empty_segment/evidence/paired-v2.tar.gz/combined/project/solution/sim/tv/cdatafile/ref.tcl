set depth_list {
  {edge_burst_out_V_data_V 60}
  {edge_burst_out_V_keep_V 60}
  {edge_burst_out_V_last_V 60}
  {edge_burst_out_V_strb_V 60}
  {gmem0 1153}
  {max_cache_segment 1}
  {node_count 1}
  {part_dst_offset 1}
  {part_vertex_count 1}
  {pma0 1}
  {pma1 1}
  {pma2 1}
  {pma3 1}
  {pma_slot_count 1}
  {row_offset 1}
}
set trans_num 13
