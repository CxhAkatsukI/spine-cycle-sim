<AutoPilot:project xmlns:AutoPilot="com.autoesl.autopilot.project" projectType="C/C++" name="project" ideType="classic" top="pma_to_regraph_adapter">
    <files>
        <file name="../../../../../../home/chuxiao/grasu-regraph-integration/kernels/pma_to_regraph_adapter/pma_to_regraph_adapter.cpp" sc="0" tb="false" cflags="-D_GTHREAD_USE_COND_INIT_FUNC -DGRASU_REGRAPH_COSIM_DEPTH=1 -DGRASU_REGRAPH_SHARDED_PMA=1 -DGRASU_REGRAPH_SHARE_ALL_MEMORY_PORTS=1 -DGRASU_REGRAPH_ROW_PREFETCH=1 -DGRASU_REGRAPH_STOP_AFTER_LAST=1 -I/data/yxx/tools/xilinx/Vitis_HLS/2024.1/include/etc -DGRASU_REGRAPH_SKIP_EMPTY_SEGMENT=1 -DGRASU_REGRAPH_WEIGHTED_PMA=1" csimflags="" blackbox="false"/>
        <file name="../../../../../../../../home/chuxiao/grasu-regraph-integration/tests/pma_adapter_cosim_tb.cpp" sc="0" tb="1" cflags="-D_GTHREAD_USE_COND_INIT_FUNC -DGRASU_REGRAPH_COSIM_DEPTH=1 -DGRASU_REGRAPH_SHARDED_PMA=1 -DGRASU_REGRAPH_SHARE_ALL_MEMORY_PORTS=1 -DGRASU_REGRAPH_ROW_PREFETCH=1 -DGRASU_REGRAPH_STOP_AFTER_LAST=1 -I/data/yxx/tools/xilinx/Vitis_HLS/2024.1/include/etc -DGRASU_REGRAPH_SKIP_EMPTY_SEGMENT=1 -DGRASU_REGRAPH_WEIGHTED_PMA=1 -Wno-unknown-pragmas" csimflags="" blackbox="false"/>
    </files>
    <solutions>
        <solution name="solution" status=""/>
    </solutions>
    <Simulation argv="">
        <SimFlow name="csim" setup="false" optimizeCompile="false" clean="false" ldflags="-Wl,--threads=2" mflags=""/>
    </Simulation>
</AutoPilot:project>

