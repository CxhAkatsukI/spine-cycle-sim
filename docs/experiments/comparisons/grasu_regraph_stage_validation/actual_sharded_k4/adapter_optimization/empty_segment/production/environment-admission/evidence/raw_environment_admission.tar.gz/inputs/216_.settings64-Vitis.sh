##############################################################
# Copyright (c) 1986-2025 Xilinx, Inc.  All rights reserved. #
##############################################################

export XILINX_VITIS=/data/yxx/tools/xilinx/Vitis/2024.1
if [ -n "${PATH}" ]; then
  export PATH=/data/yxx/tools/xilinx/Vitis/2024.1/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/microblaze/lin/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/microblaze/linux_toolchain/lin64_le/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/aarch32/lin/gcc-arm-linux-gnueabi/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/aarch32/lin/gcc-arm-none-eabi/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/aarch64/lin/aarch64-linux/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/aarch64/lin/aarch64-none/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/armr5/lin/gcc-arm-none-eabi/bin:/data/yxx/tools/xilinx/Vitis/2024.1/aietools/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/riscv/lin/riscv64-unknown-elf/bin:$PATH
else
  export PATH=/data/yxx/tools/xilinx/Vitis/2024.1/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/microblaze/lin/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/microblaze/linux_toolchain/lin64_le/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/aarch32/lin/gcc-arm-linux-gnueabi/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/aarch32/lin/gcc-arm-none-eabi/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/aarch64/lin/aarch64-linux/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/aarch64/lin/aarch64-none/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/armr5/lin/gcc-arm-none-eabi/bin:/data/yxx/tools/xilinx/Vitis/2024.1/aietools/bin:/data/yxx/tools/xilinx/Vitis/2024.1/gnu/riscv/lin/riscv64-unknown-elf/bin
fi
