##############################################################
# Copyright (c) 1986-2025 Xilinx, Inc.  All rights reserved. #
##############################################################

export XILINX_HLS=/data/yxx/tools/xilinx/Vitis_HLS/2024.1
if [ -n "${PATH}" ]; then
  export PATH=/data/yxx/tools/xilinx/Vitis_HLS/2024.1/bin:$PATH
else
  export PATH=/data/yxx/tools/xilinx/Vitis_HLS/2024.1/bin
fi
