#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/env.sh"

HLS_INCLUDE="${HLS_INCLUDE:-/data/yxx/tools/xilinx/Vitis_HLS/2024.1/include}"
HLS_INCLUDE_ETC="${HLS_INCLUDE_ETC:-${HLS_INCLUDE}/etc}"
OUT_DIR=""

usage() {
  cat <<USAGE
Usage: $0 [--out-dir PATH]

Compile and execute legacy-unit, weighted-PMA, and destination-only C++ tests for the
PMA-to-ReGraph adapter using the Vitis HLS headers. This does not synthesize an
XO.
USAGE
}

abs_path() {
  case "$1" in
    /*) printf '%s\n' "$1" ;;
    *) printf '%s/%s\n' "${PWD}" "$1" ;;
  esac
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --out-dir) OUT_DIR="$(abs_path "$2")"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [[ ! -d "${HLS_INCLUDE}" ]]; then
  echo "Missing Vitis HLS include directory: ${HLS_INCLUDE}" >&2
  exit 1
fi
if [[ ! -d "${HLS_INCLUDE_ETC}" ]]; then
  echo "Missing Vitis HLS include/etc directory: ${HLS_INCLUDE_ETC}" >&2
  exit 1
fi

if [[ -z "${OUT_DIR}" ]]; then
  OUT_DIR="${GRI_ROOT}/.tmp_build/pma_to_regraph_adapter_check_$(date +%Y%m%d_%H%M%S)"
fi
mkdir -p "${OUT_DIR}"

SRC="${GRI_ROOT}/kernels/pma_to_regraph_adapter/pma_to_regraph_adapter.cpp"
TB="${GRI_ROOT}/tests/pma_to_regraph_adapter_tb.cpp"
LEGACY_EXE="${OUT_DIR}/pma_to_regraph_adapter_legacy_test"
WEIGHTED_EXE="${OUT_DIR}/pma_to_regraph_adapter_weighted_test"
DESTINATION_EXE="${OUT_DIR}/pma_to_regraph_adapter_destination_test"
SHARDED_WEIGHTED_EXE="${OUT_DIR}/pma_to_regraph_adapter_sharded_weighted_test"
SHARDED_DESTINATION_EXE="${OUT_DIR}/pma_to_regraph_adapter_sharded_destination_test"
SHARED_MASTER_EXE="${OUT_DIR}/pma_to_regraph_adapter_shared_master_test"
LOG="${OUT_DIR}/test.log"

{
  echo "timestamp=$(date -Is)"
  echo "GRI_ROOT=${GRI_ROOT}"
  echo "HLS_INCLUDE=${HLS_INCLUDE}"
  echo "HLS_INCLUDE_ETC=${HLS_INCLUDE_ETC}"
  echo "SRC=${SRC}"
  echo "TB=${TB}"
  echo "LEGACY_EXE=${LEGACY_EXE}"
  echo "WEIGHTED_EXE=${WEIGHTED_EXE}"
  echo "DESTINATION_EXE=${DESTINATION_EXE}"
  echo "SHARDED_WEIGHTED_EXE=${SHARDED_WEIGHTED_EXE}"
  echo "SHARDED_DESTINATION_EXE=${SHARDED_DESTINATION_EXE}"
  echo "SHARED_MASTER_EXE=${SHARED_MASTER_EXE}"
} > "${OUT_DIR}/manifest.env"

if ! {
  g++ -std=c++17 -w \
    -I"${HLS_INCLUDE}" \
    -I"${HLS_INCLUDE_ETC}" \
    "${TB}" \
    -o "${LEGACY_EXE}"
  "${LEGACY_EXE}"

  g++ -std=c++17 -w \
    -DGRASU_REGRAPH_WEIGHTED_PMA=1 \
    -I"${HLS_INCLUDE}" \
    -I"${HLS_INCLUDE_ETC}" \
    "${TB}" \
    -o "${WEIGHTED_EXE}"
  "${WEIGHTED_EXE}"

  g++ -std=c++17 -w \
    -DGRASU_REGRAPH_DESTINATION_ONLY=1 \
    -I"${HLS_INCLUDE}" \
    -I"${HLS_INCLUDE_ETC}" \
    "${TB}" \
    -o "${DESTINATION_EXE}"
  "${DESTINATION_EXE}"

  g++ -std=c++17 -w \
    -DGRASU_REGRAPH_WEIGHTED_PMA=1 \
    -DGRASU_REGRAPH_SHARDED_PMA=1 \
    -I"${HLS_INCLUDE}" \
    -I"${HLS_INCLUDE_ETC}" \
    "${TB}" \
    -o "${SHARDED_WEIGHTED_EXE}"
  "${SHARDED_WEIGHTED_EXE}"

  g++ -std=c++17 -w \
    -DGRASU_REGRAPH_DESTINATION_ONLY=1 \
    -DGRASU_REGRAPH_SHARDED_PMA=1 \
    -I"${HLS_INCLUDE}" \
    -I"${HLS_INCLUDE_ETC}" \
    "${TB}" \
    -o "${SHARDED_DESTINATION_EXE}"
  "${SHARDED_DESTINATION_EXE}"

  g++ -std=c++17 -w \
    -DGRASU_REGRAPH_WEIGHTED_PMA=1 \
    -DGRASU_REGRAPH_SHARDED_PMA=1 \
    -DGRASU_REGRAPH_SHARE_ALL_MEMORY_PORTS=1 \
    -I"${HLS_INCLUDE}" \
    -I"${HLS_INCLUDE_ETC}" \
    "${TB}" \
    -o "${SHARED_MASTER_EXE}"
  "${SHARED_MASTER_EXE}"

  for mode in weighted destination unit; do
    case "${mode}" in
      weighted) row_defines=(-DGRASU_REGRAPH_WEIGHTED_PMA=1) ;;
      destination) row_defines=(-DGRASU_REGRAPH_WEIGHTED_PMA=0 -DGRASU_REGRAPH_DESTINATION_ONLY=1) ;;
      unit) row_defines=(-DGRASU_REGRAPH_WEIGHTED_PMA=0) ;;
    esac
    g++ -std=c++17 -w "${row_defines[@]}" \
      -I"${HLS_INCLUDE}" -I"${HLS_INCLUDE_ETC}" \
      "${GRI_ROOT}/tests/pma_adapter_row_prefetch_tb.cpp" \
      -o "${OUT_DIR}/row_prefetch_${mode}_test"
    "${OUT_DIR}/row_prefetch_${mode}_test"
    g++ -std=c++17 -w "${row_defines[@]}" \
      -DPMA_ADAPTER_TEST_SKIP_EMPTY=1 \
      -I"${HLS_INCLUDE}" -I"${HLS_INCLUDE_ETC}" \
      "${GRI_ROOT}/tests/pma_adapter_row_prefetch_tb.cpp" \
      -o "${OUT_DIR}/skip_empty_${mode}_test"
    "${OUT_DIR}/skip_empty_${mode}_test"
  done
} > "${LOG}" 2>&1; then
  cat "${LOG}" >&2
  exit 1
fi

{
  sha256sum "${SRC}"
  sha256sum "${TB}"
  sha256sum "${LEGACY_EXE}"
  sha256sum "${WEIGHTED_EXE}"
  sha256sum "${DESTINATION_EXE}"
  sha256sum "${SHARDED_WEIGHTED_EXE}"
  sha256sum "${SHARDED_DESTINATION_EXE}"
  sha256sum "${SHARED_MASTER_EXE}"
  sha256sum "${GRI_ROOT}/kernels/pma_to_regraph_adapter/row_prefetch.hpp"
  sha256sum "${GRI_ROOT}/tests/pma_adapter_row_prefetch_tb.cpp"
  sha256sum "${OUT_DIR}"/row_prefetch_*_test
  sha256sum "${OUT_DIR}"/skip_empty_*_test
  sha256sum "${LOG}"
} > "${OUT_DIR}/SHA256SUMS"

echo "PMA-to-ReGraph adapter legacy, weighted, and destination-only tests passed:"
echo "  ${OUT_DIR}"
