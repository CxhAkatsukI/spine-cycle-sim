##############################################################
# Copyright (c) 1986-2025 Xilinx, Inc.  All rights reserved. #
##############################################################

source /data/yxx/tools/xilinx/DocNav/.settings64-DocNav.sh
source /data/yxx/tools/xilinx/Vivado/2024.1/.settings64-Vivado.sh
source /data/yxx/tools/xilinx/Vitis/2024.1/.settings64-Vitis.sh
source /data/yxx/tools/xilinx/Model_Composer/2024.1/.settings64-Model_Composer.sh
source /data/yxx/tools/xilinx/Vitis_HLS/2024.1/.settings64-Vitis_HLS.sh
