##############################################################
# Copyright (c) 1986-2025 Xilinx, Inc.  All rights reserved. #
##############################################################

if [ -n "${PATH}" ]; then
  export PATH=/data/yxx/tools/xilinx/DocNav:$PATH
else
  export PATH=/data/yxx/tools/xilinx/DocNav
fi
