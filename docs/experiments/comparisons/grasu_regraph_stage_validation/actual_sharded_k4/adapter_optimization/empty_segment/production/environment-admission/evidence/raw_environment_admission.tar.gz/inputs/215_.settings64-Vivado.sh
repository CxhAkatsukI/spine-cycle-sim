##############################################################
# Copyright (c) 1986-2025 Xilinx, Inc.  All rights reserved. #
##############################################################

export XILINX_VIVADO=/data/yxx/tools/xilinx/Vivado/2024.1
if [ -n "${PATH}" ]; then
  export PATH=/data/yxx/tools/xilinx/Vivado/2024.1/bin:$PATH
else
  export PATH=/data/yxx/tools/xilinx/Vivado/2024.1/bin
fi
