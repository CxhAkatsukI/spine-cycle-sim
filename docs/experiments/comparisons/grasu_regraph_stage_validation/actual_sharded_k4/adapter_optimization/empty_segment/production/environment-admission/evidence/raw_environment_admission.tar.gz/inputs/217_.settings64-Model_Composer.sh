##############################################################
# Copyright (c) 1986-2025 Xilinx, Inc.  All rights reserved. #
##############################################################

if [ -n "${PATH}" ]; then
  export PATH=/data/yxx/tools/xilinx/Model_Composer/2024.1/bin:$PATH
else
  export PATH=/data/yxx/tools/xilinx/Model_Composer/2024.1/bin
fi
