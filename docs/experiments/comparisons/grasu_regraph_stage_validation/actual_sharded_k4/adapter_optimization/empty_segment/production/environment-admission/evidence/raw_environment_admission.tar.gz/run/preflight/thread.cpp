#include <condition_variable>
#include <mutex>
#include <thread>
int main() {
    std::mutex mutex;
    std::condition_variable ready;
    bool done = false;
    std::thread worker([&] {
        std::lock_guard<std::mutex> lock(mutex);
        done = true;
        ready.notify_one();
    });
    { std::unique_lock<std::mutex> lock(mutex);
      ready.wait(lock, [&] { return done; }); }
    worker.join();
    return done ? 0 : 1;
}
