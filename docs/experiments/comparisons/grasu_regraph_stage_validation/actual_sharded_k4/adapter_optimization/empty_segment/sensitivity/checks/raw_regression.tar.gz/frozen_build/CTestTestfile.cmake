# CMake generated Testfile for 
# Source directory: /home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3
# Build directory: /home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/build/original-a4-sssp-real-round-v3
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("cpp")
