#include <hls_stream.h>
#include <string.h>
#include "acc_config.h"
#include "l1_api.h"
#include "acc_data_types.h"
#include <ap_axi_sdata.h>
#if defined(SW_EMU) && !defined(__SYNTHESIS__)
#include <stdio.h>
#define HBM_DEBUG_PRINTF(fmt, ...) do { printf(fmt, ##__VA_ARGS__); fflush(stdout); } while (0)
#else
#define HBM_DEBUG_PRINTF(fmt, ...)
#endif

// REGRAPH_ALL_KERNEL_ID_TEXT

template <int an_unused_template_parameter>
void littleKernelReadMemory(
				int i,
        		ap_uint<512>                    	*src_prop,
				uchar 								num_paritions,
                hls::stream<l_ppb_request_pkt>    	&l_ppb_request_stm,
                hls::stream<l_ppb_response_pkt>   	&l_ppb_response_stm
                ){ 

#pragma HLS function_instantiate variable=i

    l_ppb_request_pkt one_ppb_request_pkg;
    l_ppb_response_pkt one_ppb_response_pkg;

	uchar processed_num_partitions = 0;

	ppb_response_dt one_ppb_response;

	HBM_DEBUG_PRINTF("[KDEBUG] hbm.littleReadMemory[%d]: begin, partitions=%u\n", i, (unsigned)num_paritions);
    
	littleKernelReadMemory:
    while(true){
#pragma HLS PIPELINE //II=1

        if(read_from_stream_nb(l_ppb_request_stm, one_ppb_request_pkg)){

			ppb_request_dt one_ppb_request;
			one_ppb_request.request_round = one_ppb_request_pkg.data;
			one_ppb_request.end_flag = one_ppb_request_pkg.last;

			ap_uint<32>  base_addr = one_ppb_request.request_round << LOG2_SRC_BUFFER_SIZE >> 4;

			if(one_ppb_request.end_flag){
				
				one_ppb_response.end_flag = one_ppb_request.end_flag;
				one_ppb_response_pkg.last = one_ppb_response.end_flag;
				write_to_stream(l_ppb_response_stm, one_ppb_response_pkg);
				processed_num_partitions ++;
				HBM_DEBUG_PRINTF("[KDEBUG] hbm.littleReadMemory[%d]: end request, processed=%u/%u\n",
					i, (unsigned)processed_num_partitions, (unsigned)num_paritions);
				DEBUG_PRINTF("processed_num_partitions %d, %d !\n", processed_num_partitions, num_paritions);
			}
			else{
				
				for(int i = 0; i < (SRC_BUFFER_SIZE >> 4); i ++){
					int addr = base_addr + i;
					one_ppb_response.addr = addr;
					one_ppb_response.data = src_prop[addr];
					one_ppb_response.end_flag = one_ppb_request.end_flag;
					
					one_ppb_response_pkg.data = one_ppb_response.data;
					one_ppb_response_pkg.dest = one_ppb_response.addr;
					one_ppb_response_pkg.last = one_ppb_response.end_flag;
					write_to_stream(l_ppb_response_stm, one_ppb_response_pkg);
				}
			}
		}

		if(processed_num_partitions == num_paritions){
			HBM_DEBUG_PRINTF("[KDEBUG] hbm.littleReadMemory[%d]: exit\n", i);
			DEBUG_PRINTF("HBMwrapperReadMemory exists %d!\n", processed_num_partitions);
			break;
		}
    }
}

template <int an_unused_template_parameter>
void bigKernelReadMemory(
				int i,
        		ap_uint<512>                    	 	*src_prop,
				uchar 								 	num_paritions,
                hls::stream<b_cacheline_request_pkt>    &b_cacheline_request_stm,
                hls::stream<b_cacheline_response_pkt>   &b_cacheline_response_stm
                ){ 

#pragma HLS function_instantiate variable=i

    b_cacheline_request_pkt one_cacheline_request_pkg;
    b_cacheline_response_pkt one_cacheline_response_pkg;

    ap_uint<27> last_requested_cacheline_idx = -1;
    ap_uint<512> last_requested_cacheline;

	uchar processed_num_partitions = 0;

	cacheline_response_dt one_cacheline_response;

	HBM_DEBUG_PRINTF("[KDEBUG] hbm.bigReadMemory[%d]: begin, partitions=%u\n", i, (unsigned)num_paritions);

    bigKernelReadMemory:
    while(true){
#pragma HLS PIPELINE II=1

        bool process_flag = read_from_stream_nb(b_cacheline_request_stm, one_cacheline_request_pkg);

		cacheline_dt one_cacheline_request;
		one_cacheline_request.idx = one_cacheline_request_pkg.data;
		one_cacheline_request.dst = one_cacheline_request_pkg.dest;
		one_cacheline_request.end_flag = one_cacheline_request_pkg.last;

        if(process_flag){

			if(one_cacheline_request.end_flag){
				one_cacheline_response.data = 0;
				last_requested_cacheline_idx = -1;
				processed_num_partitions ++;
				HBM_DEBUG_PRINTF("[KDEBUG] hbm.bigReadMemory[%d]: end request, processed=%u/%u, dst=%u\n",
					i, (unsigned)processed_num_partitions, (unsigned)num_paritions, (unsigned)one_cacheline_request.dst);
				DEBUG_PRINTF("processed_num_partitions %d!\n", processed_num_partitions);
			}
			else{

				if(one_cacheline_request.idx == last_requested_cacheline_idx){
                	one_cacheline_response.data = last_requested_cacheline;
				}
				else{
					one_cacheline_response.data = src_prop[one_cacheline_request.idx];

					last_requested_cacheline_idx = one_cacheline_request.idx;
					last_requested_cacheline = one_cacheline_response.data ;  
				}
			}
			
			one_cacheline_response.end_flag = one_cacheline_request.end_flag;
			one_cacheline_response.dst = one_cacheline_request.dst;

			one_cacheline_response_pkg.data = one_cacheline_response.data;
			one_cacheline_response_pkg.dest = one_cacheline_response.dst;
			one_cacheline_response_pkg.last = one_cacheline_response.end_flag;
            write_to_stream(b_cacheline_response_stm, one_cacheline_response_pkg);
			if(one_cacheline_response.end_flag){
				HBM_DEBUG_PRINTF("[KDEBUG] hbm.bigReadMemory[%d]: end response written\n", i);
			}
        }

		if(processed_num_partitions == num_paritions) {
			HBM_DEBUG_PRINTF("[KDEBUG] hbm.bigReadMemory[%d]: exit\n", i);
			break;
		}
    }
}


void write_out (
	// TODO
				ap_uint<512>                    *new_prop_1,
				ap_uint<512>                    *new_prop_2,
        		hls::stream<write_burst_pkt>  	&write_burst_stm
				)
{		
	uint write_idx = 0;
	uint written_num_write_burst = 0;

	HBM_DEBUG_PRINTF("[KDEBUG] hbm.write_out: begin\n");

	write_out:
    while(true){
#pragma HLS PIPELINE II=1	
		
		write_burst_pkt  one_write_burst;
		
		if(read_from_stream_nb(write_burst_stm, one_write_burst)){

			write_idx = one_write_burst.dest;

			if(one_write_burst.last){
				HBM_DEBUG_PRINTF("[KDEBUG] hbm.write_out: end after %u bursts\n", (unsigned)written_num_write_burst);
				DEBUG_PRINTF("write_out exits \n");
				break;
			} 

			ap_uint<512> new_prop = one_write_burst.data;
			// TODO
			new_prop_1[write_idx] = new_prop;
			new_prop_2[write_idx] = new_prop;
			written_num_write_burst ++;
			if ((written_num_write_burst & 0xfff) == 0) {
				HBM_DEBUG_PRINTF("[KDEBUG] hbm.write_out: wrote %u bursts, last write_idx=%u\n",
					(unsigned)written_num_write_burst, (unsigned)write_idx);
			}
		}
	}
}
