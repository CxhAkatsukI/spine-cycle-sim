"""Core simulation framework."""
