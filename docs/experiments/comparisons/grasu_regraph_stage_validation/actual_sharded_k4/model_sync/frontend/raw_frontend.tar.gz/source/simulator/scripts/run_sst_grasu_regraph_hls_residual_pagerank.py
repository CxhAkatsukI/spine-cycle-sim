#!/usr/bin/env python3
"""Run proposed ff13a67 GraSU + ReGraph residual PageRank on SST-HBM."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_sst_grasu_regraph import load_dram_stats, sha256  # noqa: E402
from scripts.run_sst_grasu_regraph_hls_pagerank import (  # noqa: E402
    full_pagerank_oracle,
)
from scripts.run_sst_grasu_regraph_hls_weighted import (  # noqa: E402
    HlsWeightedOracle,
    build_hls_weighted_oracle,
)
from spine_cycle_sim.experiments.grasu_addressing import (  # noqa: E402
    grasu_hbm_address_environment,
    partition_layout_footprints,
    selected_source_state_stride_bytes,
    validate_grasu_hbm_address_map,
    validate_partition_footprints,
)
from spine_cycle_sim.experiments.host_memory import release_process_heap  # noqa: E402
from spine_cycle_sim.experiments.profile_capabilities import (  # noqa: E402
    AlgorithmCapability,
    CapabilityCatalog,
    load_capability_catalog,
)
from spine_cycle_sim.experiments.regraph_contracts import (  # noqa: E402
    expected_partitioned_source_cache_requests,
)
from spine_cycle_sim.experiments.shared_workloads import load_slice  # noqa: E402
from spine_cycle_sim.sst_binding import grasu_normalized_memory_binding  # noqa: E402
from spine_cycle_sim.sst_library import forced_sst_library_binding  # noqa: E402


DEFAULT_SST = Path("/data/feiyang/sst/bin/sst")
DEFAULT_PROFILE = (
    ROOT
    / "configs"
    / "architectures"
    / "grasu_regraph_weighted_pma_hls_proposed_residual_pagerank_ff13a67.json"
)
DEFAULT_CAPABILITY_CATALOG = (
    ROOT / "configs" / "contracts" / "grasu_regraph_capabilities_v1.json"
)
DEFAULT_INITIAL = (
    ROOT / "tests" / "data" / "grasu_regraph_weighted_dynamic_initial.slice"
)
DEFAULT_UPDATE = (
    ROOT / "tests" / "data" / "grasu_regraph_weighted_dynamic_update.slice"
)


@dataclass(frozen=True)
class HlsResidualRuntimeOracle:
    logical_updates: int
    physical_updates: int
    external_to_internal: tuple[int, ...]
    internal_to_external: tuple[int, ...]
    partition_vertices: int
    source_requests_per_iteration: int


def compact_hls_residual_oracle(
    oracle: HlsWeightedOracle,
    partition_vertices: int,
    source_buffer_vertices: int,
) -> HlsResidualRuntimeOracle:
    if partition_vertices <= 0 or source_buffer_vertices <= 0:
        raise ValueError("residual oracle partition geometry must be positive")
    destination_partitions = (
        len(oracle.external_to_internal) + partition_vertices - 1
    ) // partition_vertices
    partition_sources: list[set[int]] = [
        set() for _ in range(destination_partitions)
    ]
    for source, destination, _ in oracle.final_internal_edges:
        partition_sources[destination // partition_vertices].add(source)
    requests_per_iteration = sum(
        expected_partitioned_source_cache_requests(
            sources, source_buffer_vertices, 1
        )
        for sources in partition_sources
    )
    return HlsResidualRuntimeOracle(
        logical_updates=oracle.logical_updates,
        physical_updates=oracle.physical_updates,
        external_to_internal=oracle.external_to_internal,
        internal_to_external=oracle.internal_to_external,
        partition_vertices=partition_vertices,
        source_requests_per_iteration=requests_per_iteration,
    )


def residual_bound_matches(
    result: dict[str, object], residual_contract: str, epsilon: float
) -> bool:
    field = (
        "residual_linf"
        if residual_contract
        in {
            "deltahls_sink_free_linf_warm",
            "grasu_hardware_warm_dangling_linf",
        }
        else "residual_l1"
    )
    try:
        return float(result[field]) <= epsilon * 1.01
    except (KeyError, TypeError, ValueError):
        return False


def propagation_iteration_count_matches(
    iterations: int, max_iterations: int, hardware_warm: bool
) -> bool:
    return (
        0 <= iterations <= max_iterations
        if hardware_warm
        else 0 < iterations <= max_iterations
    )


def frontier_ledger_matches(result: dict[str, object], iterations: int) -> bool:
    frontier_in = result.get("frontier_in_sizes", [])
    frontier_out = result.get("frontier_out_sizes", [])
    if not isinstance(frontier_in, list) or not isinstance(frontier_out, list):
        return False
    return (
        len(frontier_in) == iterations
        and len(frontier_out) == iterations
        and (iterations == 0 or frontier_out[-1] == 0)
    )


def external_rank_oracle_matches(
    result: dict[str, object],
    mathematical_error: float,
    residual_contract: str,
    epsilon: float,
    damping: float,
) -> bool:
    if residual_contract not in {
        "deltahls_sink_free_linf_warm",
        "grasu_hardware_warm_dangling_linf",
    }:
        return mathematical_error <= 5.0 * epsilon
    try:
        old_rank_l1 = float(result["old_rank_l1"])
        residual_l1 = float(result["residual_l1"])
        reported_error = float(result["mathematical_max_abs_error"])
        reported_tolerance = float(result["mathematical_error_tolerance"])
    except (KeyError, TypeError, ValueError):
        return False
    expected_tolerance = max(
        5.0e-7, 1.1 * (old_rank_l1 + residual_l1) / (1.0 - damping)
    )
    return (
        result.get("mathematical_error_bound")
        == "l1_fixed_point_defect_plus_final_residual_over_one_minus_d"
        and old_rank_l1 >= 0.0
        and residual_l1 >= 0.0
        and math.isfinite(reported_tolerance)
        and math.isclose(
            reported_tolerance, expected_tolerance, rel_tol=1.0e-4, abs_tol=1.0e-9
        )
        and math.isclose(
            reported_error, mathematical_error, rel_tol=1.0e-4, abs_tol=1.0e-7
        )
        and mathematical_error <= reported_tolerance
    )


def require_hls_residual_capability(
    profile_path: Path, capability_catalog_path: Path
) -> tuple[CapabilityCatalog, AlgorithmCapability]:
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    catalog = load_capability_catalog(capability_catalog_path)
    profile_capability = catalog.profile(str(profile.get("profile_id", "")))
    if profile_capability.profile_path != profile_path.resolve():
        raise ValueError("HLS-equivalent residual capability profile path differs")
    capability = profile_capability.require("thresholded_residual_pagerank")
    if (
        profile_capability.comparison_role
        not in {"hls_equivalent_proposed", "normalized", "hardware_native"}
        or profile_capability.handoff != "weighted_pma_to_axis_stream"
        or profile_capability.conversion_cost != "absent"
    ):
        raise ValueError("capability does not describe the proposed full-word path")
    return catalog, capability


def validate_result(
    result: dict[str, object],
    profile: dict[str, object],
    oracle: HlsWeightedOracle | HlsResidualRuntimeOracle,
    full_solution_external: tuple[float, ...],
    *,
    residual_contract: str,
    epsilon: float,
    max_iterations: int,
    downstream_sharing: str,
) -> None:
    params = profile["parameters"]
    memory = profile["memory"]
    assert isinstance(params, dict) and isinstance(memory, dict)
    delta_hls = residual_contract == "deltahls_sink_free_linf_warm"
    hardware_warm = residual_contract == "grasu_hardware_warm_dangling_linf"
    iterations = int(result.get("iterations", -1))
    expected_pipeline_executions = iterations + (1 if hardware_warm else 0)
    vertices = len(oracle.external_to_internal)
    partition_vertices = int(params["regraph_partition_vertices"])
    state_bytes = int(params["pagerank_state_bytes_per_vertex"])
    damping = float(params["pagerank_damping"])
    prepared_source_bytes = 4
    vertices_per_beat = (
        int(memory["data_width_bits"]) // 8 // prepared_source_bytes
    )
    destination_partitions = (vertices + partition_vertices - 1) // partition_vertices
    if isinstance(oracle, HlsResidualRuntimeOracle):
        if oracle.partition_vertices != partition_vertices:
            raise ValueError("compacted residual oracle geometry differs from profile")
        source_requests = (
            oracle.source_requests_per_iteration * expected_pipeline_executions
        )
    else:
        partition_sources: list[set[int]] = [
            set() for _ in range(destination_partitions)
        ]
        for source, destination, _ in oracle.final_internal_edges:
            partition = destination // partition_vertices
            partition_sources[partition].add(source)
        source_requests = sum(
            expected_partitioned_source_cache_requests(
                sources,
                int(params["regraph_source_buffer_vertices"]),
                expected_pipeline_executions,
            )
            for sources in partition_sources
        )
    source_lines = (
        source_requests
        * int(params["regraph_source_buffer_vertices"])
        // vertices_per_beat
    )
    rows = (
        destination_partitions
        * partition_vertices
        // 2
        * expected_pipeline_executions
    )
    bursts = (
        destination_partitions
        * partition_vertices
        // 16
        * expected_pipeline_executions
    )
    source_prepare_degree_reads = (vertices + 15) // 16
    ranks = tuple(float(value) for value in result.get("ranks_external", []))
    residuals = tuple(
        float(value) for value in result.get("residuals_external", [])
    )
    mathematical_error = (
        max(
            abs(actual - expected)
            for actual, expected in zip(ranks, full_solution_external)
        )
        if len(ranks) == len(full_solution_external)
        else math.inf
    )
    external_residual_l1 = (
        math.fsum(abs(value) for value in residuals)
        if len(residuals) == vertices
        else math.inf
    )
    external_residual_linf = (
        max((abs(value) for value in residuals), default=0.0)
        if len(residuals) == vertices
        else math.inf
    )
    checks = {
        "success": result.get("success") is True,
        "mode": result.get("mode")
        == "grasu_regraph_hls_weighted_residual_pagerank",
        "claim": result.get("claim_class")
        == "hls_equivalent_proposed_execution_driven_simulation",
        "timing": result.get("timing_evidence")
        == "execution_driven_sst_hbm_not_cycle_calibrated",
        "residual_contract": result.get("residual_contract")
        == residual_contract,
        "hardware_correction": (not hardware_warm)
        or (
            result.get("correction_executions") == 1
            and result.get("pipeline_executions") == expected_pipeline_executions
            and result.get("correction_execution_timing")
            == "realized_work_component_envelope"
            and int(result.get("correction_pma_slots", 0)) > 0
        ),
        "sink_free": (not delta_hls)
        or (
            result.get("old_sink_vertices") == 0
            and result.get("new_sink_vertices") == 0
        ),
        "serial_order": result.get("pipeline_order")
        == "update_then_degree_barrier_then_pma_native_compute",
        "conversion_absent": result.get("conversion_cost_included") is False,
        "abi": result.get("pma_edge_abi") == params["grasu_pma_edge_abi"],
        "logical_updates": result.get("logical_updates") == oracle.logical_updates,
        "physical_updates": result.get("physical_updates") == oracle.physical_updates,
        "host_reorder": result.get("host_vertex_reorder") is True,
        "external_to_internal": result.get("external_to_internal")
        == list(oracle.external_to_internal),
        "internal_to_external": result.get("internal_to_external")
        == list(oracle.internal_to_external),
        "dual_oracle": result.get("correctness_mismatches") == 0
        and result.get("architecture_correctness_mismatches") == 0
        and result.get("mathematical_correctness_mismatches") == 0,
        "external_rank_oracle": external_rank_oracle_matches(
            result,
            mathematical_error,
            residual_contract,
            epsilon,
            damping,
        ),
        "external_residual": residual_bound_matches(
            {
                "residual_l1": external_residual_l1,
                "residual_linf": external_residual_linf,
            },
            residual_contract,
            epsilon,
        ),
        "converged": result.get("converged") is True
        and result.get("residual_bound_passed") is True
        and propagation_iteration_count_matches(
            iterations, max_iterations, hardware_warm
        ),
        "frontiers": frontier_ledger_matches(result, iterations),
        "active_edge_execution_ledger": result.get(
            "active_edge_execution_ledger_match"
        )
        is True,
        "update_state": result.get("update_state_mismatches") == 0,
        "degree_state": result.get("degree_state_mismatches") == 0,
        "degree_timed": result.get("degree_update_timing_included") is True,
        "degree_rmw": result.get("degree_updates_required")
        == oracle.physical_updates
        and result.get("degree_update_reads") == oracle.physical_updates
        and result.get("degree_update_writes") == oracle.physical_updates,
        "partitions": result.get("destination_partitions")
        == destination_partitions,
        "pipelines": result.get("compute_pipelines")
        == int(params.get("regraph_compute_pipelines", 1)),
        "downstream_sharing": result.get("downstream_sharing")
        == downstream_sharing,
        "downstream_parallelism": result.get(
            "max_parallel_downstream_partitions"
        )
        == (
            min(
                int(params.get("regraph_compute_pipelines", 1)),
                destination_partitions,
            )
            if downstream_sharing == "direct"
            else 1
        ),
        "degree_reads": result.get("source_prepare_degree_reads")
        == source_prepare_degree_reads
        and result.get("degree_reads") == source_prepare_degree_reads + bursts,
        "state_width": result.get("state_bytes_per_vertex") == state_bytes,
        "lanes": result.get("edge_lanes") == params["regraph_map_reduce_lanes"]
        and result.get("gather_banks") == params["regraph_map_reduce_lanes"],
        "source_requests": result.get("source_cache_requests") == source_requests,
        "source_lines": result.get("source_cache_lines") == source_lines,
        "source_lane_writes": result.get("source_cache_lane_writes")
        == source_lines * int(params["regraph_map_reduce_lanes"]),
        "rows": result.get("gather_rows_emitted") == rows
        and result.get("merger_rows_consumed") == rows,
        "bursts": result.get("merger_bursts_emitted") == bursts
        and result.get("apply_input_bursts") == bursts
        and result.get("hbm_wrapper_input_bursts") == bursts,
        "request_ledger": result.get("expected_backend_requests")
        == result.get("backend_requests"),
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        source_detail = (
            f"source_expected={source_requests}/{source_lines}/"
            f"{source_lines * int(params['regraph_map_reduce_lanes'])} "
            f"source_actual={result.get('source_cache_requests')}/"
            f"{result.get('source_cache_lines')}/"
            f"{result.get('source_cache_lane_writes')}"
        )
        raise RuntimeError(
            f"HLS-equivalent residual PageRank validation failed ({failed}); "
            f"cycles={result.get('cycles')} "
            f"partitions={result.get('destination_partitions')} "
            f"pipelines={result.get('compute_pipelines')} {source_detail}"
        )


def validate_update_only_result(
    result: dict[str, object], oracle: HlsResidualRuntimeOracle
) -> None:
    observability = result.get("update_observability")
    checks = {
        "success": result.get("success") is True,
        "mode": result.get("mode")
        == "grasu_regraph_hls_weighted_residual_pagerank",
        "measurement_window": result.get("measurement_window")
        == "pure_update_only",
        "pipeline_order": result.get("pipeline_order")
        == "update_only_no_regraph_compute",
        "conversion_absent": result.get("conversion_cost_included") is False,
        "logical_updates": result.get("logical_updates") == oracle.logical_updates,
        "physical_updates": result.get("physical_updates")
        == oracle.physical_updates,
        "positive_update_cycles": int(result.get("update_cycles", 0)) > 0,
        "zero_compute_cycles": int(result.get("compute_cycles", -1)) == 0,
        "update_state": result.get("update_state_match") is True,
        "memory_ledger": result.get("memory_locality_ledger_match") is True,
        "correctness": result.get("correctness_mismatches") == 0,
        "observability": isinstance(observability, dict)
        and observability.get("updates") == oracle.physical_updates
        and observability.get("degree_reads") == oracle.physical_updates
        and observability.get("degree_writes") == oracle.physical_updates,
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise RuntimeError(
            f"HLS-equivalent residual update-only validation failed ({failed}); "
            f"cycles={result.get('update_cycles')}"
        )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile", type=Path, default=DEFAULT_PROFILE)
    parser.add_argument(
        "--capability-catalog", type=Path, default=DEFAULT_CAPABILITY_CATALOG
    )
    parser.add_argument("--workload", type=Path, default=DEFAULT_INITIAL)
    parser.add_argument("--update-workload", type=Path, default=DEFAULT_UPDATE)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--sst", type=Path, default=DEFAULT_SST)
    parser.add_argument("--lib-dir", type=Path, default=ROOT / "build" / "sst")
    parser.add_argument("--max-cycles", type=int, default=100_000_000)
    parser.add_argument(
        "--residual-contract",
        choices=(
            "generic_dangling_l1_cold",
            "deltahls_sink_free_linf_warm",
            "grasu_hardware_warm_dangling_linf",
        ),
        default=None,
    )
    parser.add_argument("--pagerank-epsilon", type=float)
    parser.add_argument("--residual-max-iterations", type=int)
    parser.add_argument(
        "--downstream-sharing", choices=("direct", "shared"), default=None
    )
    parser.add_argument("--no-build", action="store_true")
    parser.add_argument(
        "--update-only",
        action="store_true",
        help="Stop after PMA and degree maintenance and emit update observability.",
    )
    parser.add_argument(
        "--reuse-result",
        action="store_true",
        help="validate an existing result.json and DRAM directory without rerunning SST",
    )
    parser.add_argument("--instantiate-all-hbm-channels", action="store_true")
    args = parser.parse_args()

    profile_path = args.profile.resolve()
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    expected_profiles = {
        "grasu_regraph_weighted_pma_hls_proposed_residual_pagerank_ff13a67",
        "grasu_regraph_candidate10_normalized_hls_residual_pagerank_v3",
        "grasu_regraph_candidate10_k1_multipart_residual_v4",
        "grasu_regraph_candidate10_k2_multipart_residual_v4",
        "grasu_regraph_candidate10_k4_multipart_residual_v4",
        "grasu_regraph_candidate10_k1_multipart_residual_packed_v5",
        "grasu_regraph_candidate10_k2_multipart_residual_packed_v5",
        "grasu_regraph_candidate10_k4_multipart_residual_packed_v5",
        "grasu_regraph_candidate10_k4_shared_multipart_residual_packed_v6",
        "grasu_regraph_candidate10_k1_multipart_residual_fullgraph_v7",
        "grasu_regraph_candidate10_k4_shared_multipart_residual_fullgraph_v7",
        "grasu_regraph_sharded_k4_residual_hls_v8",
    }
    if profile.get("profile_id") not in expected_profiles:
        raise ValueError("runner requires a pinned HLS-derived residual profile")
    catalog, capability = require_hls_residual_capability(
        profile_path, args.capability_catalog.resolve()
    )
    params = profile["parameters"]
    memory = profile["memory"]
    profile_sharing = str(params.get("regraph_downstream_sharing", "direct"))
    residual_contract = args.residual_contract or str(
        params.get("pagerank_residual_contract", "generic_dangling_l1_cold")
    )
    downstream_sharing = args.downstream_sharing or profile_sharing
    if downstream_sharing != profile_sharing:
        raise ValueError("residual runner downstream sharing differs from profile")
    initial = load_slice(args.workload.resolve())
    update = load_slice(args.update_workload.resolve())
    oracle = build_hls_weighted_oracle(initial, update, 0)
    partition_vertices = int(params["regraph_partition_vertices"])
    destination_partitions = (
        initial.vertices + partition_vertices - 1
    ) // partition_vertices
    runtime_source_state_stride = selected_source_state_stride_bytes(
        params, destination_partitions
    )
    address_regions = None
    address_environment: dict[str, str] = {}
    if params.get("physical_address_map_id"):
        footprints = partition_layout_footprints(
            initial.records,
            update.records,
            initial.vertices,
            partition_vertices,
            oracle.external_to_internal,
            weighted_full_word=True,
        )
        validate_partition_footprints(params, footprints)
        address_regions = validate_grasu_hbm_address_map(
            params,
            int(memory["channel_capacity_bytes"]),
            destination_partitions,
            initial.vertices,
            oracle.physical_updates,
            footprints,
        )
        address_environment = grasu_hbm_address_environment(
            params, address_regions
        )
    damping = float(params["pagerank_damping"])
    epsilon = (
        float(args.pagerank_epsilon)
        if args.pagerank_epsilon is not None
        else float(params["pagerank_epsilon"])
    )
    max_iterations = (
        int(args.residual_max_iterations)
        if args.residual_max_iterations is not None
        else int(params["pagerank_residual_max_iterations"])
    )
    if epsilon <= 0.0 or max_iterations <= 0:
        raise ValueError("epsilon and residual iteration limit must be positive")
    full_solution = (
        ()
        if args.update_only
        else full_pagerank_oracle(
            initial.vertices, oracle.final_external_edges, damping, 200
        )
    )
    binding = grasu_normalized_memory_binding(
        profile, instantiate_all=args.instantiate_all_hbm_channels
    )
    runtime_oracle = compact_hls_residual_oracle(
        oracle,
        int(params["regraph_partition_vertices"]),
        int(params["regraph_source_buffer_vertices"]),
    )
    del oracle, initial, update
    host_heap_trimmed = release_process_heap()
    kernel_clock = next(
        clock for clock in profile["clocks"] if clock["name"] == "kernel"
    )
    if not args.no_build:
        subprocess.run(["make", "-C", "cpp/sst", "-j2"], cwd=ROOT, check=True)

    args.out_dir.mkdir(parents=True, exist_ok=True)
    result_path = (args.out_dir / "result.json").resolve()
    dram_dir = (args.out_dir / "dram").resolve()
    if not args.reuse_result:
        result_path.unlink(missing_ok=True)
        shutil.rmtree(dram_dir, ignore_errors=True)
    elif not result_path.is_file() or not dram_dir.is_dir():
        raise FileNotFoundError("--reuse-result requires result.json and dram/")
    env = os.environ.copy()
    env.update(
        {
            "GRASU_SST_MODE": "grasu_regraph_hls_weighted_residual_pagerank",
            "GRASU_SST_CHANNELS": str(memory["channels"]),
            "GRASU_SST_ACTIVE_CHANNELS": ",".join(
                str(channel) for channel in binding.instantiated_channels
            ),
            "GRASU_SST_CHANNEL_BYTES": str(memory["channel_capacity_bytes"]),
            "GRASU_SST_WORKLOAD": str(args.workload.resolve()),
            "GRASU_SST_UPDATE_WORKLOAD": str(args.update_workload.resolve()),
            "GRASU_SST_OUTPUT": str(result_path),
            "GRASU_SST_DRAM_OUTPUT": str(dram_dir),
            "GRASU_SST_CORE_MHZ": str(kernel_clock["achieved_mhz"]),
            "GRASU_SST_MAX_CYCLES": str(args.max_cycles),
            "GRASU_SST_MAX_ROUNDS": str(max_iterations),
            "GRASU_SST_RESIDUAL_MAX_ITERATIONS": str(max_iterations),
            "GRASU_SST_PAGERANK_DAMPING": str(damping),
            "GRASU_SST_PAGERANK_EPSILON": str(epsilon),
            "GRASU_SST_RESIDUAL_CONTRACT": residual_contract,
            "GRASU_SST_UPDATE_ONLY": "1" if args.update_only else "0",
            "GRASU_SST_CACHE_SEGMENTS_PER_HALF": str(
                params["grasu_cache_segments_per_cu"]
            ),
            "GRASU_SST_PARTITION_VERTICES": str(
                params["regraph_partition_vertices"]
            ),
            "GRASU_SST_COMPUTE_PIPELINES": str(
                params.get("regraph_compute_pipelines", 1)
            ),
            "GRASU_SST_SHARED_DOWNSTREAM": (
                "1" if downstream_sharing == "shared" else "0"
            ),
            "GRASU_SST_SHARDED_RUNTIME_PLACEMENT": (
                "1" if params.get("grasu_sharded_runtime_placement", False) else "0"
            ),
            "GRASU_SST_RUNTIME_CHANNEL_CAPACITY_BYTES": str(
                params.get(
                    "grasu_runtime_channel_capacity_bytes",
                    memory["channel_capacity_bytes"],
                )
            ),
            "GRASU_SST_SOURCE_BUFFER_VERTICES": str(
                params["regraph_source_buffer_vertices"]
            ),
            "GRASU_SST_SOURCE_CACHE_REQUEST_FIFO_DEPTH": str(
                params["regraph_source_cache_request_fifo_depth"]
            ),
            "GRASU_SST_SOURCE_CACHE_RESPONSE_FIFO_DEPTH": str(
                params["regraph_source_cache_response_fifo_depth"]
            ),
            "GRASU_SST_EDGE_LANES": str(params["regraph_map_reduce_lanes"]),
            "GRASU_SST_GATHER_BANKS": str(params["regraph_map_reduce_lanes"]),
            "GRASU_SST_AXIS_FIFO_DEPTH": str(
                params["regraph_pma_adapter_axis_fifo_depth"]
            ),
            "GRASU_SST_GATHER_BYPASS_DISTANCE": str(
                params["regraph_gather_bypass_distance"]
            ),
            "GRASU_SST_GATHER_PIPELINE_LATENCY": str(
                params["regraph_gather_pipeline_latency"]
            ),
            "GRASU_SST_SOURCE_STATE_CHANNEL": str(
                params["regraph_source_state_channel"]
            ),
            "GRASU_SST_SOURCE_STATE_MIRROR_CHANNEL": str(
                params["regraph_source_state_mirror_channel"]
            ),
            "GRASU_SST_APPLY_STATE_CHANNEL": str(
                params["regraph_apply_state_channel"]
            ),
            "GRASU_SST_SPLIT_PAGERANK_STATE": (
                "1" if params.get("regraph_split_pagerank_state", False) else "0"
            ),
            "GRASU_SST_RESIDUAL_STATE_CHANNEL": str(
                params.get("regraph_residual_state_channel", 26)
            ),
            "GRASU_SST_DEGREE_CHANNEL": str(params["regraph_degree_channel"]),
            "GRASU_SST_DEGREE_FIFO_DEPTH": str(params["grasu_degree_fifo_depth"]),
            "GRASU_SST_DEGREE_REORDER_ENTRIES": str(
                params["grasu_degree_reorder_entries"]
            ),
            "GRASU_SST_PAGERANK_SOURCE_MAP_LATENCY": str(
                params["regraph_pagerank_source_map_latency"]
            ),
            "GRASU_SST_GATHER_MERGER_FIFO_DEPTH": str(
                params["regraph_gather_merger_fifo_depth"]
            ),
            "GRASU_SST_MERGER_APPLY_FIFO_DEPTH": str(
                params["regraph_merger_apply_fifo_depth"]
            ),
            "GRASU_SST_APPLY_WRAPPER_FIFO_DEPTH": str(
                params["regraph_apply_wrapper_fifo_depth"]
            ),
            "GRASU_SST_MAX_PENDING_REQUESTS": str(
                memory["max_outstanding_per_port"]
            ),
            "GRASU_SST_MAX_OUTSTANDING_BURSTS": str(
                memory["max_outstanding_per_port"]
            ),
            "GRASU_SST_APPLY_REQUEST_WINDOW": str(
                params["regraph_apply_request_window"]
            ),
            "GRASU_SST_APPLY_PIPELINE_LATENCY": str(
                params["regraph_apply_pipeline_latency"]
            ),
            "GRASU_SST_APPLY_PIPELINE_CAPACITY": str(
                params["regraph_apply_pipeline_capacity"]
            ),
            "GRASU_SST_HBM_WRAPPER_PIPELINE_LATENCY": str(
                params["regraph_hbm_wrapper_pipeline_latency"]
            ),
            "GRASU_SST_HBM_WRAPPER_PIPELINE_CAPACITY": str(
                params["regraph_hbm_wrapper_pipeline_capacity"]
            ),
            "GRASU_SST_UPDATE_BASE": str(params["grasu_update_base_bytes"]),
            "GRASU_SST_ROW_OFFSET_BASE": str(
                params["grasu_row_offset_base_bytes"]
            ),
            "GRASU_SST_BINARY_BASE": str(params["grasu_binary_base_bytes"]),
            "GRASU_SST_PMA_BASE": str(params["grasu_pma_base_bytes"]),
            "GRASU_SST_VERTEX_STATE_BASE": str(
                params["grasu_vertex_state_base_bytes"]
            ),
            "GRASU_SST_RESIDUAL_STATE_BASE": str(
                params.get("grasu_residual_state_base_bytes", 0x42000000)
            ),
            "GRASU_SST_SOURCE_STATE_BASE": str(
                params["grasu_source_state_base_bytes"]
            ),
            "GRASU_SST_SOURCE_STATE_BUFFER_STRIDE": str(
                runtime_source_state_stride
            ),
            "GRASU_SST_DEGREE_BASE": str(params["grasu_degree_base_bytes"]),
            "GRASU_SST_PARTITION_ADDRESS_STRIDE": str(
                params["grasu_partition_address_stride_bytes"]
            ),
        }
    )
    env.update(address_environment)
    env.setdefault(
        "SPINE_CAMPAIGN_PROGRESS_PATH",
        str((args.out_dir / "progress.json").resolve()),
    )
    env.setdefault("SPINE_CAMPAIGN_PROGRESS_INTERVAL_CYCLES", "1000000")
    sst_library = forced_sst_library_binding(args.sst, args.lib_dir)
    command = [
        str(args.sst.resolve()),
        sst_library["command_option"],
        str(ROOT / "sst" / "grasu_regraph_vertical.py"),
    ]
    wall_seconds: float | None = None
    if not args.reuse_result:
        started = time.monotonic()
        completed = subprocess.run(
            command,
            cwd=ROOT,
            env=env,
            check=False,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        wall_seconds = time.monotonic() - started
        (args.out_dir / "sst.log").write_text(completed.stdout, encoding="utf-8")
        if completed.returncode != 0:
            raise RuntimeError(
                f"HLS-equivalent residual PageRank SST failed with "
                f"rc={completed.returncode}; see {args.out_dir / 'sst.log'}"
            )
    result = json.loads(result_path.read_text(encoding="utf-8"))
    if args.update_only:
        validate_update_only_result(result, runtime_oracle)
    else:
        validate_result(
            result,
            profile,
            runtime_oracle,
            full_solution,
            residual_contract=residual_contract,
            epsilon=epsilon,
            max_iterations=max_iterations,
            downstream_sharing=downstream_sharing,
        )
    dram = load_dram_stats(dram_dir)
    if (
        dram["channels"] != len(binding.instantiated_channels)
        or dram["reads"] + dram["writes"] != result["backend_requests"]
    ):
        raise RuntimeError("HLS-equivalent residual DRAM ledger mismatch")
    manifest = {
        "schema_version": 1,
        "profile": str(profile_path),
        "profile_sha256": sha256(profile_path),
        "capability_catalog": str(catalog.manifest_path),
        "capability_catalog_sha256": catalog.manifest_sha256,
        "algorithm_capability": capability.manifest_record(),
        "residual_contract": residual_contract,
        "pagerank_epsilon": epsilon,
        "residual_max_iterations": max_iterations,
        "downstream_sharing": downstream_sharing,
        "workload": str(args.workload.resolve()),
        "workload_sha256": sha256(args.workload.resolve()),
        "update_workload": str(args.update_workload.resolve()),
        "update_workload_sha256": sha256(args.update_workload.resolve()),
        "sst_memory_binding": binding.as_manifest(),
        "physical_hbm_address_regions": address_regions,
        "runtime_source_state_stride_bytes": runtime_source_state_stride,
        "sst_library_binding": sst_library,
        "sst_plugin_sha256": sst_library["plugin_sha256"],
        "host_oracle_storage": "compacted_before_sst_launch_v1",
        "host_heap_trimmed": host_heap_trimmed,
        "sst_host_wall_seconds": wall_seconds,
        "reused_existing_result": args.reuse_result,
        "measurement_window": (
            "pure_update_only" if args.update_only else "update_to_convergence"
        ),
        "graph_compute_executed": not args.update_only,
        "command": command,
        "result": result,
        "dram": dram,
        "status": "PASS",
    }
    (args.out_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    if args.update_only:
        print(
            "PASS grasu_regraph_hls_residual_pagerank_update_only: "
            f"cycles={result['update_cycles']} "
            f"physical={runtime_oracle.physical_updates} "
            f"requests={result['backend_requests']}"
        )
    else:
        print(
            "PASS grasu_regraph_hls_residual_pagerank_sst: "
            f"cycles={result['cycles']} iterations={result['iterations']} "
            f"active_edges={result['compute_active_edges']} "
            f"requests={result['backend_requests']}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
