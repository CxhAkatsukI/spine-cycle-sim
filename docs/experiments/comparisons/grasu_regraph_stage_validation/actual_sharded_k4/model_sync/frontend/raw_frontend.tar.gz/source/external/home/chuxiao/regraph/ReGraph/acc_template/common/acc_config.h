#ifndef __ACC_CONFIG_H__
#define __ACC_CONFIG_H__

#ifndef HAVE_EDGE_PROP
#define HAVE_EDGE_PROP 0
#endif

#define NUM_EDGE_PER_BURST 8

#define LOG2_NUM_EDGE_PER_BURST 3

#define SCATTER_PE_NUM      8
#define GATHER_PE_NUM     8
#define LOG2_GATHER_PE_NUM    3 
#define REDUCTIONTREE_NUM     8
#define EDGE_NUM            8
#define DATA_WIDTH              (512)


#define HASH_MASK  (REDUCTIONTREE_NUM - 1) 

#define ENDFLAG                                 0xffffffff

#define V_IDX_TYPE ap_uint<32>

#define EDGE_LOCAL_DST_BITS                     19
#define EDGE_LOCAL_DST_MASK                     0x7ffff
#define EDGE_WEIGHT_SHIFT                       EDGE_LOCAL_DST_BITS
#define EDGE_WEIGHT_BITS                        12
#define EDGE_WEIGHT_MASK                        0xfff
#define EDGE_DUMMY_MASK                         0x80000000
// Keep enough completed accumulations to bypass URAM read-after-write hazards.
// In Vitis 2024.1 the gather URAM lookup and final write are six pipeline
// stages apart; the original distance of 3 can therefore expose stale values.
#define L 6

#ifndef ENABLE_COMPRESSED_EDGE_INPUT
#define ENABLE_COMPRESSED_EDGE_INPUT 0
#endif

#if HAVE_EDGE_PROP && ENABLE_COMPRESSED_EDGE_INPUT
#error "Weighted edge properties are not supported by ENABLE_COMPRESSED_EDGE_INPUT yet."
#endif


//#define SW_DEBUG

#if defined(SW_DEBUG) && !defined(__SYNTHESIS__)

#include "stdio.h"
#define DEBUG_PRINTF(fmt,...)   printf(fmt,##__VA_ARGS__); fflush(stdout);

#else

#define DEBUG_PRINTF(fmt,...)   ;

#endif

#endif /* __ACC_CONFIG_H__ */
