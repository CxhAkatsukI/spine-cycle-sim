`timescale 1ns/1ps
module empty_segment_handshake_tb;
  reg clk = 0;
  always #5 clk = ~clk;
  reg rst = 1;
  reg start = 0;
  reg ready = 1;
  reg [27:0] begin_segment = 0;
  wire done, helper_ready, arvalid, outvalid;
  integer cycle = 0;
  always @(posedge clk) begin
    cycle <= cycle + 1;
    // Match the routed parent's start register: retire on helper ap_ready.
    if (rst || (start && helper_ready)) start <= 0;
  end

  pma_to_regraph_adapter_pma_to_regraph_adapter_Pipeline_segment_loop dut (
    .ap_clk(clk), .ap_rst(rst), .ap_start(start), .ap_done(done),
    .ap_ready(helper_ready),
    .m_axi_gmem0_AWREADY(1'b0), .m_axi_gmem0_WREADY(1'b0),
    .m_axi_gmem0_ARREADY(1'b1), .m_axi_gmem0_ARVALID(arvalid),
    .m_axi_gmem0_RVALID(1'b0), .m_axi_gmem0_RDATA(512'b0),
    .m_axi_gmem0_RLAST(1'b0), .m_axi_gmem0_RID(1'b0),
    .m_axi_gmem0_RFIFONUM(9'b0), .m_axi_gmem0_RUSER(1'b0),
    .m_axi_gmem0_RRESP(2'b0), .m_axi_gmem0_BVALID(1'b0),
    .m_axi_gmem0_BRESP(2'b0), .m_axi_gmem0_BID(1'b0), .m_axi_gmem0_BUSER(1'b0),
    .edge_burst_out_TREADY(ready), .edge_burst_out_TVALID(outvalid),
    .zext_ln246(begin_segment), .zext_ln247({1'b0, begin_segment}),
    .zext_ln128({begin_segment, 4'b0}), .zext_ln241({begin_segment, 4'b0}),
    .emitted_slots({32'b0, begin_segment, 4'b0}), .zext_ln211(32'd65536),
    .part_vertex_count(32'd65536), .out_src(32'd0), .src(32'd0),
    .pma0(64'b0), .pma1(64'b0), .pma2(64'b0), .pma3(64'b0),
    .zext_ln208(33'd65536)
  );

  task run_case(input integer offset, input integer ready_delay);
    integer accepted, elapsed, exit_cycle;
    begin
      @(negedge clk);
      begin_segment = offset;
      ready = (ready_delay == 0);
      start = 1;
      accepted = cycle;
      exit_cycle = -1;
      // Allow combinational ap_done-cache masking after asserting start.
      #1;
      if (done) $fatal(1, "stale completion after start");
      while (!done && cycle - accepted < 300) begin
        @(negedge clk);
        if (arvalid || outvalid) $fatal(1, "empty helper issued memory or edge data");
        if (helper_ready && exit_cycle < 0) exit_cycle = cycle;
        if (cycle - accepted >= ready_delay) ready = 1;
      end
      if (!done || exit_cycle < accepted || cycle <= exit_cycle || start)
        $fatal(1, "missing start/ready/done sequence or completion timeout");
      elapsed = cycle - accepted;
      $display("EMPTY_SEGMENT offset=%0d ready_delay=%0d start_cycle=%0d exit_cycle=%0d done_cycle=%0d elapsed=%0d", offset, ready_delay, accepted, exit_cycle, cycle, elapsed);
      repeat (5) @(negedge clk);
    end
  endtask

  initial begin
    repeat (5) @(negedge clk);
    rst = 0;
    repeat (5) @(negedge clk);
    run_case(0, 0);
    run_case(16, 0);
    run_case(4096, 0);
    run_case(16, 20);
    run_case(16, 100);
    run_case(0, 0);
    $display("EMPTY_SEGMENT_PASS cases=6");
    $finish;
  end
endmodule
