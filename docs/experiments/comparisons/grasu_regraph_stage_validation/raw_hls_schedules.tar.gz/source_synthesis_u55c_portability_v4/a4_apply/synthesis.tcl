open_project project
set_top kernelApply
add_files {/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_u55c_portability_v4/a4_apply/source/acc_template/kernel_apply/kernel_apply.cpp} -cflags {-I/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_u55c_portability_v4/a4_apply/source/acc_template/common -I/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_u55c_portability_v4/a4_apply/source/acc_udfs/pr -I/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_u55c_portability_v4/a4_apply/source/acc_template/kernel_apply -DLITTLE_KERNEL_NUM=4 -DBIG_KERNEL_NUM=0 -DLITTLE_KERNEL_DST_BUFFER_SIZE=65536 -DBIG_KERNEL_DST_BUFFER_SIZE=524288 -DSRC_BUFFER_SIZE=4096 -DLOG2_SRC_BUFFER_SIZE=12 -DHAVE_APPLY_OUTDEG=1 -DHAVE_VERTEX_PROP=0 -DHAVE_UNSIGNED_PROP=0 -I/data/yxx/tools/xilinx/Vitis_HLS/2024.1/include/etc -include /home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_u55c_portability_v4/a4_apply/source/hls_portability.hpp}
open_solution -flow_target vitis solution
set_part {xcu55c-fsvh2892-2L-e}
create_clock -period 4.761904761904762 -name default
source {/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_u55c_portability_v4/a4_apply/source/acc_template/hls_config.tcl}
csynth_design
exit
