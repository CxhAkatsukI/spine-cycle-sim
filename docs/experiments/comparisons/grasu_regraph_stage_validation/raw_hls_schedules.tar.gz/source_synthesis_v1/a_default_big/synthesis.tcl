open_project project
set_top bigKernelScatterGather
add_files {/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_v1/a_default_big/source/acc_template/kernel_big_gs/kernel_scatter_gather.cpp} -cflags {-I"/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_v1/a_default_big/source/acc_template/common" -I"/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_v1/a_default_big/source/acc_udfs/pr" -I"/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_v1/a_default_big/source/acc_template/kernel_big_gs" -DLITTLE_KERNEL_NUM=11 -DBIG_KERNEL_NUM=3 -DLITTLE_KERNEL_DST_BUFFER_SIZE=65536 -DBIG_KERNEL_DST_BUFFER_SIZE=524288 -DSRC_BUFFER_SIZE=4096 -DLOG2_SRC_BUFFER_SIZE=12 -DHAVE_APPLY_OUTDEG=1 -DHAVE_VERTEX_PROP=0 -DHAVE_UNSIGNED_PROP=0}
open_solution -flow_target vitis solution
set_part {xcu280-fsvh2892-2L-e}
create_clock -period 4.761904761904762 -name default
source {/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_v1/a_default_big/source/acc_template/hls_config.tcl}
csynth_design
exit
