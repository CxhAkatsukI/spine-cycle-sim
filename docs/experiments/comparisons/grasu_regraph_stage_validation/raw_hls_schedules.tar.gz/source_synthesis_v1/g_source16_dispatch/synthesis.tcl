open_project project
set_top dispatch
add_files {/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_v1/g_source16_dispatch/source/kernel_dispatch.cpp} -cflags {-I/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_v1/g_source16_dispatch/source}
open_solution -flow_target vitis solution
set_part {xcu250-figd2104-2L-e}
create_clock -period 5.0 -name default
csynth_design
exit
