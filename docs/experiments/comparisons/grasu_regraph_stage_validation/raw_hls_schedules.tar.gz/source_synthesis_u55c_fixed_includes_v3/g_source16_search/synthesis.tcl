open_project project
set_top bin_search
add_files {/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_u55c_fixed_includes_v3/g_source16_search/source/kernel_bin_search.cpp} -cflags {-I/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/source_synthesis_u55c_fixed_includes_v3/g_source16_search/source -I/data/yxx/tools/xilinx/Vitis_HLS/2024.1/include/etc}
open_solution -flow_target vitis solution
set_part {xcu250-figd2104-2L-e}
create_clock -period 5.0 -name default
csynth_design
exit
