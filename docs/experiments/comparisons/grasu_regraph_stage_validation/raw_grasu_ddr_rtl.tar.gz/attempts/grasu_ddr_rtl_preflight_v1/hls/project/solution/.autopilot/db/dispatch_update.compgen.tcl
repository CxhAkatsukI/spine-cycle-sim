# This script segment is generated automatically by AutoPilot

# clear list
if {${::AESL::PGuard_autoexp_gen}} {
    cg_default_interface_gen_dc_begin
    cg_default_interface_gen_bundle_begin
    AESL_LIB_XILADAPTER::native_axis_begin
}

# Native AXIS:
if {${::AESL::PGuard_autoexp_gen}} {
if {[info proc ::AESL_LIB_XILADAPTER::native_axis_add] == "::AESL_LIB_XILADAPTER::native_axis_add"} {
eval "::AESL_LIB_XILADAPTER::native_axis_add { \
    id 37 \
    name update_stream_V_data_V \
    reset_level 1 \
    sync_rst true \
    corename {update_stream} \
    metadata {  } \
    op interface \
    ports { update_stream_TDATA { I 96 vector } } \
} "
} else {
puts "@W \[IMPL-110\] Cannot find bus interface model in the library. Ignored generation of bus interface for 'update_stream_V_data_V'"
}
}


# Native AXIS:
if {${::AESL::PGuard_autoexp_gen}} {
if {[info proc ::AESL_LIB_XILADAPTER::native_axis_add] == "::AESL_LIB_XILADAPTER::native_axis_add"} {
eval "::AESL_LIB_XILADAPTER::native_axis_add { \
    id 38 \
    name update_stream_V_keep_V \
    reset_level 1 \
    sync_rst true \
    corename {update_stream} \
    metadata {  } \
    op interface \
    ports { update_stream_TKEEP { I 12 vector } } \
} "
} else {
puts "@W \[IMPL-110\] Cannot find bus interface model in the library. Ignored generation of bus interface for 'update_stream_V_keep_V'"
}
}


# Native AXIS:
if {${::AESL::PGuard_autoexp_gen}} {
if {[info proc ::AESL_LIB_XILADAPTER::native_axis_add] == "::AESL_LIB_XILADAPTER::native_axis_add"} {
eval "::AESL_LIB_XILADAPTER::native_axis_add { \
    id 39 \
    name update_stream_V_strb_V \
    reset_level 1 \
    sync_rst true \
    corename {update_stream} \
    metadata {  } \
    op interface \
    ports { update_stream_TSTRB { I 12 vector } } \
} "
} else {
puts "@W \[IMPL-110\] Cannot find bus interface model in the library. Ignored generation of bus interface for 'update_stream_V_strb_V'"
}
}


# Native AXIS:
if {${::AESL::PGuard_autoexp_gen}} {
if {[info proc ::AESL_LIB_XILADAPTER::native_axis_add] == "::AESL_LIB_XILADAPTER::native_axis_add"} {
eval "::AESL_LIB_XILADAPTER::native_axis_add { \
    id 40 \
    name update_stream_V_last_V \
    reset_level 1 \
    sync_rst true \
    corename {update_stream} \
    metadata {  } \
    op interface \
    ports { update_stream_TVALID { I 1 bit } update_stream_TREADY { O 1 bit } update_stream_TLAST { I 1 vector } } \
} "
} else {
puts "@W \[IMPL-110\] Cannot find bus interface model in the library. Ignored generation of bus interface for 'update_stream_V_last_V'"
}
}


# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 41 \
    name update_stream_ddr_0_0 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_0 \
    op interface \
    ports { update_stream_ddr_0_0_din { O 96 vector } update_stream_ddr_0_0_num_data_valid { I 3 vector } update_stream_ddr_0_0_fifo_cap { I 3 vector } update_stream_ddr_0_0_full_n { I 1 bit } update_stream_ddr_0_0_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 42 \
    name update_stream_ddr_0_1 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_1 \
    op interface \
    ports { update_stream_ddr_0_1_din { O 96 vector } update_stream_ddr_0_1_num_data_valid { I 3 vector } update_stream_ddr_0_1_fifo_cap { I 3 vector } update_stream_ddr_0_1_full_n { I 1 bit } update_stream_ddr_0_1_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 43 \
    name update_stream_ddr_0_2 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_2 \
    op interface \
    ports { update_stream_ddr_0_2_din { O 96 vector } update_stream_ddr_0_2_num_data_valid { I 3 vector } update_stream_ddr_0_2_fifo_cap { I 3 vector } update_stream_ddr_0_2_full_n { I 1 bit } update_stream_ddr_0_2_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 44 \
    name update_stream_ddr_0_3 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_3 \
    op interface \
    ports { update_stream_ddr_0_3_din { O 96 vector } update_stream_ddr_0_3_num_data_valid { I 3 vector } update_stream_ddr_0_3_fifo_cap { I 3 vector } update_stream_ddr_0_3_full_n { I 1 bit } update_stream_ddr_0_3_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 45 \
    name update_stream_ddr_0_4 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_4 \
    op interface \
    ports { update_stream_ddr_0_4_din { O 96 vector } update_stream_ddr_0_4_num_data_valid { I 3 vector } update_stream_ddr_0_4_fifo_cap { I 3 vector } update_stream_ddr_0_4_full_n { I 1 bit } update_stream_ddr_0_4_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 46 \
    name update_stream_ddr_0_5 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_5 \
    op interface \
    ports { update_stream_ddr_0_5_din { O 96 vector } update_stream_ddr_0_5_num_data_valid { I 3 vector } update_stream_ddr_0_5_fifo_cap { I 3 vector } update_stream_ddr_0_5_full_n { I 1 bit } update_stream_ddr_0_5_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 47 \
    name update_stream_ddr_0_6 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_6 \
    op interface \
    ports { update_stream_ddr_0_6_din { O 96 vector } update_stream_ddr_0_6_num_data_valid { I 3 vector } update_stream_ddr_0_6_fifo_cap { I 3 vector } update_stream_ddr_0_6_full_n { I 1 bit } update_stream_ddr_0_6_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 48 \
    name update_stream_ddr_0_7 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_7 \
    op interface \
    ports { update_stream_ddr_0_7_din { O 96 vector } update_stream_ddr_0_7_num_data_valid { I 3 vector } update_stream_ddr_0_7_fifo_cap { I 3 vector } update_stream_ddr_0_7_full_n { I 1 bit } update_stream_ddr_0_7_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 49 \
    name update_stream_ddr_0_8 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_8 \
    op interface \
    ports { update_stream_ddr_0_8_din { O 96 vector } update_stream_ddr_0_8_num_data_valid { I 3 vector } update_stream_ddr_0_8_fifo_cap { I 3 vector } update_stream_ddr_0_8_full_n { I 1 bit } update_stream_ddr_0_8_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 50 \
    name update_stream_ddr_0_9 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_9 \
    op interface \
    ports { update_stream_ddr_0_9_din { O 96 vector } update_stream_ddr_0_9_num_data_valid { I 3 vector } update_stream_ddr_0_9_fifo_cap { I 3 vector } update_stream_ddr_0_9_full_n { I 1 bit } update_stream_ddr_0_9_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 51 \
    name update_stream_ddr_0_10 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_10 \
    op interface \
    ports { update_stream_ddr_0_10_din { O 96 vector } update_stream_ddr_0_10_num_data_valid { I 3 vector } update_stream_ddr_0_10_fifo_cap { I 3 vector } update_stream_ddr_0_10_full_n { I 1 bit } update_stream_ddr_0_10_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 52 \
    name update_stream_ddr_0_11 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_11 \
    op interface \
    ports { update_stream_ddr_0_11_din { O 96 vector } update_stream_ddr_0_11_num_data_valid { I 3 vector } update_stream_ddr_0_11_fifo_cap { I 3 vector } update_stream_ddr_0_11_full_n { I 1 bit } update_stream_ddr_0_11_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 53 \
    name update_stream_ddr_0_12 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_12 \
    op interface \
    ports { update_stream_ddr_0_12_din { O 96 vector } update_stream_ddr_0_12_num_data_valid { I 3 vector } update_stream_ddr_0_12_fifo_cap { I 3 vector } update_stream_ddr_0_12_full_n { I 1 bit } update_stream_ddr_0_12_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 54 \
    name update_stream_ddr_0_13 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_13 \
    op interface \
    ports { update_stream_ddr_0_13_din { O 96 vector } update_stream_ddr_0_13_num_data_valid { I 3 vector } update_stream_ddr_0_13_fifo_cap { I 3 vector } update_stream_ddr_0_13_full_n { I 1 bit } update_stream_ddr_0_13_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 55 \
    name update_stream_ddr_0_14 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_14 \
    op interface \
    ports { update_stream_ddr_0_14_din { O 96 vector } update_stream_ddr_0_14_num_data_valid { I 3 vector } update_stream_ddr_0_14_fifo_cap { I 3 vector } update_stream_ddr_0_14_full_n { I 1 bit } update_stream_ddr_0_14_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 56 \
    name update_stream_ddr_0_15 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_15 \
    op interface \
    ports { update_stream_ddr_0_15_din { O 96 vector } update_stream_ddr_0_15_num_data_valid { I 3 vector } update_stream_ddr_0_15_fifo_cap { I 3 vector } update_stream_ddr_0_15_full_n { I 1 bit } update_stream_ddr_0_15_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 57 \
    name update_stream_ddr_1_0 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_0 \
    op interface \
    ports { update_stream_ddr_1_0_din { O 96 vector } update_stream_ddr_1_0_num_data_valid { I 3 vector } update_stream_ddr_1_0_fifo_cap { I 3 vector } update_stream_ddr_1_0_full_n { I 1 bit } update_stream_ddr_1_0_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 58 \
    name update_stream_ddr_1_1 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_1 \
    op interface \
    ports { update_stream_ddr_1_1_din { O 96 vector } update_stream_ddr_1_1_num_data_valid { I 3 vector } update_stream_ddr_1_1_fifo_cap { I 3 vector } update_stream_ddr_1_1_full_n { I 1 bit } update_stream_ddr_1_1_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 59 \
    name update_stream_ddr_1_2 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_2 \
    op interface \
    ports { update_stream_ddr_1_2_din { O 96 vector } update_stream_ddr_1_2_num_data_valid { I 3 vector } update_stream_ddr_1_2_fifo_cap { I 3 vector } update_stream_ddr_1_2_full_n { I 1 bit } update_stream_ddr_1_2_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 60 \
    name update_stream_ddr_1_3 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_3 \
    op interface \
    ports { update_stream_ddr_1_3_din { O 96 vector } update_stream_ddr_1_3_num_data_valid { I 3 vector } update_stream_ddr_1_3_fifo_cap { I 3 vector } update_stream_ddr_1_3_full_n { I 1 bit } update_stream_ddr_1_3_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 61 \
    name update_stream_ddr_1_4 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_4 \
    op interface \
    ports { update_stream_ddr_1_4_din { O 96 vector } update_stream_ddr_1_4_num_data_valid { I 3 vector } update_stream_ddr_1_4_fifo_cap { I 3 vector } update_stream_ddr_1_4_full_n { I 1 bit } update_stream_ddr_1_4_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 62 \
    name update_stream_ddr_1_5 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_5 \
    op interface \
    ports { update_stream_ddr_1_5_din { O 96 vector } update_stream_ddr_1_5_num_data_valid { I 3 vector } update_stream_ddr_1_5_fifo_cap { I 3 vector } update_stream_ddr_1_5_full_n { I 1 bit } update_stream_ddr_1_5_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 63 \
    name update_stream_ddr_1_6 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_6 \
    op interface \
    ports { update_stream_ddr_1_6_din { O 96 vector } update_stream_ddr_1_6_num_data_valid { I 3 vector } update_stream_ddr_1_6_fifo_cap { I 3 vector } update_stream_ddr_1_6_full_n { I 1 bit } update_stream_ddr_1_6_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 64 \
    name update_stream_ddr_1_7 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_7 \
    op interface \
    ports { update_stream_ddr_1_7_din { O 96 vector } update_stream_ddr_1_7_num_data_valid { I 3 vector } update_stream_ddr_1_7_fifo_cap { I 3 vector } update_stream_ddr_1_7_full_n { I 1 bit } update_stream_ddr_1_7_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 65 \
    name update_stream_ddr_1_8 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_8 \
    op interface \
    ports { update_stream_ddr_1_8_din { O 96 vector } update_stream_ddr_1_8_num_data_valid { I 3 vector } update_stream_ddr_1_8_fifo_cap { I 3 vector } update_stream_ddr_1_8_full_n { I 1 bit } update_stream_ddr_1_8_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 66 \
    name update_stream_ddr_1_9 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_9 \
    op interface \
    ports { update_stream_ddr_1_9_din { O 96 vector } update_stream_ddr_1_9_num_data_valid { I 3 vector } update_stream_ddr_1_9_fifo_cap { I 3 vector } update_stream_ddr_1_9_full_n { I 1 bit } update_stream_ddr_1_9_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 67 \
    name update_stream_ddr_1_10 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_10 \
    op interface \
    ports { update_stream_ddr_1_10_din { O 96 vector } update_stream_ddr_1_10_num_data_valid { I 3 vector } update_stream_ddr_1_10_fifo_cap { I 3 vector } update_stream_ddr_1_10_full_n { I 1 bit } update_stream_ddr_1_10_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 68 \
    name update_stream_ddr_1_11 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_11 \
    op interface \
    ports { update_stream_ddr_1_11_din { O 96 vector } update_stream_ddr_1_11_num_data_valid { I 3 vector } update_stream_ddr_1_11_fifo_cap { I 3 vector } update_stream_ddr_1_11_full_n { I 1 bit } update_stream_ddr_1_11_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 69 \
    name update_stream_ddr_1_12 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_12 \
    op interface \
    ports { update_stream_ddr_1_12_din { O 96 vector } update_stream_ddr_1_12_num_data_valid { I 3 vector } update_stream_ddr_1_12_fifo_cap { I 3 vector } update_stream_ddr_1_12_full_n { I 1 bit } update_stream_ddr_1_12_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 70 \
    name update_stream_ddr_1_13 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_13 \
    op interface \
    ports { update_stream_ddr_1_13_din { O 96 vector } update_stream_ddr_1_13_num_data_valid { I 3 vector } update_stream_ddr_1_13_fifo_cap { I 3 vector } update_stream_ddr_1_13_full_n { I 1 bit } update_stream_ddr_1_13_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 71 \
    name update_stream_ddr_1_14 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_14 \
    op interface \
    ports { update_stream_ddr_1_14_din { O 96 vector } update_stream_ddr_1_14_num_data_valid { I 3 vector } update_stream_ddr_1_14_fifo_cap { I 3 vector } update_stream_ddr_1_14_full_n { I 1 bit } update_stream_ddr_1_14_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 72 \
    name update_stream_ddr_1_15 \
    type fifo \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_15 \
    op interface \
    ports { update_stream_ddr_1_15_din { O 96 vector } update_stream_ddr_1_15_num_data_valid { I 3 vector } update_stream_ddr_1_15_fifo_cap { I 3 vector } update_stream_ddr_1_15_full_n { I 1 bit } update_stream_ddr_1_15_write { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id -1 \
    name ap_ctrl \
    type ap_ctrl \
    reset_level 1 \
    sync_rst true \
    corename ap_ctrl \
    op interface \
    ports { ap_start { I 1 bit } ap_ready { O 1 bit } ap_done { O 1 bit } ap_idle { O 1 bit } ap_continue { I 1 bit } } \
} "
}


# Adapter definition:
set PortName ap_clk
set DataWd 1 
if {${::AESL::PGuard_autoexp_gen}} {
if {[info proc cg_default_interface_gen_clock] == "cg_default_interface_gen_clock"} {
eval "cg_default_interface_gen_clock { \
    id -2 \
    name ${PortName} \
    reset_level 1 \
    sync_rst true \
    corename apif_ap_clk \
    data_wd ${DataWd} \
    op interface \
}"
} else {
puts "@W \[IMPL-113\] Cannot find bus interface model in the library. Ignored generation of bus interface for '${PortName}'"
}
}


# Adapter definition:
set PortName ap_rst
set DataWd 1 
if {${::AESL::PGuard_autoexp_gen}} {
if {[info proc cg_default_interface_gen_reset] == "cg_default_interface_gen_reset"} {
eval "cg_default_interface_gen_reset { \
    id -3 \
    name ${PortName} \
    reset_level 1 \
    sync_rst true \
    corename apif_ap_rst \
    data_wd ${DataWd} \
    op interface \
}"
} else {
puts "@W \[IMPL-114\] Cannot find bus interface model in the library. Ignored generation of bus interface for '${PortName}'"
}
}



# merge
if {${::AESL::PGuard_autoexp_gen}} {
    cg_default_interface_gen_dc_end
    cg_default_interface_gen_bundle_end
    AESL_LIB_XILADAPTER::native_axis_end
}


if {${::AESL::PGuard_rtl_comp_handler}} {
	::AP::rtl_comp_handler process_ddr_regslice_both BINDTYPE {interface} TYPE {adapter} IMPL {reg_slice}
}


if {${::AESL::PGuard_rtl_comp_handler}} {
	::AP::rtl_comp_handler process_ddr_regslice_both BINDTYPE {interface} TYPE {adapter} IMPL {reg_slice}
}


if {${::AESL::PGuard_rtl_comp_handler}} {
	::AP::rtl_comp_handler process_ddr_regslice_both BINDTYPE {interface} TYPE {adapter} IMPL {reg_slice}
}


if {${::AESL::PGuard_rtl_comp_handler}} {
	::AP::rtl_comp_handler process_ddr_regslice_both BINDTYPE {interface} TYPE {adapter} IMPL {reg_slice}
}


