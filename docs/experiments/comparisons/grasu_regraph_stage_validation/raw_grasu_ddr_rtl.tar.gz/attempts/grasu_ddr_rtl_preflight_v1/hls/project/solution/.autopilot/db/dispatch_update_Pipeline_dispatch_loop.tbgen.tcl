set moduleName dispatch_update_Pipeline_dispatch_loop
set isTopModule 0
set isCombinational 0
set isDatapathOnly 0
set isPipelined 1
set pipeline_type none
set FunctionProtocol ap_ctrl_hs
set isOneStateSeq 0
set ProfileFlag 0
set StallSigGenFlag 0
set isEnableWaveformDebug 1
set hasInterrupt 0
set DLRegFirstOffset 0
set DLRegItemOffset 0
set C_modelName {dispatch_update_Pipeline_dispatch_loop}
set C_modelType { void 0 }
set ap_memory_interface_dict [dict create]
set C_modelArgList {
	{ update_stream_V_data_V int 96 regular {axi_s 0 volatile  { update_stream Data } }  }
	{ update_stream_V_keep_V int 12 regular {axi_s 0 volatile  { update_stream Keep } }  }
	{ update_stream_V_strb_V int 12 regular {axi_s 0 volatile  { update_stream Strb } }  }
	{ update_stream_V_last_V int 1 regular {axi_s 0 volatile  { update_stream Last } }  }
	{ update_stream_ddr_0_0 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_1 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_2 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_3 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_4 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_5 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_6 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_7 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_8 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_9 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_10 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_11 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_12 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_13 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_14 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_0_15 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_0 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_1 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_2 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_3 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_4 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_5 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_6 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_7 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_8 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_9 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_10 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_11 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_12 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_13 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_14 int 96 regular {fifo 1 volatile }  }
	{ update_stream_ddr_1_15 int 96 regular {fifo 1 volatile }  }
}
set hasAXIMCache 0
set hasAXIML2Cache 0
set AXIMCacheInstDict [dict create]
set C_modelArgMapList {[ 
	{ "Name" : "update_stream_V_data_V", "interface" : "axis", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_V_keep_V", "interface" : "axis", "bitwidth" : 12, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_V_strb_V", "interface" : "axis", "bitwidth" : 12, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_V_last_V", "interface" : "axis", "bitwidth" : 1, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_0", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_1", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_2", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_3", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_4", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_5", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_6", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_7", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_8", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_9", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_10", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_11", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_12", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_13", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_14", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_0_15", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_0", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_1", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_2", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_3", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_4", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_5", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_6", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_7", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_8", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_9", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_10", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_11", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_12", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_13", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_14", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} , 
 	{ "Name" : "update_stream_ddr_1_15", "interface" : "fifo", "bitwidth" : 96, "direction" : "WRITEONLY"} ]}
# RTL Port declarations: 
set portNum 172
set portList { 
	{ ap_clk sc_in sc_logic 1 clock -1 } 
	{ ap_rst sc_in sc_logic 1 reset -1 active_high_sync } 
	{ ap_start sc_in sc_logic 1 start -1 } 
	{ ap_done sc_out sc_logic 1 predone -1 } 
	{ ap_idle sc_out sc_logic 1 done -1 } 
	{ ap_ready sc_out sc_logic 1 ready -1 } 
	{ update_stream_TVALID sc_in sc_logic 1 invld 0 } 
	{ update_stream_ddr_0_14_din sc_out sc_lv 96 signal 18 } 
	{ update_stream_ddr_0_14_num_data_valid sc_in sc_lv 3 signal 18 } 
	{ update_stream_ddr_0_14_fifo_cap sc_in sc_lv 3 signal 18 } 
	{ update_stream_ddr_0_14_full_n sc_in sc_logic 1 signal 18 } 
	{ update_stream_ddr_0_14_write sc_out sc_logic 1 signal 18 } 
	{ update_stream_ddr_0_13_din sc_out sc_lv 96 signal 17 } 
	{ update_stream_ddr_0_13_num_data_valid sc_in sc_lv 3 signal 17 } 
	{ update_stream_ddr_0_13_fifo_cap sc_in sc_lv 3 signal 17 } 
	{ update_stream_ddr_0_13_full_n sc_in sc_logic 1 signal 17 } 
	{ update_stream_ddr_0_13_write sc_out sc_logic 1 signal 17 } 
	{ update_stream_ddr_0_12_din sc_out sc_lv 96 signal 16 } 
	{ update_stream_ddr_0_12_num_data_valid sc_in sc_lv 3 signal 16 } 
	{ update_stream_ddr_0_12_fifo_cap sc_in sc_lv 3 signal 16 } 
	{ update_stream_ddr_0_12_full_n sc_in sc_logic 1 signal 16 } 
	{ update_stream_ddr_0_12_write sc_out sc_logic 1 signal 16 } 
	{ update_stream_ddr_0_11_din sc_out sc_lv 96 signal 15 } 
	{ update_stream_ddr_0_11_num_data_valid sc_in sc_lv 3 signal 15 } 
	{ update_stream_ddr_0_11_fifo_cap sc_in sc_lv 3 signal 15 } 
	{ update_stream_ddr_0_11_full_n sc_in sc_logic 1 signal 15 } 
	{ update_stream_ddr_0_11_write sc_out sc_logic 1 signal 15 } 
	{ update_stream_ddr_0_10_din sc_out sc_lv 96 signal 14 } 
	{ update_stream_ddr_0_10_num_data_valid sc_in sc_lv 3 signal 14 } 
	{ update_stream_ddr_0_10_fifo_cap sc_in sc_lv 3 signal 14 } 
	{ update_stream_ddr_0_10_full_n sc_in sc_logic 1 signal 14 } 
	{ update_stream_ddr_0_10_write sc_out sc_logic 1 signal 14 } 
	{ update_stream_ddr_0_9_din sc_out sc_lv 96 signal 13 } 
	{ update_stream_ddr_0_9_num_data_valid sc_in sc_lv 3 signal 13 } 
	{ update_stream_ddr_0_9_fifo_cap sc_in sc_lv 3 signal 13 } 
	{ update_stream_ddr_0_9_full_n sc_in sc_logic 1 signal 13 } 
	{ update_stream_ddr_0_9_write sc_out sc_logic 1 signal 13 } 
	{ update_stream_ddr_0_8_din sc_out sc_lv 96 signal 12 } 
	{ update_stream_ddr_0_8_num_data_valid sc_in sc_lv 3 signal 12 } 
	{ update_stream_ddr_0_8_fifo_cap sc_in sc_lv 3 signal 12 } 
	{ update_stream_ddr_0_8_full_n sc_in sc_logic 1 signal 12 } 
	{ update_stream_ddr_0_8_write sc_out sc_logic 1 signal 12 } 
	{ update_stream_ddr_0_7_din sc_out sc_lv 96 signal 11 } 
	{ update_stream_ddr_0_7_num_data_valid sc_in sc_lv 3 signal 11 } 
	{ update_stream_ddr_0_7_fifo_cap sc_in sc_lv 3 signal 11 } 
	{ update_stream_ddr_0_7_full_n sc_in sc_logic 1 signal 11 } 
	{ update_stream_ddr_0_7_write sc_out sc_logic 1 signal 11 } 
	{ update_stream_ddr_0_6_din sc_out sc_lv 96 signal 10 } 
	{ update_stream_ddr_0_6_num_data_valid sc_in sc_lv 3 signal 10 } 
	{ update_stream_ddr_0_6_fifo_cap sc_in sc_lv 3 signal 10 } 
	{ update_stream_ddr_0_6_full_n sc_in sc_logic 1 signal 10 } 
	{ update_stream_ddr_0_6_write sc_out sc_logic 1 signal 10 } 
	{ update_stream_ddr_0_5_din sc_out sc_lv 96 signal 9 } 
	{ update_stream_ddr_0_5_num_data_valid sc_in sc_lv 3 signal 9 } 
	{ update_stream_ddr_0_5_fifo_cap sc_in sc_lv 3 signal 9 } 
	{ update_stream_ddr_0_5_full_n sc_in sc_logic 1 signal 9 } 
	{ update_stream_ddr_0_5_write sc_out sc_logic 1 signal 9 } 
	{ update_stream_ddr_0_4_din sc_out sc_lv 96 signal 8 } 
	{ update_stream_ddr_0_4_num_data_valid sc_in sc_lv 3 signal 8 } 
	{ update_stream_ddr_0_4_fifo_cap sc_in sc_lv 3 signal 8 } 
	{ update_stream_ddr_0_4_full_n sc_in sc_logic 1 signal 8 } 
	{ update_stream_ddr_0_4_write sc_out sc_logic 1 signal 8 } 
	{ update_stream_ddr_0_3_din sc_out sc_lv 96 signal 7 } 
	{ update_stream_ddr_0_3_num_data_valid sc_in sc_lv 3 signal 7 } 
	{ update_stream_ddr_0_3_fifo_cap sc_in sc_lv 3 signal 7 } 
	{ update_stream_ddr_0_3_full_n sc_in sc_logic 1 signal 7 } 
	{ update_stream_ddr_0_3_write sc_out sc_logic 1 signal 7 } 
	{ update_stream_ddr_0_2_din sc_out sc_lv 96 signal 6 } 
	{ update_stream_ddr_0_2_num_data_valid sc_in sc_lv 3 signal 6 } 
	{ update_stream_ddr_0_2_fifo_cap sc_in sc_lv 3 signal 6 } 
	{ update_stream_ddr_0_2_full_n sc_in sc_logic 1 signal 6 } 
	{ update_stream_ddr_0_2_write sc_out sc_logic 1 signal 6 } 
	{ update_stream_ddr_0_1_din sc_out sc_lv 96 signal 5 } 
	{ update_stream_ddr_0_1_num_data_valid sc_in sc_lv 3 signal 5 } 
	{ update_stream_ddr_0_1_fifo_cap sc_in sc_lv 3 signal 5 } 
	{ update_stream_ddr_0_1_full_n sc_in sc_logic 1 signal 5 } 
	{ update_stream_ddr_0_1_write sc_out sc_logic 1 signal 5 } 
	{ update_stream_ddr_0_0_din sc_out sc_lv 96 signal 4 } 
	{ update_stream_ddr_0_0_num_data_valid sc_in sc_lv 3 signal 4 } 
	{ update_stream_ddr_0_0_fifo_cap sc_in sc_lv 3 signal 4 } 
	{ update_stream_ddr_0_0_full_n sc_in sc_logic 1 signal 4 } 
	{ update_stream_ddr_0_0_write sc_out sc_logic 1 signal 4 } 
	{ update_stream_ddr_0_15_din sc_out sc_lv 96 signal 19 } 
	{ update_stream_ddr_0_15_num_data_valid sc_in sc_lv 3 signal 19 } 
	{ update_stream_ddr_0_15_fifo_cap sc_in sc_lv 3 signal 19 } 
	{ update_stream_ddr_0_15_full_n sc_in sc_logic 1 signal 19 } 
	{ update_stream_ddr_0_15_write sc_out sc_logic 1 signal 19 } 
	{ update_stream_ddr_1_14_din sc_out sc_lv 96 signal 34 } 
	{ update_stream_ddr_1_14_num_data_valid sc_in sc_lv 3 signal 34 } 
	{ update_stream_ddr_1_14_fifo_cap sc_in sc_lv 3 signal 34 } 
	{ update_stream_ddr_1_14_full_n sc_in sc_logic 1 signal 34 } 
	{ update_stream_ddr_1_14_write sc_out sc_logic 1 signal 34 } 
	{ update_stream_ddr_1_13_din sc_out sc_lv 96 signal 33 } 
	{ update_stream_ddr_1_13_num_data_valid sc_in sc_lv 3 signal 33 } 
	{ update_stream_ddr_1_13_fifo_cap sc_in sc_lv 3 signal 33 } 
	{ update_stream_ddr_1_13_full_n sc_in sc_logic 1 signal 33 } 
	{ update_stream_ddr_1_13_write sc_out sc_logic 1 signal 33 } 
	{ update_stream_ddr_1_12_din sc_out sc_lv 96 signal 32 } 
	{ update_stream_ddr_1_12_num_data_valid sc_in sc_lv 3 signal 32 } 
	{ update_stream_ddr_1_12_fifo_cap sc_in sc_lv 3 signal 32 } 
	{ update_stream_ddr_1_12_full_n sc_in sc_logic 1 signal 32 } 
	{ update_stream_ddr_1_12_write sc_out sc_logic 1 signal 32 } 
	{ update_stream_ddr_1_11_din sc_out sc_lv 96 signal 31 } 
	{ update_stream_ddr_1_11_num_data_valid sc_in sc_lv 3 signal 31 } 
	{ update_stream_ddr_1_11_fifo_cap sc_in sc_lv 3 signal 31 } 
	{ update_stream_ddr_1_11_full_n sc_in sc_logic 1 signal 31 } 
	{ update_stream_ddr_1_11_write sc_out sc_logic 1 signal 31 } 
	{ update_stream_ddr_1_10_din sc_out sc_lv 96 signal 30 } 
	{ update_stream_ddr_1_10_num_data_valid sc_in sc_lv 3 signal 30 } 
	{ update_stream_ddr_1_10_fifo_cap sc_in sc_lv 3 signal 30 } 
	{ update_stream_ddr_1_10_full_n sc_in sc_logic 1 signal 30 } 
	{ update_stream_ddr_1_10_write sc_out sc_logic 1 signal 30 } 
	{ update_stream_ddr_1_9_din sc_out sc_lv 96 signal 29 } 
	{ update_stream_ddr_1_9_num_data_valid sc_in sc_lv 3 signal 29 } 
	{ update_stream_ddr_1_9_fifo_cap sc_in sc_lv 3 signal 29 } 
	{ update_stream_ddr_1_9_full_n sc_in sc_logic 1 signal 29 } 
	{ update_stream_ddr_1_9_write sc_out sc_logic 1 signal 29 } 
	{ update_stream_ddr_1_8_din sc_out sc_lv 96 signal 28 } 
	{ update_stream_ddr_1_8_num_data_valid sc_in sc_lv 3 signal 28 } 
	{ update_stream_ddr_1_8_fifo_cap sc_in sc_lv 3 signal 28 } 
	{ update_stream_ddr_1_8_full_n sc_in sc_logic 1 signal 28 } 
	{ update_stream_ddr_1_8_write sc_out sc_logic 1 signal 28 } 
	{ update_stream_ddr_1_7_din sc_out sc_lv 96 signal 27 } 
	{ update_stream_ddr_1_7_num_data_valid sc_in sc_lv 3 signal 27 } 
	{ update_stream_ddr_1_7_fifo_cap sc_in sc_lv 3 signal 27 } 
	{ update_stream_ddr_1_7_full_n sc_in sc_logic 1 signal 27 } 
	{ update_stream_ddr_1_7_write sc_out sc_logic 1 signal 27 } 
	{ update_stream_ddr_1_6_din sc_out sc_lv 96 signal 26 } 
	{ update_stream_ddr_1_6_num_data_valid sc_in sc_lv 3 signal 26 } 
	{ update_stream_ddr_1_6_fifo_cap sc_in sc_lv 3 signal 26 } 
	{ update_stream_ddr_1_6_full_n sc_in sc_logic 1 signal 26 } 
	{ update_stream_ddr_1_6_write sc_out sc_logic 1 signal 26 } 
	{ update_stream_ddr_1_5_din sc_out sc_lv 96 signal 25 } 
	{ update_stream_ddr_1_5_num_data_valid sc_in sc_lv 3 signal 25 } 
	{ update_stream_ddr_1_5_fifo_cap sc_in sc_lv 3 signal 25 } 
	{ update_stream_ddr_1_5_full_n sc_in sc_logic 1 signal 25 } 
	{ update_stream_ddr_1_5_write sc_out sc_logic 1 signal 25 } 
	{ update_stream_ddr_1_4_din sc_out sc_lv 96 signal 24 } 
	{ update_stream_ddr_1_4_num_data_valid sc_in sc_lv 3 signal 24 } 
	{ update_stream_ddr_1_4_fifo_cap sc_in sc_lv 3 signal 24 } 
	{ update_stream_ddr_1_4_full_n sc_in sc_logic 1 signal 24 } 
	{ update_stream_ddr_1_4_write sc_out sc_logic 1 signal 24 } 
	{ update_stream_ddr_1_3_din sc_out sc_lv 96 signal 23 } 
	{ update_stream_ddr_1_3_num_data_valid sc_in sc_lv 3 signal 23 } 
	{ update_stream_ddr_1_3_fifo_cap sc_in sc_lv 3 signal 23 } 
	{ update_stream_ddr_1_3_full_n sc_in sc_logic 1 signal 23 } 
	{ update_stream_ddr_1_3_write sc_out sc_logic 1 signal 23 } 
	{ update_stream_ddr_1_2_din sc_out sc_lv 96 signal 22 } 
	{ update_stream_ddr_1_2_num_data_valid sc_in sc_lv 3 signal 22 } 
	{ update_stream_ddr_1_2_fifo_cap sc_in sc_lv 3 signal 22 } 
	{ update_stream_ddr_1_2_full_n sc_in sc_logic 1 signal 22 } 
	{ update_stream_ddr_1_2_write sc_out sc_logic 1 signal 22 } 
	{ update_stream_ddr_1_1_din sc_out sc_lv 96 signal 21 } 
	{ update_stream_ddr_1_1_num_data_valid sc_in sc_lv 3 signal 21 } 
	{ update_stream_ddr_1_1_fifo_cap sc_in sc_lv 3 signal 21 } 
	{ update_stream_ddr_1_1_full_n sc_in sc_logic 1 signal 21 } 
	{ update_stream_ddr_1_1_write sc_out sc_logic 1 signal 21 } 
	{ update_stream_ddr_1_0_din sc_out sc_lv 96 signal 20 } 
	{ update_stream_ddr_1_0_num_data_valid sc_in sc_lv 3 signal 20 } 
	{ update_stream_ddr_1_0_fifo_cap sc_in sc_lv 3 signal 20 } 
	{ update_stream_ddr_1_0_full_n sc_in sc_logic 1 signal 20 } 
	{ update_stream_ddr_1_0_write sc_out sc_logic 1 signal 20 } 
	{ update_stream_ddr_1_15_din sc_out sc_lv 96 signal 35 } 
	{ update_stream_ddr_1_15_num_data_valid sc_in sc_lv 3 signal 35 } 
	{ update_stream_ddr_1_15_fifo_cap sc_in sc_lv 3 signal 35 } 
	{ update_stream_ddr_1_15_full_n sc_in sc_logic 1 signal 35 } 
	{ update_stream_ddr_1_15_write sc_out sc_logic 1 signal 35 } 
	{ update_stream_TDATA sc_in sc_lv 96 signal 0 } 
	{ update_stream_TREADY sc_out sc_logic 1 inacc 3 } 
	{ update_stream_TKEEP sc_in sc_lv 12 signal 1 } 
	{ update_stream_TSTRB sc_in sc_lv 12 signal 2 } 
	{ update_stream_TLAST sc_in sc_lv 1 signal 3 } 
}
set NewPortList {[ 
	{ "name": "ap_clk", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "clock", "bundle":{"name": "ap_clk", "role": "default" }} , 
 	{ "name": "ap_rst", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "reset", "bundle":{"name": "ap_rst", "role": "default" }} , 
 	{ "name": "ap_start", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "start", "bundle":{"name": "ap_start", "role": "default" }} , 
 	{ "name": "ap_done", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "predone", "bundle":{"name": "ap_done", "role": "default" }} , 
 	{ "name": "ap_idle", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "done", "bundle":{"name": "ap_idle", "role": "default" }} , 
 	{ "name": "ap_ready", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "ready", "bundle":{"name": "ap_ready", "role": "default" }} , 
 	{ "name": "update_stream_TVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "invld", "bundle":{"name": "update_stream_V_data_V", "role": "default" }} , 
 	{ "name": "update_stream_ddr_0_14_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_14", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_14_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_14", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_14_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_14", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_14_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_14", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_14_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_14", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_13_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_13", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_13_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_13", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_13_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_13", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_13_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_13", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_13_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_13", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_12_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_12", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_12_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_12", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_12_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_12", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_12_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_12", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_12_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_12", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_11_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_11", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_11_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_11", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_11_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_11", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_11_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_11", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_11_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_11", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_10_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_10", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_10_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_10", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_10_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_10", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_10_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_10", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_10_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_10", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_9_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_9", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_9_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_9", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_9_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_9", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_9_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_9", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_9_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_9", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_8_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_8", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_8_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_8", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_8_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_8", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_8_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_8", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_8_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_8", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_7_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_7", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_7_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_7", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_7_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_7", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_7_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_7", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_7_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_7", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_6_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_6", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_6_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_6", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_6_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_6", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_6_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_6", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_6_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_6", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_5_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_5", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_5_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_5", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_5_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_5", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_5_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_5", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_5_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_5", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_4_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_4", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_4_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_4", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_4_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_4", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_4_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_4", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_4_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_4", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_3_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_3", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_3_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_3", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_3_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_3", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_3_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_3", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_3_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_3", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_2_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_2", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_2_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_2", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_2_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_2", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_2_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_2", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_2_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_2", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_1_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_1", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_1_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_1", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_1_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_1", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_1_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_1", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_1_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_1", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_0_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_0", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_0_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_0", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_0_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_0", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_0_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_0", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_0_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_0", "role": "write" }} , 
 	{ "name": "update_stream_ddr_0_15_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_15", "role": "din" }} , 
 	{ "name": "update_stream_ddr_0_15_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_15", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_15_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_15", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_15_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_15", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_0_15_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_15", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_14_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_14", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_14_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_14", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_14_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_14", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_14_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_14", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_14_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_14", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_13_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_13", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_13_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_13", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_13_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_13", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_13_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_13", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_13_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_13", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_12_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_12", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_12_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_12", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_12_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_12", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_12_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_12", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_12_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_12", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_11_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_11", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_11_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_11", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_11_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_11", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_11_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_11", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_11_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_11", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_10_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_10", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_10_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_10", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_10_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_10", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_10_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_10", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_10_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_10", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_9_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_9", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_9_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_9", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_9_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_9", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_9_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_9", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_9_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_9", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_8_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_8", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_8_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_8", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_8_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_8", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_8_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_8", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_8_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_8", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_7_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_7", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_7_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_7", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_7_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_7", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_7_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_7", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_7_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_7", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_6_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_6", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_6_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_6", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_6_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_6", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_6_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_6", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_6_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_6", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_5_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_5", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_5_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_5", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_5_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_5", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_5_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_5", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_5_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_5", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_4_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_4", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_4_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_4", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_4_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_4", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_4_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_4", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_4_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_4", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_3_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_3", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_3_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_3", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_3_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_3", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_3_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_3", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_3_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_3", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_2_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_2", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_2_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_2", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_2_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_2", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_2_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_2", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_2_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_2", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_1_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_1", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_1_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_1", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_1_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_1", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_1_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_1", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_1_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_1", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_0_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_0", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_0_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_0", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_0_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_0", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_0_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_0", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_0_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_0", "role": "write" }} , 
 	{ "name": "update_stream_ddr_1_15_din", "direction": "out", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_15", "role": "din" }} , 
 	{ "name": "update_stream_ddr_1_15_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_15", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_15_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_15", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_15_full_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_15", "role": "full_n" }} , 
 	{ "name": "update_stream_ddr_1_15_write", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_15", "role": "write" }} , 
 	{ "name": "update_stream_TDATA", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_V_data_V", "role": "default" }} , 
 	{ "name": "update_stream_TREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "inacc", "bundle":{"name": "update_stream_V_last_V", "role": "default" }} , 
 	{ "name": "update_stream_TKEEP", "direction": "in", "datatype": "sc_lv", "bitwidth":12, "type": "signal", "bundle":{"name": "update_stream_V_keep_V", "role": "default" }} , 
 	{ "name": "update_stream_TSTRB", "direction": "in", "datatype": "sc_lv", "bitwidth":12, "type": "signal", "bundle":{"name": "update_stream_V_strb_V", "role": "default" }} , 
 	{ "name": "update_stream_TLAST", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_V_last_V", "role": "default" }}  ]}

set RtlHierarchyInfo {[
	{"ID" : "0", "Level" : "0", "Path" : "`AUTOTB_DUT_INST", "Parent" : "", "Child" : ["1"],
		"CDFG" : "dispatch_update_Pipeline_dispatch_loop",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "0", "ap_idle" : "1", "real_start" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "0",
		"VariableLatency" : "1", "ExactLatency" : "-1", "EstimateLatencyMin" : "-1", "EstimateLatencyMax" : "-1",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"IsBlackBox" : "0",
		"Port" : [
			{"Name" : "update_stream_V_data_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream",
				"BlockSignal" : [
					{"Name" : "update_stream_TDATA_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_V_keep_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream"},
			{"Name" : "update_stream_V_strb_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream"},
			{"Name" : "update_stream_V_last_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream"},
			{"Name" : "update_stream_ddr_0_0", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_0_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_1", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_1_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_2", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_2_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_3", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_3_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_4", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_4_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_5", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_5_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_6", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_6_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_7", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_7_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_8", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_8_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_9", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_9_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_10", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_10_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_11", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_11_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_12", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_12_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_13", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_13_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_14", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_14_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_15", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_15_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_0", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_0_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_1", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_1_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_2", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_2_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_3", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_3_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_4", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_4_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_5", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_5_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_6", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_6_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_7", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_7_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_8", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_8_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_9", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_9_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_10", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_10_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_11", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_11_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_12", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_12_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_13", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_13_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_14", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_14_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_15", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_15_blk_n", "Type" : "RtlSignal"}]}],
		"Loop" : [
			{"Name" : "dispatch_loop", "PipelineType" : "UPC",
				"LoopDec" : {"FSMBitwidth" : "1", "FirstState" : "ap_ST_fsm_pp0_stage0", "FirstStateIter" : "ap_enable_reg_pp0_iter0", "FirstStateBlock" : "ap_block_pp0_stage0_subdone", "LastState" : "ap_ST_fsm_pp0_stage0", "LastStateIter" : "ap_enable_reg_pp0_iter1", "LastStateBlock" : "ap_block_pp0_stage0_subdone", "QuitState" : "ap_ST_fsm_pp0_stage0", "QuitStateIter" : "ap_enable_reg_pp0_iter1", "QuitStateBlock" : "ap_block_pp0_stage0_subdone", "OneDepthLoop" : "0", "has_ap_ctrl" : "1", "has_continue" : "0"}}]},
	{"ID" : "1", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.flow_control_loop_pipe_sequential_init_U", "Parent" : "0"}]}


set ArgLastReadFirstWriteLatency {
	dispatch_update_Pipeline_dispatch_loop {
		update_stream_V_data_V {Type I LastRead 0 FirstWrite -1}
		update_stream_V_keep_V {Type I LastRead 0 FirstWrite -1}
		update_stream_V_strb_V {Type I LastRead 0 FirstWrite -1}
		update_stream_V_last_V {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_0 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_1 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_2 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_3 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_4 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_5 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_6 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_7 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_8 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_9 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_10 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_11 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_12 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_13 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_14 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_15 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_0 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_1 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_2 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_3 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_4 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_5 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_6 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_7 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_8 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_9 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_10 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_11 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_12 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_13 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_14 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_15 {Type O LastRead -1 FirstWrite 1}}}

set hasDtUnsupportedChannel 0

set PerformanceInfo {[
	{"Name" : "Latency", "Min" : "-1", "Max" : "-1"}
	, {"Name" : "Interval", "Min" : "-1", "Max" : "-1"}
]}

set PipelineEnableSignalInfo {[
	{"Pipeline" : "0", "EnableSignal" : "ap_enable_pp0"}
]}

set Spec2ImplPortList { 
	update_stream_V_data_V { axis {  { update_stream_TVALID in_vld 0 1 }  { update_stream_TDATA in_data 0 96 } } }
	update_stream_V_keep_V { axis {  { update_stream_TKEEP in_data 0 12 } } }
	update_stream_V_strb_V { axis {  { update_stream_TSTRB in_data 0 12 } } }
	update_stream_V_last_V { axis {  { update_stream_TREADY in_acc 1 1 }  { update_stream_TLAST in_data 0 1 } } }
	update_stream_ddr_0_0 { ap_fifo {  { update_stream_ddr_0_0_din fifo_data_in 1 96 }  { update_stream_ddr_0_0_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_0_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_0_full_n fifo_status 0 1 }  { update_stream_ddr_0_0_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_1 { ap_fifo {  { update_stream_ddr_0_1_din fifo_data_in 1 96 }  { update_stream_ddr_0_1_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_1_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_1_full_n fifo_status 0 1 }  { update_stream_ddr_0_1_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_2 { ap_fifo {  { update_stream_ddr_0_2_din fifo_data_in 1 96 }  { update_stream_ddr_0_2_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_2_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_2_full_n fifo_status 0 1 }  { update_stream_ddr_0_2_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_3 { ap_fifo {  { update_stream_ddr_0_3_din fifo_data_in 1 96 }  { update_stream_ddr_0_3_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_3_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_3_full_n fifo_status 0 1 }  { update_stream_ddr_0_3_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_4 { ap_fifo {  { update_stream_ddr_0_4_din fifo_data_in 1 96 }  { update_stream_ddr_0_4_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_4_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_4_full_n fifo_status 0 1 }  { update_stream_ddr_0_4_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_5 { ap_fifo {  { update_stream_ddr_0_5_din fifo_data_in 1 96 }  { update_stream_ddr_0_5_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_5_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_5_full_n fifo_status 0 1 }  { update_stream_ddr_0_5_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_6 { ap_fifo {  { update_stream_ddr_0_6_din fifo_data_in 1 96 }  { update_stream_ddr_0_6_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_6_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_6_full_n fifo_status 0 1 }  { update_stream_ddr_0_6_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_7 { ap_fifo {  { update_stream_ddr_0_7_din fifo_data_in 1 96 }  { update_stream_ddr_0_7_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_7_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_7_full_n fifo_status 0 1 }  { update_stream_ddr_0_7_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_8 { ap_fifo {  { update_stream_ddr_0_8_din fifo_data_in 1 96 }  { update_stream_ddr_0_8_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_8_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_8_full_n fifo_status 0 1 }  { update_stream_ddr_0_8_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_9 { ap_fifo {  { update_stream_ddr_0_9_din fifo_data_in 1 96 }  { update_stream_ddr_0_9_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_9_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_9_full_n fifo_status 0 1 }  { update_stream_ddr_0_9_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_10 { ap_fifo {  { update_stream_ddr_0_10_din fifo_data_in 1 96 }  { update_stream_ddr_0_10_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_10_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_10_full_n fifo_status 0 1 }  { update_stream_ddr_0_10_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_11 { ap_fifo {  { update_stream_ddr_0_11_din fifo_data_in 1 96 }  { update_stream_ddr_0_11_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_11_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_11_full_n fifo_status 0 1 }  { update_stream_ddr_0_11_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_12 { ap_fifo {  { update_stream_ddr_0_12_din fifo_data_in 1 96 }  { update_stream_ddr_0_12_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_12_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_12_full_n fifo_status 0 1 }  { update_stream_ddr_0_12_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_13 { ap_fifo {  { update_stream_ddr_0_13_din fifo_data_in 1 96 }  { update_stream_ddr_0_13_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_13_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_13_full_n fifo_status 0 1 }  { update_stream_ddr_0_13_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_14 { ap_fifo {  { update_stream_ddr_0_14_din fifo_data_in 1 96 }  { update_stream_ddr_0_14_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_14_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_14_full_n fifo_status 0 1 }  { update_stream_ddr_0_14_write fifo_port_we 1 1 } } }
	update_stream_ddr_0_15 { ap_fifo {  { update_stream_ddr_0_15_din fifo_data_in 1 96 }  { update_stream_ddr_0_15_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_15_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_15_full_n fifo_status 0 1 }  { update_stream_ddr_0_15_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_0 { ap_fifo {  { update_stream_ddr_1_0_din fifo_data_in 1 96 }  { update_stream_ddr_1_0_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_0_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_0_full_n fifo_status 0 1 }  { update_stream_ddr_1_0_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_1 { ap_fifo {  { update_stream_ddr_1_1_din fifo_data_in 1 96 }  { update_stream_ddr_1_1_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_1_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_1_full_n fifo_status 0 1 }  { update_stream_ddr_1_1_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_2 { ap_fifo {  { update_stream_ddr_1_2_din fifo_data_in 1 96 }  { update_stream_ddr_1_2_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_2_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_2_full_n fifo_status 0 1 }  { update_stream_ddr_1_2_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_3 { ap_fifo {  { update_stream_ddr_1_3_din fifo_data_in 1 96 }  { update_stream_ddr_1_3_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_3_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_3_full_n fifo_status 0 1 }  { update_stream_ddr_1_3_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_4 { ap_fifo {  { update_stream_ddr_1_4_din fifo_data_in 1 96 }  { update_stream_ddr_1_4_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_4_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_4_full_n fifo_status 0 1 }  { update_stream_ddr_1_4_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_5 { ap_fifo {  { update_stream_ddr_1_5_din fifo_data_in 1 96 }  { update_stream_ddr_1_5_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_5_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_5_full_n fifo_status 0 1 }  { update_stream_ddr_1_5_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_6 { ap_fifo {  { update_stream_ddr_1_6_din fifo_data_in 1 96 }  { update_stream_ddr_1_6_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_6_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_6_full_n fifo_status 0 1 }  { update_stream_ddr_1_6_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_7 { ap_fifo {  { update_stream_ddr_1_7_din fifo_data_in 1 96 }  { update_stream_ddr_1_7_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_7_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_7_full_n fifo_status 0 1 }  { update_stream_ddr_1_7_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_8 { ap_fifo {  { update_stream_ddr_1_8_din fifo_data_in 1 96 }  { update_stream_ddr_1_8_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_8_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_8_full_n fifo_status 0 1 }  { update_stream_ddr_1_8_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_9 { ap_fifo {  { update_stream_ddr_1_9_din fifo_data_in 1 96 }  { update_stream_ddr_1_9_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_9_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_9_full_n fifo_status 0 1 }  { update_stream_ddr_1_9_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_10 { ap_fifo {  { update_stream_ddr_1_10_din fifo_data_in 1 96 }  { update_stream_ddr_1_10_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_10_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_10_full_n fifo_status 0 1 }  { update_stream_ddr_1_10_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_11 { ap_fifo {  { update_stream_ddr_1_11_din fifo_data_in 1 96 }  { update_stream_ddr_1_11_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_11_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_11_full_n fifo_status 0 1 }  { update_stream_ddr_1_11_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_12 { ap_fifo {  { update_stream_ddr_1_12_din fifo_data_in 1 96 }  { update_stream_ddr_1_12_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_12_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_12_full_n fifo_status 0 1 }  { update_stream_ddr_1_12_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_13 { ap_fifo {  { update_stream_ddr_1_13_din fifo_data_in 1 96 }  { update_stream_ddr_1_13_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_13_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_13_full_n fifo_status 0 1 }  { update_stream_ddr_1_13_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_14 { ap_fifo {  { update_stream_ddr_1_14_din fifo_data_in 1 96 }  { update_stream_ddr_1_14_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_14_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_14_full_n fifo_status 0 1 }  { update_stream_ddr_1_14_write fifo_port_we 1 1 } } }
	update_stream_ddr_1_15 { ap_fifo {  { update_stream_ddr_1_15_din fifo_data_in 1 96 }  { update_stream_ddr_1_15_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_15_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_15_full_n fifo_status 0 1 }  { update_stream_ddr_1_15_write fifo_port_we 1 1 } } }
}
