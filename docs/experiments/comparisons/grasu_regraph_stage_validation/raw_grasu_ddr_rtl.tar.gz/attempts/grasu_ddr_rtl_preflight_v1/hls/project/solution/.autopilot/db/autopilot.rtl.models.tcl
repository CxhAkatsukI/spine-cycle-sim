set SynModuleInfo {
  {SRCNAME dispatch_update_Pipeline_dispatch_loop MODELNAME dispatch_update_Pipeline_dispatch_loop RTLNAME process_ddr_dispatch_update_Pipeline_dispatch_loop
    SUBMODULES {
      {MODELNAME process_ddr_flow_control_loop_pipe_sequential_init RTLNAME process_ddr_flow_control_loop_pipe_sequential_init BINDTYPE interface TYPE internal_upc_flow_control INSTNAME process_ddr_flow_control_loop_pipe_sequential_init_U}
    }
  }
  {SRCNAME dispatch_update MODELNAME dispatch_update RTLNAME process_ddr_dispatch_update
    SUBMODULES {
      {MODELNAME process_ddr_regslice_both RTLNAME process_ddr_regslice_both BINDTYPE interface TYPE adapter IMPL reg_slice}
    }
  }
  {SRCNAME process_Pipeline_process_ddr_sub_loop MODELNAME process_Pipeline_process_ddr_sub_loop RTLNAME process_ddr_process_Pipeline_process_ddr_sub_loop
    SUBMODULES {
      {MODELNAME process_ddr_sparsemux_7_2_512_1_1 RTLNAME process_ddr_sparsemux_7_2_512_1_1 BINDTYPE op TYPE sparsemux IMPL auto}
    }
  }
  {SRCNAME process MODELNAME process_r RTLNAME process_ddr_process_r}
  {SRCNAME process.1_Pipeline_process_ddr_sub_loop MODELNAME process_1_Pipeline_process_ddr_sub_loop RTLNAME process_ddr_process_1_Pipeline_process_ddr_sub_loop}
  {SRCNAME process.1 MODELNAME process_1 RTLNAME process_ddr_process_1}
  {SRCNAME process_ddr MODELNAME process_ddr RTLNAME process_ddr IS_TOP 1
    SUBMODULES {
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_1_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_2_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_3_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_4_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_5_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_6_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_7_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_8_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_9_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_10_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_11_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_12_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_13_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_14_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_0_15_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_1_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_2_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_3_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_4_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_5_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_6_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_7_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_8_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_9_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_10_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_11_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_12_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_13_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_14_U}
      {MODELNAME process_ddr_fifo_w96_d2_S RTLNAME process_ddr_fifo_w96_d2_S BINDTYPE storage TYPE fifo IMPL srl ALLOW_PRAGMA 1 INSTNAME update_stream_ddr_1_15_U}
      {MODELNAME process_ddr_gmem0_m_axi RTLNAME process_ddr_gmem0_m_axi BINDTYPE interface TYPE adapter IMPL m_axi}
      {MODELNAME process_ddr_gmem1_m_axi RTLNAME process_ddr_gmem1_m_axi BINDTYPE interface TYPE adapter IMPL m_axi}
      {MODELNAME process_ddr_gmem2_m_axi RTLNAME process_ddr_gmem2_m_axi BINDTYPE interface TYPE adapter IMPL m_axi}
      {MODELNAME process_ddr_gmem3_m_axi RTLNAME process_ddr_gmem3_m_axi BINDTYPE interface TYPE adapter IMPL m_axi}
      {MODELNAME process_ddr_control_s_axi RTLNAME process_ddr_control_s_axi BINDTYPE interface TYPE interface_s_axilite}
    }
  }
}
