set moduleName process_ddr
set isTopModule 1
set isCombinational 0
set isDatapathOnly 0
set isPipelined 1
set pipeline_type dataflow
set FunctionProtocol ap_ctrl_chain
set isOneStateSeq 0
set ProfileFlag 0
set StallSigGenFlag 0
set isEnableWaveformDebug 1
set hasInterrupt 0
set DLRegFirstOffset 0
set DLRegItemOffset 0
set C_modelName {process_ddr}
set C_modelType { void 0 }
set ap_memory_interface_dict [dict create]
set C_modelArgList {
	{ gmem0 int 512 regular {axi_master 0}  }
	{ gmem1 int 512 regular {axi_master 0}  }
	{ gmem2 int 512 regular {axi_master 1}  }
	{ gmem3 int 512 regular {axi_master 1}  }
	{ pma_in0_ddr int 64 regular {axi_slave 0}  }
	{ pma_in1_ddr int 64 regular {axi_slave 0}  }
	{ pma_out0_ddr int 64 regular {axi_slave 0}  }
	{ pma_out1_ddr int 64 regular {axi_slave 0}  }
	{ update_stream_V_data_V int 96 regular {axi_s 0 volatile  { update_stream Data } }  }
	{ update_stream_V_keep_V int 12 regular {axi_s 0 volatile  { update_stream Keep } }  }
	{ update_stream_V_strb_V int 12 regular {axi_s 0 volatile  { update_stream Strb } }  }
	{ update_stream_V_last_V int 1 regular {axi_s 0 volatile  { update_stream Last } }  }
}
set hasAXIMCache 0
set hasAXIML2Cache 0
set AXIMCacheInstDict [dict create]
set C_modelArgMapList {[ 
	{ "Name" : "gmem0", "interface" : "axi_master", "bitwidth" : 512, "direction" : "READONLY", "bitSlice":[ {"cElement": [{"cName": "pma_in0_ddr","offset": { "type": "dynamic","port_name": "pma_in0_ddr","bundle": "control"},"direction": "READONLY"}]}]} , 
 	{ "Name" : "gmem1", "interface" : "axi_master", "bitwidth" : 512, "direction" : "READONLY", "bitSlice":[ {"cElement": [{"cName": "pma_in1_ddr","offset": { "type": "dynamic","port_name": "pma_in1_ddr","bundle": "control"},"direction": "READONLY"}]}]} , 
 	{ "Name" : "gmem2", "interface" : "axi_master", "bitwidth" : 512, "direction" : "WRITEONLY", "bitSlice":[ {"cElement": [{"cName": "pma_out0_ddr","offset": { "type": "dynamic","port_name": "pma_out0_ddr","bundle": "control"},"direction": "WRITEONLY"}]}]} , 
 	{ "Name" : "gmem3", "interface" : "axi_master", "bitwidth" : 512, "direction" : "WRITEONLY", "bitSlice":[ {"cElement": [{"cName": "pma_out1_ddr","offset": { "type": "dynamic","port_name": "pma_out1_ddr","bundle": "control"},"direction": "WRITEONLY"}]}]} , 
 	{ "Name" : "pma_in0_ddr", "interface" : "axi_slave", "bundle":"control","type":"ap_none","bitwidth" : 64, "direction" : "READONLY", "offset" : {"in":16}, "offset_end" : {"in":27}} , 
 	{ "Name" : "pma_in1_ddr", "interface" : "axi_slave", "bundle":"control","type":"ap_none","bitwidth" : 64, "direction" : "READONLY", "offset" : {"in":28}, "offset_end" : {"in":39}} , 
 	{ "Name" : "pma_out0_ddr", "interface" : "axi_slave", "bundle":"control","type":"ap_none","bitwidth" : 64, "direction" : "READONLY", "offset" : {"in":40}, "offset_end" : {"in":51}} , 
 	{ "Name" : "pma_out1_ddr", "interface" : "axi_slave", "bundle":"control","type":"ap_none","bitwidth" : 64, "direction" : "READONLY", "offset" : {"in":52}, "offset_end" : {"in":63}} , 
 	{ "Name" : "update_stream_V_data_V", "interface" : "axis", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_V_keep_V", "interface" : "axis", "bitwidth" : 12, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_V_strb_V", "interface" : "axis", "bitwidth" : 12, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_V_last_V", "interface" : "axis", "bitwidth" : 1, "direction" : "READONLY"} ]}
# RTL Port declarations: 
set portNum 206
set portList { 
	{ s_axi_control_AWVALID sc_in sc_logic 1 signal -1 } 
	{ s_axi_control_AWREADY sc_out sc_logic 1 signal -1 } 
	{ s_axi_control_AWADDR sc_in sc_lv 6 signal -1 } 
	{ s_axi_control_WVALID sc_in sc_logic 1 signal -1 } 
	{ s_axi_control_WREADY sc_out sc_logic 1 signal -1 } 
	{ s_axi_control_WDATA sc_in sc_lv 32 signal -1 } 
	{ s_axi_control_WSTRB sc_in sc_lv 4 signal -1 } 
	{ s_axi_control_ARVALID sc_in sc_logic 1 signal -1 } 
	{ s_axi_control_ARREADY sc_out sc_logic 1 signal -1 } 
	{ s_axi_control_ARADDR sc_in sc_lv 6 signal -1 } 
	{ s_axi_control_RVALID sc_out sc_logic 1 signal -1 } 
	{ s_axi_control_RREADY sc_in sc_logic 1 signal -1 } 
	{ s_axi_control_RDATA sc_out sc_lv 32 signal -1 } 
	{ s_axi_control_RRESP sc_out sc_lv 2 signal -1 } 
	{ s_axi_control_BVALID sc_out sc_logic 1 signal -1 } 
	{ s_axi_control_BREADY sc_in sc_logic 1 signal -1 } 
	{ s_axi_control_BRESP sc_out sc_lv 2 signal -1 } 
	{ ap_clk sc_in sc_logic 1 clock -1 } 
	{ ap_rst_n sc_in sc_logic 1 reset -1 active_low_sync } 
	{ interrupt sc_out sc_logic 1 signal -1 } 
	{ m_axi_gmem0_AWVALID sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem0_AWREADY sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem0_AWADDR sc_out sc_lv 64 signal 0 } 
	{ m_axi_gmem0_AWID sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem0_AWLEN sc_out sc_lv 8 signal 0 } 
	{ m_axi_gmem0_AWSIZE sc_out sc_lv 3 signal 0 } 
	{ m_axi_gmem0_AWBURST sc_out sc_lv 2 signal 0 } 
	{ m_axi_gmem0_AWLOCK sc_out sc_lv 2 signal 0 } 
	{ m_axi_gmem0_AWCACHE sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem0_AWPROT sc_out sc_lv 3 signal 0 } 
	{ m_axi_gmem0_AWQOS sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem0_AWREGION sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem0_AWUSER sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem0_WVALID sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem0_WREADY sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem0_WDATA sc_out sc_lv 512 signal 0 } 
	{ m_axi_gmem0_WSTRB sc_out sc_lv 64 signal 0 } 
	{ m_axi_gmem0_WLAST sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem0_WID sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem0_WUSER sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem0_ARVALID sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem0_ARREADY sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem0_ARADDR sc_out sc_lv 64 signal 0 } 
	{ m_axi_gmem0_ARID sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem0_ARLEN sc_out sc_lv 8 signal 0 } 
	{ m_axi_gmem0_ARSIZE sc_out sc_lv 3 signal 0 } 
	{ m_axi_gmem0_ARBURST sc_out sc_lv 2 signal 0 } 
	{ m_axi_gmem0_ARLOCK sc_out sc_lv 2 signal 0 } 
	{ m_axi_gmem0_ARCACHE sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem0_ARPROT sc_out sc_lv 3 signal 0 } 
	{ m_axi_gmem0_ARQOS sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem0_ARREGION sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem0_ARUSER sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem0_RVALID sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem0_RREADY sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem0_RDATA sc_in sc_lv 512 signal 0 } 
	{ m_axi_gmem0_RLAST sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem0_RID sc_in sc_lv 1 signal 0 } 
	{ m_axi_gmem0_RUSER sc_in sc_lv 1 signal 0 } 
	{ m_axi_gmem0_RRESP sc_in sc_lv 2 signal 0 } 
	{ m_axi_gmem0_BVALID sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem0_BREADY sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem0_BRESP sc_in sc_lv 2 signal 0 } 
	{ m_axi_gmem0_BID sc_in sc_lv 1 signal 0 } 
	{ m_axi_gmem0_BUSER sc_in sc_lv 1 signal 0 } 
	{ m_axi_gmem1_AWVALID sc_out sc_logic 1 signal 1 } 
	{ m_axi_gmem1_AWREADY sc_in sc_logic 1 signal 1 } 
	{ m_axi_gmem1_AWADDR sc_out sc_lv 64 signal 1 } 
	{ m_axi_gmem1_AWID sc_out sc_lv 1 signal 1 } 
	{ m_axi_gmem1_AWLEN sc_out sc_lv 8 signal 1 } 
	{ m_axi_gmem1_AWSIZE sc_out sc_lv 3 signal 1 } 
	{ m_axi_gmem1_AWBURST sc_out sc_lv 2 signal 1 } 
	{ m_axi_gmem1_AWLOCK sc_out sc_lv 2 signal 1 } 
	{ m_axi_gmem1_AWCACHE sc_out sc_lv 4 signal 1 } 
	{ m_axi_gmem1_AWPROT sc_out sc_lv 3 signal 1 } 
	{ m_axi_gmem1_AWQOS sc_out sc_lv 4 signal 1 } 
	{ m_axi_gmem1_AWREGION sc_out sc_lv 4 signal 1 } 
	{ m_axi_gmem1_AWUSER sc_out sc_lv 1 signal 1 } 
	{ m_axi_gmem1_WVALID sc_out sc_logic 1 signal 1 } 
	{ m_axi_gmem1_WREADY sc_in sc_logic 1 signal 1 } 
	{ m_axi_gmem1_WDATA sc_out sc_lv 512 signal 1 } 
	{ m_axi_gmem1_WSTRB sc_out sc_lv 64 signal 1 } 
	{ m_axi_gmem1_WLAST sc_out sc_logic 1 signal 1 } 
	{ m_axi_gmem1_WID sc_out sc_lv 1 signal 1 } 
	{ m_axi_gmem1_WUSER sc_out sc_lv 1 signal 1 } 
	{ m_axi_gmem1_ARVALID sc_out sc_logic 1 signal 1 } 
	{ m_axi_gmem1_ARREADY sc_in sc_logic 1 signal 1 } 
	{ m_axi_gmem1_ARADDR sc_out sc_lv 64 signal 1 } 
	{ m_axi_gmem1_ARID sc_out sc_lv 1 signal 1 } 
	{ m_axi_gmem1_ARLEN sc_out sc_lv 8 signal 1 } 
	{ m_axi_gmem1_ARSIZE sc_out sc_lv 3 signal 1 } 
	{ m_axi_gmem1_ARBURST sc_out sc_lv 2 signal 1 } 
	{ m_axi_gmem1_ARLOCK sc_out sc_lv 2 signal 1 } 
	{ m_axi_gmem1_ARCACHE sc_out sc_lv 4 signal 1 } 
	{ m_axi_gmem1_ARPROT sc_out sc_lv 3 signal 1 } 
	{ m_axi_gmem1_ARQOS sc_out sc_lv 4 signal 1 } 
	{ m_axi_gmem1_ARREGION sc_out sc_lv 4 signal 1 } 
	{ m_axi_gmem1_ARUSER sc_out sc_lv 1 signal 1 } 
	{ m_axi_gmem1_RVALID sc_in sc_logic 1 signal 1 } 
	{ m_axi_gmem1_RREADY sc_out sc_logic 1 signal 1 } 
	{ m_axi_gmem1_RDATA sc_in sc_lv 512 signal 1 } 
	{ m_axi_gmem1_RLAST sc_in sc_logic 1 signal 1 } 
	{ m_axi_gmem1_RID sc_in sc_lv 1 signal 1 } 
	{ m_axi_gmem1_RUSER sc_in sc_lv 1 signal 1 } 
	{ m_axi_gmem1_RRESP sc_in sc_lv 2 signal 1 } 
	{ m_axi_gmem1_BVALID sc_in sc_logic 1 signal 1 } 
	{ m_axi_gmem1_BREADY sc_out sc_logic 1 signal 1 } 
	{ m_axi_gmem1_BRESP sc_in sc_lv 2 signal 1 } 
	{ m_axi_gmem1_BID sc_in sc_lv 1 signal 1 } 
	{ m_axi_gmem1_BUSER sc_in sc_lv 1 signal 1 } 
	{ m_axi_gmem2_AWVALID sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem2_AWREADY sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem2_AWADDR sc_out sc_lv 64 signal 2 } 
	{ m_axi_gmem2_AWID sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem2_AWLEN sc_out sc_lv 8 signal 2 } 
	{ m_axi_gmem2_AWSIZE sc_out sc_lv 3 signal 2 } 
	{ m_axi_gmem2_AWBURST sc_out sc_lv 2 signal 2 } 
	{ m_axi_gmem2_AWLOCK sc_out sc_lv 2 signal 2 } 
	{ m_axi_gmem2_AWCACHE sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem2_AWPROT sc_out sc_lv 3 signal 2 } 
	{ m_axi_gmem2_AWQOS sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem2_AWREGION sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem2_AWUSER sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem2_WVALID sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem2_WREADY sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem2_WDATA sc_out sc_lv 512 signal 2 } 
	{ m_axi_gmem2_WSTRB sc_out sc_lv 64 signal 2 } 
	{ m_axi_gmem2_WLAST sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem2_WID sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem2_WUSER sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem2_ARVALID sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem2_ARREADY sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem2_ARADDR sc_out sc_lv 64 signal 2 } 
	{ m_axi_gmem2_ARID sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem2_ARLEN sc_out sc_lv 8 signal 2 } 
	{ m_axi_gmem2_ARSIZE sc_out sc_lv 3 signal 2 } 
	{ m_axi_gmem2_ARBURST sc_out sc_lv 2 signal 2 } 
	{ m_axi_gmem2_ARLOCK sc_out sc_lv 2 signal 2 } 
	{ m_axi_gmem2_ARCACHE sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem2_ARPROT sc_out sc_lv 3 signal 2 } 
	{ m_axi_gmem2_ARQOS sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem2_ARREGION sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem2_ARUSER sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem2_RVALID sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem2_RREADY sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem2_RDATA sc_in sc_lv 512 signal 2 } 
	{ m_axi_gmem2_RLAST sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem2_RID sc_in sc_lv 1 signal 2 } 
	{ m_axi_gmem2_RUSER sc_in sc_lv 1 signal 2 } 
	{ m_axi_gmem2_RRESP sc_in sc_lv 2 signal 2 } 
	{ m_axi_gmem2_BVALID sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem2_BREADY sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem2_BRESP sc_in sc_lv 2 signal 2 } 
	{ m_axi_gmem2_BID sc_in sc_lv 1 signal 2 } 
	{ m_axi_gmem2_BUSER sc_in sc_lv 1 signal 2 } 
	{ m_axi_gmem3_AWVALID sc_out sc_logic 1 signal 3 } 
	{ m_axi_gmem3_AWREADY sc_in sc_logic 1 signal 3 } 
	{ m_axi_gmem3_AWADDR sc_out sc_lv 64 signal 3 } 
	{ m_axi_gmem3_AWID sc_out sc_lv 1 signal 3 } 
	{ m_axi_gmem3_AWLEN sc_out sc_lv 8 signal 3 } 
	{ m_axi_gmem3_AWSIZE sc_out sc_lv 3 signal 3 } 
	{ m_axi_gmem3_AWBURST sc_out sc_lv 2 signal 3 } 
	{ m_axi_gmem3_AWLOCK sc_out sc_lv 2 signal 3 } 
	{ m_axi_gmem3_AWCACHE sc_out sc_lv 4 signal 3 } 
	{ m_axi_gmem3_AWPROT sc_out sc_lv 3 signal 3 } 
	{ m_axi_gmem3_AWQOS sc_out sc_lv 4 signal 3 } 
	{ m_axi_gmem3_AWREGION sc_out sc_lv 4 signal 3 } 
	{ m_axi_gmem3_AWUSER sc_out sc_lv 1 signal 3 } 
	{ m_axi_gmem3_WVALID sc_out sc_logic 1 signal 3 } 
	{ m_axi_gmem3_WREADY sc_in sc_logic 1 signal 3 } 
	{ m_axi_gmem3_WDATA sc_out sc_lv 512 signal 3 } 
	{ m_axi_gmem3_WSTRB sc_out sc_lv 64 signal 3 } 
	{ m_axi_gmem3_WLAST sc_out sc_logic 1 signal 3 } 
	{ m_axi_gmem3_WID sc_out sc_lv 1 signal 3 } 
	{ m_axi_gmem3_WUSER sc_out sc_lv 1 signal 3 } 
	{ m_axi_gmem3_ARVALID sc_out sc_logic 1 signal 3 } 
	{ m_axi_gmem3_ARREADY sc_in sc_logic 1 signal 3 } 
	{ m_axi_gmem3_ARADDR sc_out sc_lv 64 signal 3 } 
	{ m_axi_gmem3_ARID sc_out sc_lv 1 signal 3 } 
	{ m_axi_gmem3_ARLEN sc_out sc_lv 8 signal 3 } 
	{ m_axi_gmem3_ARSIZE sc_out sc_lv 3 signal 3 } 
	{ m_axi_gmem3_ARBURST sc_out sc_lv 2 signal 3 } 
	{ m_axi_gmem3_ARLOCK sc_out sc_lv 2 signal 3 } 
	{ m_axi_gmem3_ARCACHE sc_out sc_lv 4 signal 3 } 
	{ m_axi_gmem3_ARPROT sc_out sc_lv 3 signal 3 } 
	{ m_axi_gmem3_ARQOS sc_out sc_lv 4 signal 3 } 
	{ m_axi_gmem3_ARREGION sc_out sc_lv 4 signal 3 } 
	{ m_axi_gmem3_ARUSER sc_out sc_lv 1 signal 3 } 
	{ m_axi_gmem3_RVALID sc_in sc_logic 1 signal 3 } 
	{ m_axi_gmem3_RREADY sc_out sc_logic 1 signal 3 } 
	{ m_axi_gmem3_RDATA sc_in sc_lv 512 signal 3 } 
	{ m_axi_gmem3_RLAST sc_in sc_logic 1 signal 3 } 
	{ m_axi_gmem3_RID sc_in sc_lv 1 signal 3 } 
	{ m_axi_gmem3_RUSER sc_in sc_lv 1 signal 3 } 
	{ m_axi_gmem3_RRESP sc_in sc_lv 2 signal 3 } 
	{ m_axi_gmem3_BVALID sc_in sc_logic 1 signal 3 } 
	{ m_axi_gmem3_BREADY sc_out sc_logic 1 signal 3 } 
	{ m_axi_gmem3_BRESP sc_in sc_lv 2 signal 3 } 
	{ m_axi_gmem3_BID sc_in sc_lv 1 signal 3 } 
	{ m_axi_gmem3_BUSER sc_in sc_lv 1 signal 3 } 
	{ update_stream_TDATA sc_in sc_lv 96 signal 8 } 
	{ update_stream_TKEEP sc_in sc_lv 12 signal 9 } 
	{ update_stream_TSTRB sc_in sc_lv 12 signal 10 } 
	{ update_stream_TLAST sc_in sc_lv 1 signal 11 } 
	{ update_stream_TVALID sc_in sc_logic 1 invld 11 } 
	{ update_stream_TREADY sc_out sc_logic 1 inacc 11 } 
}
set NewPortList {[ 
	{ "name": "s_axi_control_AWADDR", "direction": "in", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "control", "role": "AWADDR" },"address":[{"name":"process_ddr","role":"start","value":"0","valid_bit":"0"},{"name":"process_ddr","role":"continue","value":"0","valid_bit":"4"},{"name":"process_ddr","role":"auto_start","value":"0","valid_bit":"7"},{"name":"pma_in0_ddr","role":"data","value":"16"},{"name":"pma_in1_ddr","role":"data","value":"28"},{"name":"pma_out0_ddr","role":"data","value":"40"},{"name":"pma_out1_ddr","role":"data","value":"52"}] },
	{ "name": "s_axi_control_AWVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "control", "role": "AWVALID" } },
	{ "name": "s_axi_control_AWREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "control", "role": "AWREADY" } },
	{ "name": "s_axi_control_WVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "control", "role": "WVALID" } },
	{ "name": "s_axi_control_WREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "control", "role": "WREADY" } },
	{ "name": "s_axi_control_WDATA", "direction": "in", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "control", "role": "WDATA" } },
	{ "name": "s_axi_control_WSTRB", "direction": "in", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "control", "role": "WSTRB" } },
	{ "name": "s_axi_control_ARADDR", "direction": "in", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "control", "role": "ARADDR" },"address":[{"name":"process_ddr","role":"start","value":"0","valid_bit":"0"},{"name":"process_ddr","role":"done","value":"0","valid_bit":"1"},{"name":"process_ddr","role":"idle","value":"0","valid_bit":"2"},{"name":"process_ddr","role":"ready","value":"0","valid_bit":"3"},{"name":"process_ddr","role":"auto_start","value":"0","valid_bit":"7"}] },
	{ "name": "s_axi_control_ARVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "control", "role": "ARVALID" } },
	{ "name": "s_axi_control_ARREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "control", "role": "ARREADY" } },
	{ "name": "s_axi_control_RVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "control", "role": "RVALID" } },
	{ "name": "s_axi_control_RREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "control", "role": "RREADY" } },
	{ "name": "s_axi_control_RDATA", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "control", "role": "RDATA" } },
	{ "name": "s_axi_control_RRESP", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "control", "role": "RRESP" } },
	{ "name": "s_axi_control_BVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "control", "role": "BVALID" } },
	{ "name": "s_axi_control_BREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "control", "role": "BREADY" } },
	{ "name": "s_axi_control_BRESP", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "control", "role": "BRESP" } },
	{ "name": "interrupt", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "control", "role": "interrupt" } }, 
 	{ "name": "ap_clk", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "clock", "bundle":{"name": "ap_clk", "role": "default" }} , 
 	{ "name": "ap_rst_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "reset", "bundle":{"name": "ap_rst_n", "role": "default" }} , 
 	{ "name": "m_axi_gmem0_AWVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "AWVALID" }} , 
 	{ "name": "m_axi_gmem0_AWREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "AWREADY" }} , 
 	{ "name": "m_axi_gmem0_AWADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem0", "role": "AWADDR" }} , 
 	{ "name": "m_axi_gmem0_AWID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "AWID" }} , 
 	{ "name": "m_axi_gmem0_AWLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":8, "type": "signal", "bundle":{"name": "gmem0", "role": "AWLEN" }} , 
 	{ "name": "m_axi_gmem0_AWSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem0", "role": "AWSIZE" }} , 
 	{ "name": "m_axi_gmem0_AWBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem0", "role": "AWBURST" }} , 
 	{ "name": "m_axi_gmem0_AWLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem0", "role": "AWLOCK" }} , 
 	{ "name": "m_axi_gmem0_AWCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem0", "role": "AWCACHE" }} , 
 	{ "name": "m_axi_gmem0_AWPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem0", "role": "AWPROT" }} , 
 	{ "name": "m_axi_gmem0_AWQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem0", "role": "AWQOS" }} , 
 	{ "name": "m_axi_gmem0_AWREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem0", "role": "AWREGION" }} , 
 	{ "name": "m_axi_gmem0_AWUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "AWUSER" }} , 
 	{ "name": "m_axi_gmem0_WVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "WVALID" }} , 
 	{ "name": "m_axi_gmem0_WREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "WREADY" }} , 
 	{ "name": "m_axi_gmem0_WDATA", "direction": "out", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem0", "role": "WDATA" }} , 
 	{ "name": "m_axi_gmem0_WSTRB", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem0", "role": "WSTRB" }} , 
 	{ "name": "m_axi_gmem0_WLAST", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "WLAST" }} , 
 	{ "name": "m_axi_gmem0_WID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "WID" }} , 
 	{ "name": "m_axi_gmem0_WUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "WUSER" }} , 
 	{ "name": "m_axi_gmem0_ARVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "ARVALID" }} , 
 	{ "name": "m_axi_gmem0_ARREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "ARREADY" }} , 
 	{ "name": "m_axi_gmem0_ARADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem0", "role": "ARADDR" }} , 
 	{ "name": "m_axi_gmem0_ARID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "ARID" }} , 
 	{ "name": "m_axi_gmem0_ARLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":8, "type": "signal", "bundle":{"name": "gmem0", "role": "ARLEN" }} , 
 	{ "name": "m_axi_gmem0_ARSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem0", "role": "ARSIZE" }} , 
 	{ "name": "m_axi_gmem0_ARBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem0", "role": "ARBURST" }} , 
 	{ "name": "m_axi_gmem0_ARLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem0", "role": "ARLOCK" }} , 
 	{ "name": "m_axi_gmem0_ARCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem0", "role": "ARCACHE" }} , 
 	{ "name": "m_axi_gmem0_ARPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem0", "role": "ARPROT" }} , 
 	{ "name": "m_axi_gmem0_ARQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem0", "role": "ARQOS" }} , 
 	{ "name": "m_axi_gmem0_ARREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem0", "role": "ARREGION" }} , 
 	{ "name": "m_axi_gmem0_ARUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "ARUSER" }} , 
 	{ "name": "m_axi_gmem0_RVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "RVALID" }} , 
 	{ "name": "m_axi_gmem0_RREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "RREADY" }} , 
 	{ "name": "m_axi_gmem0_RDATA", "direction": "in", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem0", "role": "RDATA" }} , 
 	{ "name": "m_axi_gmem0_RLAST", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "RLAST" }} , 
 	{ "name": "m_axi_gmem0_RID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "RID" }} , 
 	{ "name": "m_axi_gmem0_RUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "RUSER" }} , 
 	{ "name": "m_axi_gmem0_RRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem0", "role": "RRESP" }} , 
 	{ "name": "m_axi_gmem0_BVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "BVALID" }} , 
 	{ "name": "m_axi_gmem0_BREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "BREADY" }} , 
 	{ "name": "m_axi_gmem0_BRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem0", "role": "BRESP" }} , 
 	{ "name": "m_axi_gmem0_BID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "BID" }} , 
 	{ "name": "m_axi_gmem0_BUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "BUSER" }} , 
 	{ "name": "m_axi_gmem1_AWVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "AWVALID" }} , 
 	{ "name": "m_axi_gmem1_AWREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "AWREADY" }} , 
 	{ "name": "m_axi_gmem1_AWADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem1", "role": "AWADDR" }} , 
 	{ "name": "m_axi_gmem1_AWID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "AWID" }} , 
 	{ "name": "m_axi_gmem1_AWLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":8, "type": "signal", "bundle":{"name": "gmem1", "role": "AWLEN" }} , 
 	{ "name": "m_axi_gmem1_AWSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem1", "role": "AWSIZE" }} , 
 	{ "name": "m_axi_gmem1_AWBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem1", "role": "AWBURST" }} , 
 	{ "name": "m_axi_gmem1_AWLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem1", "role": "AWLOCK" }} , 
 	{ "name": "m_axi_gmem1_AWCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem1", "role": "AWCACHE" }} , 
 	{ "name": "m_axi_gmem1_AWPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem1", "role": "AWPROT" }} , 
 	{ "name": "m_axi_gmem1_AWQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem1", "role": "AWQOS" }} , 
 	{ "name": "m_axi_gmem1_AWREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem1", "role": "AWREGION" }} , 
 	{ "name": "m_axi_gmem1_AWUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "AWUSER" }} , 
 	{ "name": "m_axi_gmem1_WVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "WVALID" }} , 
 	{ "name": "m_axi_gmem1_WREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "WREADY" }} , 
 	{ "name": "m_axi_gmem1_WDATA", "direction": "out", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem1", "role": "WDATA" }} , 
 	{ "name": "m_axi_gmem1_WSTRB", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem1", "role": "WSTRB" }} , 
 	{ "name": "m_axi_gmem1_WLAST", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "WLAST" }} , 
 	{ "name": "m_axi_gmem1_WID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "WID" }} , 
 	{ "name": "m_axi_gmem1_WUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "WUSER" }} , 
 	{ "name": "m_axi_gmem1_ARVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "ARVALID" }} , 
 	{ "name": "m_axi_gmem1_ARREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "ARREADY" }} , 
 	{ "name": "m_axi_gmem1_ARADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem1", "role": "ARADDR" }} , 
 	{ "name": "m_axi_gmem1_ARID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "ARID" }} , 
 	{ "name": "m_axi_gmem1_ARLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":8, "type": "signal", "bundle":{"name": "gmem1", "role": "ARLEN" }} , 
 	{ "name": "m_axi_gmem1_ARSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem1", "role": "ARSIZE" }} , 
 	{ "name": "m_axi_gmem1_ARBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem1", "role": "ARBURST" }} , 
 	{ "name": "m_axi_gmem1_ARLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem1", "role": "ARLOCK" }} , 
 	{ "name": "m_axi_gmem1_ARCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem1", "role": "ARCACHE" }} , 
 	{ "name": "m_axi_gmem1_ARPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem1", "role": "ARPROT" }} , 
 	{ "name": "m_axi_gmem1_ARQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem1", "role": "ARQOS" }} , 
 	{ "name": "m_axi_gmem1_ARREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem1", "role": "ARREGION" }} , 
 	{ "name": "m_axi_gmem1_ARUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "ARUSER" }} , 
 	{ "name": "m_axi_gmem1_RVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "RVALID" }} , 
 	{ "name": "m_axi_gmem1_RREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "RREADY" }} , 
 	{ "name": "m_axi_gmem1_RDATA", "direction": "in", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem1", "role": "RDATA" }} , 
 	{ "name": "m_axi_gmem1_RLAST", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "RLAST" }} , 
 	{ "name": "m_axi_gmem1_RID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "RID" }} , 
 	{ "name": "m_axi_gmem1_RUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "RUSER" }} , 
 	{ "name": "m_axi_gmem1_RRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem1", "role": "RRESP" }} , 
 	{ "name": "m_axi_gmem1_BVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "BVALID" }} , 
 	{ "name": "m_axi_gmem1_BREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "BREADY" }} , 
 	{ "name": "m_axi_gmem1_BRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem1", "role": "BRESP" }} , 
 	{ "name": "m_axi_gmem1_BID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "BID" }} , 
 	{ "name": "m_axi_gmem1_BUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "BUSER" }} , 
 	{ "name": "m_axi_gmem2_AWVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "AWVALID" }} , 
 	{ "name": "m_axi_gmem2_AWREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "AWREADY" }} , 
 	{ "name": "m_axi_gmem2_AWADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem2", "role": "AWADDR" }} , 
 	{ "name": "m_axi_gmem2_AWID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "AWID" }} , 
 	{ "name": "m_axi_gmem2_AWLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":8, "type": "signal", "bundle":{"name": "gmem2", "role": "AWLEN" }} , 
 	{ "name": "m_axi_gmem2_AWSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem2", "role": "AWSIZE" }} , 
 	{ "name": "m_axi_gmem2_AWBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem2", "role": "AWBURST" }} , 
 	{ "name": "m_axi_gmem2_AWLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem2", "role": "AWLOCK" }} , 
 	{ "name": "m_axi_gmem2_AWCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem2", "role": "AWCACHE" }} , 
 	{ "name": "m_axi_gmem2_AWPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem2", "role": "AWPROT" }} , 
 	{ "name": "m_axi_gmem2_AWQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem2", "role": "AWQOS" }} , 
 	{ "name": "m_axi_gmem2_AWREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem2", "role": "AWREGION" }} , 
 	{ "name": "m_axi_gmem2_AWUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "AWUSER" }} , 
 	{ "name": "m_axi_gmem2_WVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "WVALID" }} , 
 	{ "name": "m_axi_gmem2_WREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "WREADY" }} , 
 	{ "name": "m_axi_gmem2_WDATA", "direction": "out", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem2", "role": "WDATA" }} , 
 	{ "name": "m_axi_gmem2_WSTRB", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem2", "role": "WSTRB" }} , 
 	{ "name": "m_axi_gmem2_WLAST", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "WLAST" }} , 
 	{ "name": "m_axi_gmem2_WID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "WID" }} , 
 	{ "name": "m_axi_gmem2_WUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "WUSER" }} , 
 	{ "name": "m_axi_gmem2_ARVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "ARVALID" }} , 
 	{ "name": "m_axi_gmem2_ARREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "ARREADY" }} , 
 	{ "name": "m_axi_gmem2_ARADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem2", "role": "ARADDR" }} , 
 	{ "name": "m_axi_gmem2_ARID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "ARID" }} , 
 	{ "name": "m_axi_gmem2_ARLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":8, "type": "signal", "bundle":{"name": "gmem2", "role": "ARLEN" }} , 
 	{ "name": "m_axi_gmem2_ARSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem2", "role": "ARSIZE" }} , 
 	{ "name": "m_axi_gmem2_ARBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem2", "role": "ARBURST" }} , 
 	{ "name": "m_axi_gmem2_ARLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem2", "role": "ARLOCK" }} , 
 	{ "name": "m_axi_gmem2_ARCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem2", "role": "ARCACHE" }} , 
 	{ "name": "m_axi_gmem2_ARPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem2", "role": "ARPROT" }} , 
 	{ "name": "m_axi_gmem2_ARQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem2", "role": "ARQOS" }} , 
 	{ "name": "m_axi_gmem2_ARREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem2", "role": "ARREGION" }} , 
 	{ "name": "m_axi_gmem2_ARUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "ARUSER" }} , 
 	{ "name": "m_axi_gmem2_RVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "RVALID" }} , 
 	{ "name": "m_axi_gmem2_RREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "RREADY" }} , 
 	{ "name": "m_axi_gmem2_RDATA", "direction": "in", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem2", "role": "RDATA" }} , 
 	{ "name": "m_axi_gmem2_RLAST", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "RLAST" }} , 
 	{ "name": "m_axi_gmem2_RID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "RID" }} , 
 	{ "name": "m_axi_gmem2_RUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "RUSER" }} , 
 	{ "name": "m_axi_gmem2_RRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem2", "role": "RRESP" }} , 
 	{ "name": "m_axi_gmem2_BVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "BVALID" }} , 
 	{ "name": "m_axi_gmem2_BREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "BREADY" }} , 
 	{ "name": "m_axi_gmem2_BRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem2", "role": "BRESP" }} , 
 	{ "name": "m_axi_gmem2_BID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "BID" }} , 
 	{ "name": "m_axi_gmem2_BUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "BUSER" }} , 
 	{ "name": "m_axi_gmem3_AWVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "AWVALID" }} , 
 	{ "name": "m_axi_gmem3_AWREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "AWREADY" }} , 
 	{ "name": "m_axi_gmem3_AWADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem3", "role": "AWADDR" }} , 
 	{ "name": "m_axi_gmem3_AWID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "AWID" }} , 
 	{ "name": "m_axi_gmem3_AWLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":8, "type": "signal", "bundle":{"name": "gmem3", "role": "AWLEN" }} , 
 	{ "name": "m_axi_gmem3_AWSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem3", "role": "AWSIZE" }} , 
 	{ "name": "m_axi_gmem3_AWBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem3", "role": "AWBURST" }} , 
 	{ "name": "m_axi_gmem3_AWLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem3", "role": "AWLOCK" }} , 
 	{ "name": "m_axi_gmem3_AWCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem3", "role": "AWCACHE" }} , 
 	{ "name": "m_axi_gmem3_AWPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem3", "role": "AWPROT" }} , 
 	{ "name": "m_axi_gmem3_AWQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem3", "role": "AWQOS" }} , 
 	{ "name": "m_axi_gmem3_AWREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem3", "role": "AWREGION" }} , 
 	{ "name": "m_axi_gmem3_AWUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "AWUSER" }} , 
 	{ "name": "m_axi_gmem3_WVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "WVALID" }} , 
 	{ "name": "m_axi_gmem3_WREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "WREADY" }} , 
 	{ "name": "m_axi_gmem3_WDATA", "direction": "out", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem3", "role": "WDATA" }} , 
 	{ "name": "m_axi_gmem3_WSTRB", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem3", "role": "WSTRB" }} , 
 	{ "name": "m_axi_gmem3_WLAST", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "WLAST" }} , 
 	{ "name": "m_axi_gmem3_WID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "WID" }} , 
 	{ "name": "m_axi_gmem3_WUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "WUSER" }} , 
 	{ "name": "m_axi_gmem3_ARVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "ARVALID" }} , 
 	{ "name": "m_axi_gmem3_ARREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "ARREADY" }} , 
 	{ "name": "m_axi_gmem3_ARADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem3", "role": "ARADDR" }} , 
 	{ "name": "m_axi_gmem3_ARID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "ARID" }} , 
 	{ "name": "m_axi_gmem3_ARLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":8, "type": "signal", "bundle":{"name": "gmem3", "role": "ARLEN" }} , 
 	{ "name": "m_axi_gmem3_ARSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem3", "role": "ARSIZE" }} , 
 	{ "name": "m_axi_gmem3_ARBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem3", "role": "ARBURST" }} , 
 	{ "name": "m_axi_gmem3_ARLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem3", "role": "ARLOCK" }} , 
 	{ "name": "m_axi_gmem3_ARCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem3", "role": "ARCACHE" }} , 
 	{ "name": "m_axi_gmem3_ARPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem3", "role": "ARPROT" }} , 
 	{ "name": "m_axi_gmem3_ARQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem3", "role": "ARQOS" }} , 
 	{ "name": "m_axi_gmem3_ARREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem3", "role": "ARREGION" }} , 
 	{ "name": "m_axi_gmem3_ARUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "ARUSER" }} , 
 	{ "name": "m_axi_gmem3_RVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "RVALID" }} , 
 	{ "name": "m_axi_gmem3_RREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "RREADY" }} , 
 	{ "name": "m_axi_gmem3_RDATA", "direction": "in", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem3", "role": "RDATA" }} , 
 	{ "name": "m_axi_gmem3_RLAST", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "RLAST" }} , 
 	{ "name": "m_axi_gmem3_RID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "RID" }} , 
 	{ "name": "m_axi_gmem3_RUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "RUSER" }} , 
 	{ "name": "m_axi_gmem3_RRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem3", "role": "RRESP" }} , 
 	{ "name": "m_axi_gmem3_BVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "BVALID" }} , 
 	{ "name": "m_axi_gmem3_BREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "BREADY" }} , 
 	{ "name": "m_axi_gmem3_BRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem3", "role": "BRESP" }} , 
 	{ "name": "m_axi_gmem3_BID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "BID" }} , 
 	{ "name": "m_axi_gmem3_BUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "BUSER" }} , 
 	{ "name": "update_stream_TDATA", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_V_data_V", "role": "default" }} , 
 	{ "name": "update_stream_TKEEP", "direction": "in", "datatype": "sc_lv", "bitwidth":12, "type": "signal", "bundle":{"name": "update_stream_V_keep_V", "role": "default" }} , 
 	{ "name": "update_stream_TSTRB", "direction": "in", "datatype": "sc_lv", "bitwidth":12, "type": "signal", "bundle":{"name": "update_stream_V_strb_V", "role": "default" }} , 
 	{ "name": "update_stream_TLAST", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_V_last_V", "role": "default" }} , 
 	{ "name": "update_stream_TVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "invld", "bundle":{"name": "update_stream_V_last_V", "role": "default" }} , 
 	{ "name": "update_stream_TREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "inacc", "bundle":{"name": "update_stream_V_last_V", "role": "default" }}  ]}

set RtlHierarchyInfo {[
	{"ID" : "0", "Level" : "0", "Path" : "`AUTOTB_DUT_INST", "Parent" : "", "Child" : ["1", "2", "3", "4", "5", "6", "13", "17", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52"],
		"CDFG" : "process_ddr",
		"Protocol" : "ap_ctrl_chain",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "1", "ap_idle" : "1", "real_start" : "0",
		"Pipeline" : "Dataflow", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "1",
		"II" : "0",
		"VariableLatency" : "1", "ExactLatency" : "-1", "EstimateLatencyMin" : "-1", "EstimateLatencyMax" : "-1",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "1",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"IsBlackBox" : "0",
		"InputProcess" : [
			{"ID" : "6", "Name" : "dispatch_update_U0"},
			{"ID" : "13", "Name" : "process_U0"},
			{"ID" : "17", "Name" : "process_1_U0"}],
		"OutputProcess" : [
			{"ID" : "13", "Name" : "process_U0"},
			{"ID" : "17", "Name" : "process_1_U0"}],
		"Port" : [
			{"Name" : "gmem0", "Type" : "MAXI", "Direction" : "I",
				"SubConnect" : [
					{"ID" : "13", "SubInstance" : "process_U0", "Port" : "gmem0"}]},
			{"Name" : "gmem1", "Type" : "MAXI", "Direction" : "I",
				"SubConnect" : [
					{"ID" : "17", "SubInstance" : "process_1_U0", "Port" : "gmem1"}]},
			{"Name" : "gmem2", "Type" : "MAXI", "Direction" : "O",
				"SubConnect" : [
					{"ID" : "13", "SubInstance" : "process_U0", "Port" : "gmem2"}]},
			{"Name" : "gmem3", "Type" : "MAXI", "Direction" : "O",
				"SubConnect" : [
					{"ID" : "17", "SubInstance" : "process_1_U0", "Port" : "gmem3"}]},
			{"Name" : "pma_in0_ddr", "Type" : "None", "Direction" : "I"},
			{"Name" : "pma_in1_ddr", "Type" : "None", "Direction" : "I"},
			{"Name" : "pma_out0_ddr", "Type" : "None", "Direction" : "I"},
			{"Name" : "pma_out1_ddr", "Type" : "None", "Direction" : "I"},
			{"Name" : "update_stream_V_data_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream",
				"SubConnect" : [
					{"ID" : "6", "SubInstance" : "dispatch_update_U0", "Port" : "update_stream_V_data_V"}]},
			{"Name" : "update_stream_V_keep_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream",
				"SubConnect" : [
					{"ID" : "6", "SubInstance" : "dispatch_update_U0", "Port" : "update_stream_V_keep_V"}]},
			{"Name" : "update_stream_V_strb_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream",
				"SubConnect" : [
					{"ID" : "6", "SubInstance" : "dispatch_update_U0", "Port" : "update_stream_V_strb_V"}]},
			{"Name" : "update_stream_V_last_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream",
				"SubConnect" : [
					{"ID" : "6", "SubInstance" : "dispatch_update_U0", "Port" : "update_stream_V_last_V"}]}]},
	{"ID" : "1", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.control_s_axi_U", "Parent" : "0"},
	{"ID" : "2", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.gmem0_m_axi_U", "Parent" : "0"},
	{"ID" : "3", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.gmem1_m_axi_U", "Parent" : "0"},
	{"ID" : "4", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.gmem2_m_axi_U", "Parent" : "0"},
	{"ID" : "5", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.gmem3_m_axi_U", "Parent" : "0"},
	{"ID" : "6", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.dispatch_update_U0", "Parent" : "0", "Child" : ["7", "9", "10", "11", "12"],
		"CDFG" : "dispatch_update",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "1", "ap_idle" : "1", "real_start" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "0",
		"VariableLatency" : "1", "ExactLatency" : "-1", "EstimateLatencyMin" : "-1", "EstimateLatencyMax" : "-1",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "1",
		"HasNonBlockingOperation" : "0",
		"IsBlackBox" : "0",
		"Port" : [
			{"Name" : "update_stream_V_data_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream",
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_V_data_V", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_V_keep_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream",
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_V_keep_V", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_V_strb_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream",
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_V_strb_V", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_V_last_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream",
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_V_last_V", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_0", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "21", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_0_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_0", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_1", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "22", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_1_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_1", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_2", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "23", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_2_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_2", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_3", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "24", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_3_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_3", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_4", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "25", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_4_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_4", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_5", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "26", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_5_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_5", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_6", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "27", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_6_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_6", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_7", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "28", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_7_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_7", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_8", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "29", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_8_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_8", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_9", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "30", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_9_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_9", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_10", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "31", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_10_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_10", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_11", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "32", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_11_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_11", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_12", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "33", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_12_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_12", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_13", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "34", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_13_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_13", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_14", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "35", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_14_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_14", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_15", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["13"], "DependentChan" : "36", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_15_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_0_15", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_0", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "37", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_0_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_0", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_1", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "38", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_1_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_1", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_2", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "39", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_2_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_2", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_3", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "40", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_3_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_3", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_4", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "41", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_4_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_4", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_5", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "42", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_5_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_5", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_6", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "43", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_6_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_6", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_7", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "44", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_7_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_7", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_8", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "45", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_8_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_8", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_9", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "46", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_9_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_9", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_10", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "47", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_10_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_10", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_11", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "48", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_11_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_11", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_12", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "49", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_12_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_12", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_13", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "50", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_13_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_13", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_14", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "51", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_14_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_14", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_15", "Type" : "Fifo", "Direction" : "O", "DependentProc" : ["17"], "DependentChan" : "52", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_15_blk_n", "Type" : "RtlSignal"}],
				"SubConnect" : [
					{"ID" : "7", "SubInstance" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Port" : "update_stream_ddr_1_15", "Inst_start_state" : "2", "Inst_end_state" : "3"}]}]},
	{"ID" : "7", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.dispatch_update_U0.grp_dispatch_update_Pipeline_dispatch_loop_fu_358", "Parent" : "6", "Child" : ["8"],
		"CDFG" : "dispatch_update_Pipeline_dispatch_loop",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "0", "ap_idle" : "1", "real_start" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "0",
		"VariableLatency" : "1", "ExactLatency" : "-1", "EstimateLatencyMin" : "-1", "EstimateLatencyMax" : "-1",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"IsBlackBox" : "0",
		"Port" : [
			{"Name" : "update_stream_V_data_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream",
				"BlockSignal" : [
					{"Name" : "update_stream_TDATA_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_V_keep_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream"},
			{"Name" : "update_stream_V_strb_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream"},
			{"Name" : "update_stream_V_last_V", "Type" : "Axis", "Direction" : "I", "BaseName" : "update_stream"},
			{"Name" : "update_stream_ddr_0_0", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_0_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_1", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_1_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_2", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_2_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_3", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_3_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_4", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_4_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_5", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_5_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_6", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_6_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_7", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_7_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_8", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_8_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_9", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_9_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_10", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_10_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_11", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_11_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_12", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_12_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_13", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_13_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_14", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_14_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_0_15", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_0_15_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_0", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_0_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_1", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_1_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_2", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_2_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_3", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_3_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_4", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_4_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_5", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_5_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_6", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_6_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_7", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_7_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_8", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_8_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_9", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_9_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_10", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_10_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_11", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_11_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_12", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_12_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_13", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_13_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_14", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_14_blk_n", "Type" : "RtlSignal"}]},
			{"Name" : "update_stream_ddr_1_15", "Type" : "Fifo", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "update_stream_ddr_1_15_blk_n", "Type" : "RtlSignal"}]}],
		"Loop" : [
			{"Name" : "dispatch_loop", "PipelineType" : "UPC",
				"LoopDec" : {"FSMBitwidth" : "1", "FirstState" : "ap_ST_fsm_pp0_stage0", "FirstStateIter" : "ap_enable_reg_pp0_iter0", "FirstStateBlock" : "ap_block_pp0_stage0_subdone", "LastState" : "ap_ST_fsm_pp0_stage0", "LastStateIter" : "ap_enable_reg_pp0_iter1", "LastStateBlock" : "ap_block_pp0_stage0_subdone", "QuitState" : "ap_ST_fsm_pp0_stage0", "QuitStateIter" : "ap_enable_reg_pp0_iter1", "QuitStateBlock" : "ap_block_pp0_stage0_subdone", "OneDepthLoop" : "0", "has_ap_ctrl" : "1", "has_continue" : "0"}}]},
	{"ID" : "8", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.dispatch_update_U0.grp_dispatch_update_Pipeline_dispatch_loop_fu_358.flow_control_loop_pipe_sequential_init_U", "Parent" : "7"},
	{"ID" : "9", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.dispatch_update_U0.regslice_both_update_stream_V_data_V_U", "Parent" : "6"},
	{"ID" : "10", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.dispatch_update_U0.regslice_both_update_stream_V_keep_V_U", "Parent" : "6"},
	{"ID" : "11", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.dispatch_update_U0.regslice_both_update_stream_V_strb_V_U", "Parent" : "6"},
	{"ID" : "12", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.dispatch_update_U0.regslice_both_update_stream_V_last_V_U", "Parent" : "6"},
	{"ID" : "13", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.process_U0", "Parent" : "0", "Child" : ["14"],
		"CDFG" : "process_r",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "1", "ap_idle" : "1", "real_start" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "0",
		"VariableLatency" : "1", "ExactLatency" : "-1", "EstimateLatencyMin" : "-1", "EstimateLatencyMax" : "-1",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "1",
		"HasNonBlockingOperation" : "0",
		"IsBlackBox" : "0",
		"Port" : [
			{"Name" : "gmem0", "Type" : "MAXI", "Direction" : "I",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "gmem0", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "pma_in", "Type" : "None", "Direction" : "I"},
			{"Name" : "gmem2", "Type" : "MAXI", "Direction" : "O",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "gmem2", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "pma_out", "Type" : "None", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_0", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "21", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_0", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_1", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "22", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_1", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_2", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "23", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_2", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_3", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "24", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_3", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_4", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "25", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_4", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_5", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "26", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_5", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_6", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "27", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_6", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_7", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "28", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_7", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_8", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "29", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_8", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_9", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "30", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_9", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_10", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "31", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_10", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_11", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "32", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_11", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_12", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "33", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_12", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_13", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "34", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_13", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_14", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "35", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_14", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_15", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "36", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "14", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_15", "Inst_start_state" : "2", "Inst_end_state" : "3"}]}],
		"Loop" : [
			{"Name" : "process_ddr_loop", "PipelineType" : "no",
				"LoopDec" : {"FSMBitwidth" : "4", "FirstState" : "ap_ST_fsm_state2", "LastState" : ["ap_ST_fsm_state4"], "QuitState" : ["ap_ST_fsm_state2"], "PreState" : ["ap_ST_fsm_state1"], "PostState" : ["ap_ST_fsm_state1"], "OneDepthLoop" : "0", "OneStateBlock": ""}}]},
	{"ID" : "14", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.process_U0.grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Parent" : "13", "Child" : ["15", "16"],
		"CDFG" : "process_Pipeline_process_ddr_sub_loop",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "0", "ap_idle" : "1", "real_start" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "0",
		"VariableLatency" : "1", "ExactLatency" : "-1", "EstimateLatencyMin" : "162", "EstimateLatencyMax" : "162",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "1",
		"IsBlackBox" : "0",
		"Port" : [
			{"Name" : "finish_r", "Type" : "None", "Direction" : "I"},
			{"Name" : "info", "Type" : "None", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_0", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_1", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_2", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_3", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_4", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_5", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_6", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_7", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_8", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_9", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_10", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_11", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_12", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_13", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_14", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_15", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "pma_in", "Type" : "None", "Direction" : "I"},
			{"Name" : "gmem0", "Type" : "MAXI", "Direction" : "I",
				"BlockSignal" : [
					{"Name" : "gmem0_blk_n_AR", "Type" : "RtlSignal"},
					{"Name" : "gmem0_blk_n_R", "Type" : "RtlSignal"}]},
			{"Name" : "pma_out", "Type" : "None", "Direction" : "I"},
			{"Name" : "gmem2", "Type" : "MAXI", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "gmem2_blk_n_AW", "Type" : "RtlSignal"},
					{"Name" : "gmem2_blk_n_W", "Type" : "RtlSignal"},
					{"Name" : "gmem2_blk_n_B", "Type" : "RtlSignal"}]},
			{"Name" : "finish_4_out", "Type" : "Vld", "Direction" : "O"},
			{"Name" : "info_4_out", "Type" : "Vld", "Direction" : "O"}],
		"Loop" : [
			{"Name" : "process_ddr_sub_loop", "PipelineType" : "UPC",
				"LoopDec" : {"FSMBitwidth" : "1", "FirstState" : "ap_ST_fsm_pp0_stage0", "FirstStateIter" : "ap_enable_reg_pp0_iter0", "FirstStateBlock" : "ap_block_pp0_stage0_subdone", "LastState" : "ap_ST_fsm_pp0_stage0", "LastStateIter" : "ap_enable_reg_pp0_iter145", "LastStateBlock" : "ap_block_pp0_stage0_subdone", "QuitState" : "ap_ST_fsm_pp0_stage0", "QuitStateIter" : "ap_enable_reg_pp0_iter145", "QuitStateBlock" : "ap_block_pp0_stage0_subdone", "OneDepthLoop" : "0", "has_ap_ctrl" : "1", "has_continue" : "0"}}]},
	{"ID" : "15", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.process_U0.grp_process_Pipeline_process_ddr_sub_loop_fu_108.sparsemux_7_2_512_1_1_U77", "Parent" : "14"},
	{"ID" : "16", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.process_U0.grp_process_Pipeline_process_ddr_sub_loop_fu_108.flow_control_loop_pipe_sequential_init_U", "Parent" : "14"},
	{"ID" : "17", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.process_1_U0", "Parent" : "0", "Child" : ["18"],
		"CDFG" : "process_1",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "1", "ap_idle" : "1", "real_start" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "0",
		"VariableLatency" : "1", "ExactLatency" : "-1", "EstimateLatencyMin" : "-1", "EstimateLatencyMax" : "-1",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "1",
		"HasNonBlockingOperation" : "0",
		"IsBlackBox" : "0",
		"Port" : [
			{"Name" : "gmem1", "Type" : "MAXI", "Direction" : "I",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "gmem1", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "pma_in", "Type" : "None", "Direction" : "I"},
			{"Name" : "gmem3", "Type" : "MAXI", "Direction" : "O",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "gmem3", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "pma_out", "Type" : "None", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_0", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "37", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_0", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_1", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "38", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_1", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_2", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "39", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_2", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_3", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "40", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_3", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_4", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "41", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_4", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_5", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "42", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_5", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_6", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "43", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_6", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_7", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "44", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_7", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_8", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "45", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_8", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_9", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "46", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_9", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_10", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "47", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_10", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_11", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "48", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_11", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_12", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "49", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_12", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_13", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "50", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_13", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_14", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "51", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_14", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_15", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["6"], "DependentChan" : "52", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "18", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_15", "Inst_start_state" : "2", "Inst_end_state" : "3"}]}],
		"Loop" : [
			{"Name" : "process_ddr_loop", "PipelineType" : "no",
				"LoopDec" : {"FSMBitwidth" : "4", "FirstState" : "ap_ST_fsm_state2", "LastState" : ["ap_ST_fsm_state4"], "QuitState" : ["ap_ST_fsm_state2"], "PreState" : ["ap_ST_fsm_state1"], "PostState" : ["ap_ST_fsm_state1"], "OneDepthLoop" : "0", "OneStateBlock": ""}}]},
	{"ID" : "18", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.process_1_U0.grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Parent" : "17", "Child" : ["19", "20"],
		"CDFG" : "process_1_Pipeline_process_ddr_sub_loop",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "0", "ap_idle" : "1", "real_start" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "0",
		"VariableLatency" : "1", "ExactLatency" : "-1", "EstimateLatencyMin" : "162", "EstimateLatencyMax" : "162",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "1",
		"IsBlackBox" : "0",
		"Port" : [
			{"Name" : "finish_r", "Type" : "None", "Direction" : "I"},
			{"Name" : "info", "Type" : "None", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_0", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_1", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_2", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_3", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_4", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_5", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_6", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_7", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_8", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_9", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_10", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_11", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_12", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_13", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_14", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_15", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "pma_in", "Type" : "None", "Direction" : "I"},
			{"Name" : "gmem1", "Type" : "MAXI", "Direction" : "I",
				"BlockSignal" : [
					{"Name" : "gmem1_blk_n_AR", "Type" : "RtlSignal"},
					{"Name" : "gmem1_blk_n_R", "Type" : "RtlSignal"}]},
			{"Name" : "pma_out", "Type" : "None", "Direction" : "I"},
			{"Name" : "gmem3", "Type" : "MAXI", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "gmem3_blk_n_AW", "Type" : "RtlSignal"},
					{"Name" : "gmem3_blk_n_W", "Type" : "RtlSignal"},
					{"Name" : "gmem3_blk_n_B", "Type" : "RtlSignal"}]},
			{"Name" : "finish_1_out", "Type" : "Vld", "Direction" : "O"},
			{"Name" : "info_1_out", "Type" : "Vld", "Direction" : "O"}],
		"Loop" : [
			{"Name" : "process_ddr_sub_loop", "PipelineType" : "UPC",
				"LoopDec" : {"FSMBitwidth" : "1", "FirstState" : "ap_ST_fsm_pp0_stage0", "FirstStateIter" : "ap_enable_reg_pp0_iter0", "FirstStateBlock" : "ap_block_pp0_stage0_subdone", "LastState" : "ap_ST_fsm_pp0_stage0", "LastStateIter" : "ap_enable_reg_pp0_iter145", "LastStateBlock" : "ap_block_pp0_stage0_subdone", "QuitState" : "ap_ST_fsm_pp0_stage0", "QuitStateIter" : "ap_enable_reg_pp0_iter145", "QuitStateBlock" : "ap_block_pp0_stage0_subdone", "OneDepthLoop" : "0", "has_ap_ctrl" : "1", "has_continue" : "0"}}]},
	{"ID" : "19", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.process_1_U0.grp_process_1_Pipeline_process_ddr_sub_loop_fu_108.sparsemux_7_2_512_1_1_U123", "Parent" : "18"},
	{"ID" : "20", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.process_1_U0.grp_process_1_Pipeline_process_ddr_sub_loop_fu_108.flow_control_loop_pipe_sequential_init_U", "Parent" : "18"},
	{"ID" : "21", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_U", "Parent" : "0"},
	{"ID" : "22", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_1_U", "Parent" : "0"},
	{"ID" : "23", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_2_U", "Parent" : "0"},
	{"ID" : "24", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_3_U", "Parent" : "0"},
	{"ID" : "25", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_4_U", "Parent" : "0"},
	{"ID" : "26", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_5_U", "Parent" : "0"},
	{"ID" : "27", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_6_U", "Parent" : "0"},
	{"ID" : "28", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_7_U", "Parent" : "0"},
	{"ID" : "29", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_8_U", "Parent" : "0"},
	{"ID" : "30", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_9_U", "Parent" : "0"},
	{"ID" : "31", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_10_U", "Parent" : "0"},
	{"ID" : "32", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_11_U", "Parent" : "0"},
	{"ID" : "33", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_12_U", "Parent" : "0"},
	{"ID" : "34", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_13_U", "Parent" : "0"},
	{"ID" : "35", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_14_U", "Parent" : "0"},
	{"ID" : "36", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_0_15_U", "Parent" : "0"},
	{"ID" : "37", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_U", "Parent" : "0"},
	{"ID" : "38", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_1_U", "Parent" : "0"},
	{"ID" : "39", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_2_U", "Parent" : "0"},
	{"ID" : "40", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_3_U", "Parent" : "0"},
	{"ID" : "41", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_4_U", "Parent" : "0"},
	{"ID" : "42", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_5_U", "Parent" : "0"},
	{"ID" : "43", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_6_U", "Parent" : "0"},
	{"ID" : "44", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_7_U", "Parent" : "0"},
	{"ID" : "45", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_8_U", "Parent" : "0"},
	{"ID" : "46", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_9_U", "Parent" : "0"},
	{"ID" : "47", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_10_U", "Parent" : "0"},
	{"ID" : "48", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_11_U", "Parent" : "0"},
	{"ID" : "49", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_12_U", "Parent" : "0"},
	{"ID" : "50", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_13_U", "Parent" : "0"},
	{"ID" : "51", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_14_U", "Parent" : "0"},
	{"ID" : "52", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.update_stream_ddr_1_15_U", "Parent" : "0"}]}


set ArgLastReadFirstWriteLatency {
	process_ddr {
		gmem0 {Type I LastRead 73 FirstWrite -1}
		gmem1 {Type I LastRead 73 FirstWrite -1}
		gmem2 {Type O LastRead 78 FirstWrite 77}
		gmem3 {Type O LastRead 78 FirstWrite 77}
		pma_in0_ddr {Type I LastRead 3 FirstWrite -1}
		pma_in1_ddr {Type I LastRead 3 FirstWrite -1}
		pma_out0_ddr {Type I LastRead 3 FirstWrite -1}
		pma_out1_ddr {Type I LastRead 3 FirstWrite -1}
		update_stream_V_data_V {Type I LastRead 0 FirstWrite -1}
		update_stream_V_keep_V {Type I LastRead 0 FirstWrite -1}
		update_stream_V_strb_V {Type I LastRead 0 FirstWrite -1}
		update_stream_V_last_V {Type I LastRead 0 FirstWrite -1}}
	dispatch_update {
		update_stream_V_data_V {Type I LastRead 0 FirstWrite -1}
		update_stream_V_keep_V {Type I LastRead 0 FirstWrite -1}
		update_stream_V_strb_V {Type I LastRead 0 FirstWrite -1}
		update_stream_V_last_V {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_0 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_1 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_2 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_3 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_4 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_5 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_6 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_7 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_8 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_9 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_10 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_11 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_12 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_13 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_14 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_15 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_0 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_1 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_2 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_3 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_4 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_5 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_6 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_7 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_8 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_9 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_10 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_11 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_12 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_13 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_14 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_15 {Type O LastRead -1 FirstWrite 1}}
	dispatch_update_Pipeline_dispatch_loop {
		update_stream_V_data_V {Type I LastRead 0 FirstWrite -1}
		update_stream_V_keep_V {Type I LastRead 0 FirstWrite -1}
		update_stream_V_strb_V {Type I LastRead 0 FirstWrite -1}
		update_stream_V_last_V {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_0 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_1 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_2 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_3 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_4 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_5 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_6 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_7 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_8 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_9 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_10 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_11 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_12 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_13 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_14 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_0_15 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_0 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_1 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_2 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_3 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_4 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_5 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_6 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_7 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_8 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_9 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_10 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_11 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_12 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_13 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_14 {Type O LastRead -1 FirstWrite 1}
		update_stream_ddr_1_15 {Type O LastRead -1 FirstWrite 1}}
	process_r {
		gmem0 {Type I LastRead 73 FirstWrite -1}
		pma_in {Type I LastRead 0 FirstWrite -1}
		gmem2 {Type O LastRead 78 FirstWrite 77}
		pma_out {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_0 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_1 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_2 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_3 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_4 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_5 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_6 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_7 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_8 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_9 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_10 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_11 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_12 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_13 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_14 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_15 {Type I LastRead 0 FirstWrite -1}}
	process_Pipeline_process_ddr_sub_loop {
		finish_r {Type I LastRead 0 FirstWrite -1}
		info {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_0 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_1 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_2 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_3 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_4 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_5 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_6 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_7 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_8 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_9 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_10 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_11 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_12 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_13 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_14 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_15 {Type I LastRead 0 FirstWrite -1}
		pma_in {Type I LastRead 0 FirstWrite -1}
		gmem0 {Type I LastRead 73 FirstWrite -1}
		pma_out {Type I LastRead 0 FirstWrite -1}
		gmem2 {Type O LastRead 78 FirstWrite 77}
		finish_4_out {Type O LastRead -1 FirstWrite 144}
		info_4_out {Type O LastRead -1 FirstWrite 144}}
	process_1 {
		gmem1 {Type I LastRead 73 FirstWrite -1}
		pma_in {Type I LastRead 0 FirstWrite -1}
		gmem3 {Type O LastRead 78 FirstWrite 77}
		pma_out {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_0 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_1 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_2 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_3 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_4 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_5 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_6 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_7 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_8 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_9 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_10 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_11 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_12 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_13 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_14 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_15 {Type I LastRead 0 FirstWrite -1}}
	process_1_Pipeline_process_ddr_sub_loop {
		finish_r {Type I LastRead 0 FirstWrite -1}
		info {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_0 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_1 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_2 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_3 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_4 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_5 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_6 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_7 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_8 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_9 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_10 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_11 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_12 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_13 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_14 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_15 {Type I LastRead 0 FirstWrite -1}
		pma_in {Type I LastRead 0 FirstWrite -1}
		gmem1 {Type I LastRead 73 FirstWrite -1}
		pma_out {Type I LastRead 0 FirstWrite -1}
		gmem3 {Type O LastRead 78 FirstWrite 77}
		finish_1_out {Type O LastRead -1 FirstWrite 144}
		info_1_out {Type O LastRead -1 FirstWrite 144}}}

set hasDtUnsupportedChannel 0

set PerformanceInfo {[
	{"Name" : "Latency", "Min" : "-1", "Max" : "-1"}
	, {"Name" : "Interval", "Min" : "-1", "Max" : "-1"}
]}

set PipelineEnableSignalInfo {[
]}

set Spec2ImplPortList { 
	gmem0 { m_axi {  { m_axi_gmem0_AWVALID VALID 1 1 }  { m_axi_gmem0_AWREADY READY 0 1 }  { m_axi_gmem0_AWADDR ADDR 1 64 }  { m_axi_gmem0_AWID ID 1 1 }  { m_axi_gmem0_AWLEN SIZE 1 8 }  { m_axi_gmem0_AWSIZE BURST 1 3 }  { m_axi_gmem0_AWBURST LOCK 1 2 }  { m_axi_gmem0_AWLOCK CACHE 1 2 }  { m_axi_gmem0_AWCACHE PROT 1 4 }  { m_axi_gmem0_AWPROT QOS 1 3 }  { m_axi_gmem0_AWQOS REGION 1 4 }  { m_axi_gmem0_AWREGION USER 1 4 }  { m_axi_gmem0_AWUSER DATA 1 1 }  { m_axi_gmem0_WVALID VALID 1 1 }  { m_axi_gmem0_WREADY READY 0 1 }  { m_axi_gmem0_WDATA FIFONUM 1 512 }  { m_axi_gmem0_WSTRB STRB 1 64 }  { m_axi_gmem0_WLAST LAST 1 1 }  { m_axi_gmem0_WID ID 1 1 }  { m_axi_gmem0_WUSER DATA 1 1 }  { m_axi_gmem0_ARVALID VALID 1 1 }  { m_axi_gmem0_ARREADY READY 0 1 }  { m_axi_gmem0_ARADDR ADDR 1 64 }  { m_axi_gmem0_ARID ID 1 1 }  { m_axi_gmem0_ARLEN SIZE 1 8 }  { m_axi_gmem0_ARSIZE BURST 1 3 }  { m_axi_gmem0_ARBURST LOCK 1 2 }  { m_axi_gmem0_ARLOCK CACHE 1 2 }  { m_axi_gmem0_ARCACHE PROT 1 4 }  { m_axi_gmem0_ARPROT QOS 1 3 }  { m_axi_gmem0_ARQOS REGION 1 4 }  { m_axi_gmem0_ARREGION USER 1 4 }  { m_axi_gmem0_ARUSER DATA 1 1 }  { m_axi_gmem0_RVALID VALID 0 1 }  { m_axi_gmem0_RREADY READY 1 1 }  { m_axi_gmem0_RDATA FIFONUM 0 512 }  { m_axi_gmem0_RLAST LAST 0 1 }  { m_axi_gmem0_RID ID 0 1 }  { m_axi_gmem0_RUSER DATA 0 1 }  { m_axi_gmem0_RRESP RESP 0 2 }  { m_axi_gmem0_BVALID VALID 0 1 }  { m_axi_gmem0_BREADY READY 1 1 }  { m_axi_gmem0_BRESP RESP 0 2 }  { m_axi_gmem0_BID ID 0 1 }  { m_axi_gmem0_BUSER DATA 0 1 } } }
	gmem1 { m_axi {  { m_axi_gmem1_AWVALID VALID 1 1 }  { m_axi_gmem1_AWREADY READY 0 1 }  { m_axi_gmem1_AWADDR ADDR 1 64 }  { m_axi_gmem1_AWID ID 1 1 }  { m_axi_gmem1_AWLEN SIZE 1 8 }  { m_axi_gmem1_AWSIZE BURST 1 3 }  { m_axi_gmem1_AWBURST LOCK 1 2 }  { m_axi_gmem1_AWLOCK CACHE 1 2 }  { m_axi_gmem1_AWCACHE PROT 1 4 }  { m_axi_gmem1_AWPROT QOS 1 3 }  { m_axi_gmem1_AWQOS REGION 1 4 }  { m_axi_gmem1_AWREGION USER 1 4 }  { m_axi_gmem1_AWUSER DATA 1 1 }  { m_axi_gmem1_WVALID VALID 1 1 }  { m_axi_gmem1_WREADY READY 0 1 }  { m_axi_gmem1_WDATA FIFONUM 1 512 }  { m_axi_gmem1_WSTRB STRB 1 64 }  { m_axi_gmem1_WLAST LAST 1 1 }  { m_axi_gmem1_WID ID 1 1 }  { m_axi_gmem1_WUSER DATA 1 1 }  { m_axi_gmem1_ARVALID VALID 1 1 }  { m_axi_gmem1_ARREADY READY 0 1 }  { m_axi_gmem1_ARADDR ADDR 1 64 }  { m_axi_gmem1_ARID ID 1 1 }  { m_axi_gmem1_ARLEN SIZE 1 8 }  { m_axi_gmem1_ARSIZE BURST 1 3 }  { m_axi_gmem1_ARBURST LOCK 1 2 }  { m_axi_gmem1_ARLOCK CACHE 1 2 }  { m_axi_gmem1_ARCACHE PROT 1 4 }  { m_axi_gmem1_ARPROT QOS 1 3 }  { m_axi_gmem1_ARQOS REGION 1 4 }  { m_axi_gmem1_ARREGION USER 1 4 }  { m_axi_gmem1_ARUSER DATA 1 1 }  { m_axi_gmem1_RVALID VALID 0 1 }  { m_axi_gmem1_RREADY READY 1 1 }  { m_axi_gmem1_RDATA FIFONUM 0 512 }  { m_axi_gmem1_RLAST LAST 0 1 }  { m_axi_gmem1_RID ID 0 1 }  { m_axi_gmem1_RUSER DATA 0 1 }  { m_axi_gmem1_RRESP RESP 0 2 }  { m_axi_gmem1_BVALID VALID 0 1 }  { m_axi_gmem1_BREADY READY 1 1 }  { m_axi_gmem1_BRESP RESP 0 2 }  { m_axi_gmem1_BID ID 0 1 }  { m_axi_gmem1_BUSER DATA 0 1 } } }
	gmem2 { m_axi {  { m_axi_gmem2_AWVALID VALID 1 1 }  { m_axi_gmem2_AWREADY READY 0 1 }  { m_axi_gmem2_AWADDR ADDR 1 64 }  { m_axi_gmem2_AWID ID 1 1 }  { m_axi_gmem2_AWLEN SIZE 1 8 }  { m_axi_gmem2_AWSIZE BURST 1 3 }  { m_axi_gmem2_AWBURST LOCK 1 2 }  { m_axi_gmem2_AWLOCK CACHE 1 2 }  { m_axi_gmem2_AWCACHE PROT 1 4 }  { m_axi_gmem2_AWPROT QOS 1 3 }  { m_axi_gmem2_AWQOS REGION 1 4 }  { m_axi_gmem2_AWREGION USER 1 4 }  { m_axi_gmem2_AWUSER DATA 1 1 }  { m_axi_gmem2_WVALID VALID 1 1 }  { m_axi_gmem2_WREADY READY 0 1 }  { m_axi_gmem2_WDATA FIFONUM 1 512 }  { m_axi_gmem2_WSTRB STRB 1 64 }  { m_axi_gmem2_WLAST LAST 1 1 }  { m_axi_gmem2_WID ID 1 1 }  { m_axi_gmem2_WUSER DATA 1 1 }  { m_axi_gmem2_ARVALID VALID 1 1 }  { m_axi_gmem2_ARREADY READY 0 1 }  { m_axi_gmem2_ARADDR ADDR 1 64 }  { m_axi_gmem2_ARID ID 1 1 }  { m_axi_gmem2_ARLEN SIZE 1 8 }  { m_axi_gmem2_ARSIZE BURST 1 3 }  { m_axi_gmem2_ARBURST LOCK 1 2 }  { m_axi_gmem2_ARLOCK CACHE 1 2 }  { m_axi_gmem2_ARCACHE PROT 1 4 }  { m_axi_gmem2_ARPROT QOS 1 3 }  { m_axi_gmem2_ARQOS REGION 1 4 }  { m_axi_gmem2_ARREGION USER 1 4 }  { m_axi_gmem2_ARUSER DATA 1 1 }  { m_axi_gmem2_RVALID VALID 0 1 }  { m_axi_gmem2_RREADY READY 1 1 }  { m_axi_gmem2_RDATA FIFONUM 0 512 }  { m_axi_gmem2_RLAST LAST 0 1 }  { m_axi_gmem2_RID ID 0 1 }  { m_axi_gmem2_RUSER DATA 0 1 }  { m_axi_gmem2_RRESP RESP 0 2 }  { m_axi_gmem2_BVALID VALID 0 1 }  { m_axi_gmem2_BREADY READY 1 1 }  { m_axi_gmem2_BRESP RESP 0 2 }  { m_axi_gmem2_BID ID 0 1 }  { m_axi_gmem2_BUSER DATA 0 1 } } }
	gmem3 { m_axi {  { m_axi_gmem3_AWVALID VALID 1 1 }  { m_axi_gmem3_AWREADY READY 0 1 }  { m_axi_gmem3_AWADDR ADDR 1 64 }  { m_axi_gmem3_AWID ID 1 1 }  { m_axi_gmem3_AWLEN SIZE 1 8 }  { m_axi_gmem3_AWSIZE BURST 1 3 }  { m_axi_gmem3_AWBURST LOCK 1 2 }  { m_axi_gmem3_AWLOCK CACHE 1 2 }  { m_axi_gmem3_AWCACHE PROT 1 4 }  { m_axi_gmem3_AWPROT QOS 1 3 }  { m_axi_gmem3_AWQOS REGION 1 4 }  { m_axi_gmem3_AWREGION USER 1 4 }  { m_axi_gmem3_AWUSER DATA 1 1 }  { m_axi_gmem3_WVALID VALID 1 1 }  { m_axi_gmem3_WREADY READY 0 1 }  { m_axi_gmem3_WDATA FIFONUM 1 512 }  { m_axi_gmem3_WSTRB STRB 1 64 }  { m_axi_gmem3_WLAST LAST 1 1 }  { m_axi_gmem3_WID ID 1 1 }  { m_axi_gmem3_WUSER DATA 1 1 }  { m_axi_gmem3_ARVALID VALID 1 1 }  { m_axi_gmem3_ARREADY READY 0 1 }  { m_axi_gmem3_ARADDR ADDR 1 64 }  { m_axi_gmem3_ARID ID 1 1 }  { m_axi_gmem3_ARLEN SIZE 1 8 }  { m_axi_gmem3_ARSIZE BURST 1 3 }  { m_axi_gmem3_ARBURST LOCK 1 2 }  { m_axi_gmem3_ARLOCK CACHE 1 2 }  { m_axi_gmem3_ARCACHE PROT 1 4 }  { m_axi_gmem3_ARPROT QOS 1 3 }  { m_axi_gmem3_ARQOS REGION 1 4 }  { m_axi_gmem3_ARREGION USER 1 4 }  { m_axi_gmem3_ARUSER DATA 1 1 }  { m_axi_gmem3_RVALID VALID 0 1 }  { m_axi_gmem3_RREADY READY 1 1 }  { m_axi_gmem3_RDATA FIFONUM 0 512 }  { m_axi_gmem3_RLAST LAST 0 1 }  { m_axi_gmem3_RID ID 0 1 }  { m_axi_gmem3_RUSER DATA 0 1 }  { m_axi_gmem3_RRESP RESP 0 2 }  { m_axi_gmem3_BVALID VALID 0 1 }  { m_axi_gmem3_BREADY READY 1 1 }  { m_axi_gmem3_BRESP RESP 0 2 }  { m_axi_gmem3_BID ID 0 1 }  { m_axi_gmem3_BUSER DATA 0 1 } } }
	update_stream_V_data_V { axis {  { update_stream_TDATA in_data 0 96 } } }
	update_stream_V_keep_V { axis {  { update_stream_TKEEP in_data 0 12 } } }
	update_stream_V_strb_V { axis {  { update_stream_TSTRB in_data 0 12 } } }
	update_stream_V_last_V { axis {  { update_stream_TLAST in_data 0 1 }  { update_stream_TVALID in_vld 0 1 }  { update_stream_TREADY in_acc 1 1 } } }
}

set maxi_interface_dict [dict create]
dict set maxi_interface_dict gmem0 { CHANNEL_NUM 0 BUNDLE gmem0 NUM_READ_OUTSTANDING 16 NUM_WRITE_OUTSTANDING 16 MAX_READ_BURST_LENGTH 16 MAX_WRITE_BURST_LENGTH 16 READ_WRITE_MODE READ_ONLY}
dict set maxi_interface_dict gmem1 { CHANNEL_NUM 0 BUNDLE gmem1 NUM_READ_OUTSTANDING 16 NUM_WRITE_OUTSTANDING 16 MAX_READ_BURST_LENGTH 16 MAX_WRITE_BURST_LENGTH 16 READ_WRITE_MODE READ_ONLY}
dict set maxi_interface_dict gmem2 { CHANNEL_NUM 0 BUNDLE gmem2 NUM_READ_OUTSTANDING 16 NUM_WRITE_OUTSTANDING 16 MAX_READ_BURST_LENGTH 16 MAX_WRITE_BURST_LENGTH 16 READ_WRITE_MODE WRITE_ONLY}
dict set maxi_interface_dict gmem3 { CHANNEL_NUM 0 BUNDLE gmem3 NUM_READ_OUTSTANDING 16 NUM_WRITE_OUTSTANDING 16 MAX_READ_BURST_LENGTH 16 MAX_WRITE_BURST_LENGTH 16 READ_WRITE_MODE WRITE_ONLY}

# RTL port scheduling information:
set fifoSchedulingInfoList { 
}

# RTL bus port read request latency information:
set busReadReqLatencyList { 
	{ gmem0 64 }
	{ gmem1 64 }
	{ gmem2 64 }
	{ gmem3 64 }
}

# RTL bus port write response latency information:
set busWriteResLatencyList { 
	{ gmem0 64 }
	{ gmem1 64 }
	{ gmem2 64 }
	{ gmem3 64 }
}

# RTL array port load latency information:
set memoryLoadLatencyList { 
}
