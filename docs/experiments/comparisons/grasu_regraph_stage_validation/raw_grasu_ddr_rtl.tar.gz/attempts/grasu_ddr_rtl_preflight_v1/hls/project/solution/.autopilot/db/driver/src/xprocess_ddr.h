// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XPROCESS_DDR_H
#define XPROCESS_DDR_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xprocess_ddr_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XProcess_ddr_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XProcess_ddr;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XProcess_ddr_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XProcess_ddr_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XProcess_ddr_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XProcess_ddr_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XProcess_ddr_Initialize(XProcess_ddr *InstancePtr, UINTPTR BaseAddress);
XProcess_ddr_Config* XProcess_ddr_LookupConfig(UINTPTR BaseAddress);
#else
int XProcess_ddr_Initialize(XProcess_ddr *InstancePtr, u16 DeviceId);
XProcess_ddr_Config* XProcess_ddr_LookupConfig(u16 DeviceId);
#endif
int XProcess_ddr_CfgInitialize(XProcess_ddr *InstancePtr, XProcess_ddr_Config *ConfigPtr);
#else
int XProcess_ddr_Initialize(XProcess_ddr *InstancePtr, const char* InstanceName);
int XProcess_ddr_Release(XProcess_ddr *InstancePtr);
#endif

void XProcess_ddr_Start(XProcess_ddr *InstancePtr);
u32 XProcess_ddr_IsDone(XProcess_ddr *InstancePtr);
u32 XProcess_ddr_IsIdle(XProcess_ddr *InstancePtr);
u32 XProcess_ddr_IsReady(XProcess_ddr *InstancePtr);
void XProcess_ddr_Continue(XProcess_ddr *InstancePtr);
void XProcess_ddr_EnableAutoRestart(XProcess_ddr *InstancePtr);
void XProcess_ddr_DisableAutoRestart(XProcess_ddr *InstancePtr);

void XProcess_ddr_Set_pma_in0_ddr(XProcess_ddr *InstancePtr, u64 Data);
u64 XProcess_ddr_Get_pma_in0_ddr(XProcess_ddr *InstancePtr);
void XProcess_ddr_Set_pma_in1_ddr(XProcess_ddr *InstancePtr, u64 Data);
u64 XProcess_ddr_Get_pma_in1_ddr(XProcess_ddr *InstancePtr);
void XProcess_ddr_Set_pma_out0_ddr(XProcess_ddr *InstancePtr, u64 Data);
u64 XProcess_ddr_Get_pma_out0_ddr(XProcess_ddr *InstancePtr);
void XProcess_ddr_Set_pma_out1_ddr(XProcess_ddr *InstancePtr, u64 Data);
u64 XProcess_ddr_Get_pma_out1_ddr(XProcess_ddr *InstancePtr);

void XProcess_ddr_InterruptGlobalEnable(XProcess_ddr *InstancePtr);
void XProcess_ddr_InterruptGlobalDisable(XProcess_ddr *InstancePtr);
void XProcess_ddr_InterruptEnable(XProcess_ddr *InstancePtr, u32 Mask);
void XProcess_ddr_InterruptDisable(XProcess_ddr *InstancePtr, u32 Mask);
void XProcess_ddr_InterruptClear(XProcess_ddr *InstancePtr, u32 Mask);
u32 XProcess_ddr_InterruptGetEnabled(XProcess_ddr *InstancePtr);
u32 XProcess_ddr_InterruptGetStatus(XProcess_ddr *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
