set moduleName process_r
set isTopModule 0
set isCombinational 0
set isDatapathOnly 0
set isPipelined 0
set pipeline_type none
set FunctionProtocol ap_ctrl_hs
set isOneStateSeq 0
set ProfileFlag 0
set StallSigGenFlag 0
set isEnableWaveformDebug 1
set hasInterrupt 0
set DLRegFirstOffset 0
set DLRegItemOffset 0
set C_modelName {process}
set C_modelType { void 0 }
set ap_memory_interface_dict [dict create]
set C_modelArgList {
	{ gmem0 int 512 regular {axi_master 0}  }
	{ pma_in int 64 regular  }
	{ gmem2 int 512 regular {axi_master 1}  }
	{ pma_out int 64 regular  }
	{ update_stream_ddr_0_0 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_1 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_2 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_3 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_4 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_5 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_6 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_7 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_8 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_9 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_10 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_11 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_12 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_13 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_14 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_0_15 int 96 regular {fifo 0 volatile }  }
}
set hasAXIMCache 0
set hasAXIML2Cache 0
set AXIMCacheInstDict [dict create]
set C_modelArgMapList {[ 
	{ "Name" : "gmem0", "interface" : "axi_master", "bitwidth" : 512, "direction" : "READONLY", "bitSlice":[ {"cElement": [{"cName": "pma_in0_ddr","offset": { "type": "dynamic","port_name": "pma_in0_ddr","bundle": "control"},"direction": "READONLY"}]}]} , 
 	{ "Name" : "pma_in", "interface" : "wire", "bitwidth" : 64, "direction" : "READONLY"} , 
 	{ "Name" : "gmem2", "interface" : "axi_master", "bitwidth" : 512, "direction" : "WRITEONLY", "bitSlice":[ {"cElement": [{"cName": "pma_out0_ddr","offset": { "type": "dynamic","port_name": "pma_out0_ddr","bundle": "control"},"direction": "WRITEONLY"}]}]} , 
 	{ "Name" : "pma_out", "interface" : "wire", "bitwidth" : 64, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_0", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_1", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_2", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_3", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_4", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_5", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_6", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_7", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_8", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_9", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_10", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_11", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_12", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_13", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_14", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_0_15", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} ]}
# RTL Port declarations: 
set portNum 181
set portList { 
	{ ap_clk sc_in sc_logic 1 clock -1 } 
	{ ap_rst sc_in sc_logic 1 reset -1 active_high_sync } 
	{ ap_start sc_in sc_logic 1 start -1 } 
	{ ap_done sc_out sc_logic 1 predone -1 } 
	{ ap_continue sc_in sc_logic 1 continue -1 } 
	{ ap_idle sc_out sc_logic 1 done -1 } 
	{ ap_ready sc_out sc_logic 1 ready -1 } 
	{ m_axi_gmem0_AWVALID sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem0_AWREADY sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem0_AWADDR sc_out sc_lv 64 signal 0 } 
	{ m_axi_gmem0_AWID sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem0_AWLEN sc_out sc_lv 32 signal 0 } 
	{ m_axi_gmem0_AWSIZE sc_out sc_lv 3 signal 0 } 
	{ m_axi_gmem0_AWBURST sc_out sc_lv 2 signal 0 } 
	{ m_axi_gmem0_AWLOCK sc_out sc_lv 2 signal 0 } 
	{ m_axi_gmem0_AWCACHE sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem0_AWPROT sc_out sc_lv 3 signal 0 } 
	{ m_axi_gmem0_AWQOS sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem0_AWREGION sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem0_AWUSER sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem0_WVALID sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem0_WREADY sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem0_WDATA sc_out sc_lv 512 signal 0 } 
	{ m_axi_gmem0_WSTRB sc_out sc_lv 64 signal 0 } 
	{ m_axi_gmem0_WLAST sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem0_WID sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem0_WUSER sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem0_ARVALID sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem0_ARREADY sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem0_ARADDR sc_out sc_lv 64 signal 0 } 
	{ m_axi_gmem0_ARID sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem0_ARLEN sc_out sc_lv 32 signal 0 } 
	{ m_axi_gmem0_ARSIZE sc_out sc_lv 3 signal 0 } 
	{ m_axi_gmem0_ARBURST sc_out sc_lv 2 signal 0 } 
	{ m_axi_gmem0_ARLOCK sc_out sc_lv 2 signal 0 } 
	{ m_axi_gmem0_ARCACHE sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem0_ARPROT sc_out sc_lv 3 signal 0 } 
	{ m_axi_gmem0_ARQOS sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem0_ARREGION sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem0_ARUSER sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem0_RVALID sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem0_RREADY sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem0_RDATA sc_in sc_lv 512 signal 0 } 
	{ m_axi_gmem0_RLAST sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem0_RID sc_in sc_lv 1 signal 0 } 
	{ m_axi_gmem0_RFIFONUM sc_in sc_lv 9 signal 0 } 
	{ m_axi_gmem0_RUSER sc_in sc_lv 1 signal 0 } 
	{ m_axi_gmem0_RRESP sc_in sc_lv 2 signal 0 } 
	{ m_axi_gmem0_BVALID sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem0_BREADY sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem0_BRESP sc_in sc_lv 2 signal 0 } 
	{ m_axi_gmem0_BID sc_in sc_lv 1 signal 0 } 
	{ m_axi_gmem0_BUSER sc_in sc_lv 1 signal 0 } 
	{ pma_in sc_in sc_lv 64 signal 1 } 
	{ m_axi_gmem2_AWVALID sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem2_AWREADY sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem2_AWADDR sc_out sc_lv 64 signal 2 } 
	{ m_axi_gmem2_AWID sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem2_AWLEN sc_out sc_lv 32 signal 2 } 
	{ m_axi_gmem2_AWSIZE sc_out sc_lv 3 signal 2 } 
	{ m_axi_gmem2_AWBURST sc_out sc_lv 2 signal 2 } 
	{ m_axi_gmem2_AWLOCK sc_out sc_lv 2 signal 2 } 
	{ m_axi_gmem2_AWCACHE sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem2_AWPROT sc_out sc_lv 3 signal 2 } 
	{ m_axi_gmem2_AWQOS sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem2_AWREGION sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem2_AWUSER sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem2_WVALID sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem2_WREADY sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem2_WDATA sc_out sc_lv 512 signal 2 } 
	{ m_axi_gmem2_WSTRB sc_out sc_lv 64 signal 2 } 
	{ m_axi_gmem2_WLAST sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem2_WID sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem2_WUSER sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem2_ARVALID sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem2_ARREADY sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem2_ARADDR sc_out sc_lv 64 signal 2 } 
	{ m_axi_gmem2_ARID sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem2_ARLEN sc_out sc_lv 32 signal 2 } 
	{ m_axi_gmem2_ARSIZE sc_out sc_lv 3 signal 2 } 
	{ m_axi_gmem2_ARBURST sc_out sc_lv 2 signal 2 } 
	{ m_axi_gmem2_ARLOCK sc_out sc_lv 2 signal 2 } 
	{ m_axi_gmem2_ARCACHE sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem2_ARPROT sc_out sc_lv 3 signal 2 } 
	{ m_axi_gmem2_ARQOS sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem2_ARREGION sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem2_ARUSER sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem2_RVALID sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem2_RREADY sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem2_RDATA sc_in sc_lv 512 signal 2 } 
	{ m_axi_gmem2_RLAST sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem2_RID sc_in sc_lv 1 signal 2 } 
	{ m_axi_gmem2_RFIFONUM sc_in sc_lv 9 signal 2 } 
	{ m_axi_gmem2_RUSER sc_in sc_lv 1 signal 2 } 
	{ m_axi_gmem2_RRESP sc_in sc_lv 2 signal 2 } 
	{ m_axi_gmem2_BVALID sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem2_BREADY sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem2_BRESP sc_in sc_lv 2 signal 2 } 
	{ m_axi_gmem2_BID sc_in sc_lv 1 signal 2 } 
	{ m_axi_gmem2_BUSER sc_in sc_lv 1 signal 2 } 
	{ pma_out sc_in sc_lv 64 signal 3 } 
	{ update_stream_ddr_0_0_dout sc_in sc_lv 96 signal 4 } 
	{ update_stream_ddr_0_0_num_data_valid sc_in sc_lv 3 signal 4 } 
	{ update_stream_ddr_0_0_fifo_cap sc_in sc_lv 3 signal 4 } 
	{ update_stream_ddr_0_0_empty_n sc_in sc_logic 1 signal 4 } 
	{ update_stream_ddr_0_0_read sc_out sc_logic 1 signal 4 } 
	{ update_stream_ddr_0_1_dout sc_in sc_lv 96 signal 5 } 
	{ update_stream_ddr_0_1_num_data_valid sc_in sc_lv 3 signal 5 } 
	{ update_stream_ddr_0_1_fifo_cap sc_in sc_lv 3 signal 5 } 
	{ update_stream_ddr_0_1_empty_n sc_in sc_logic 1 signal 5 } 
	{ update_stream_ddr_0_1_read sc_out sc_logic 1 signal 5 } 
	{ update_stream_ddr_0_2_dout sc_in sc_lv 96 signal 6 } 
	{ update_stream_ddr_0_2_num_data_valid sc_in sc_lv 3 signal 6 } 
	{ update_stream_ddr_0_2_fifo_cap sc_in sc_lv 3 signal 6 } 
	{ update_stream_ddr_0_2_empty_n sc_in sc_logic 1 signal 6 } 
	{ update_stream_ddr_0_2_read sc_out sc_logic 1 signal 6 } 
	{ update_stream_ddr_0_3_dout sc_in sc_lv 96 signal 7 } 
	{ update_stream_ddr_0_3_num_data_valid sc_in sc_lv 3 signal 7 } 
	{ update_stream_ddr_0_3_fifo_cap sc_in sc_lv 3 signal 7 } 
	{ update_stream_ddr_0_3_empty_n sc_in sc_logic 1 signal 7 } 
	{ update_stream_ddr_0_3_read sc_out sc_logic 1 signal 7 } 
	{ update_stream_ddr_0_4_dout sc_in sc_lv 96 signal 8 } 
	{ update_stream_ddr_0_4_num_data_valid sc_in sc_lv 3 signal 8 } 
	{ update_stream_ddr_0_4_fifo_cap sc_in sc_lv 3 signal 8 } 
	{ update_stream_ddr_0_4_empty_n sc_in sc_logic 1 signal 8 } 
	{ update_stream_ddr_0_4_read sc_out sc_logic 1 signal 8 } 
	{ update_stream_ddr_0_5_dout sc_in sc_lv 96 signal 9 } 
	{ update_stream_ddr_0_5_num_data_valid sc_in sc_lv 3 signal 9 } 
	{ update_stream_ddr_0_5_fifo_cap sc_in sc_lv 3 signal 9 } 
	{ update_stream_ddr_0_5_empty_n sc_in sc_logic 1 signal 9 } 
	{ update_stream_ddr_0_5_read sc_out sc_logic 1 signal 9 } 
	{ update_stream_ddr_0_6_dout sc_in sc_lv 96 signal 10 } 
	{ update_stream_ddr_0_6_num_data_valid sc_in sc_lv 3 signal 10 } 
	{ update_stream_ddr_0_6_fifo_cap sc_in sc_lv 3 signal 10 } 
	{ update_stream_ddr_0_6_empty_n sc_in sc_logic 1 signal 10 } 
	{ update_stream_ddr_0_6_read sc_out sc_logic 1 signal 10 } 
	{ update_stream_ddr_0_7_dout sc_in sc_lv 96 signal 11 } 
	{ update_stream_ddr_0_7_num_data_valid sc_in sc_lv 3 signal 11 } 
	{ update_stream_ddr_0_7_fifo_cap sc_in sc_lv 3 signal 11 } 
	{ update_stream_ddr_0_7_empty_n sc_in sc_logic 1 signal 11 } 
	{ update_stream_ddr_0_7_read sc_out sc_logic 1 signal 11 } 
	{ update_stream_ddr_0_8_dout sc_in sc_lv 96 signal 12 } 
	{ update_stream_ddr_0_8_num_data_valid sc_in sc_lv 3 signal 12 } 
	{ update_stream_ddr_0_8_fifo_cap sc_in sc_lv 3 signal 12 } 
	{ update_stream_ddr_0_8_empty_n sc_in sc_logic 1 signal 12 } 
	{ update_stream_ddr_0_8_read sc_out sc_logic 1 signal 12 } 
	{ update_stream_ddr_0_9_dout sc_in sc_lv 96 signal 13 } 
	{ update_stream_ddr_0_9_num_data_valid sc_in sc_lv 3 signal 13 } 
	{ update_stream_ddr_0_9_fifo_cap sc_in sc_lv 3 signal 13 } 
	{ update_stream_ddr_0_9_empty_n sc_in sc_logic 1 signal 13 } 
	{ update_stream_ddr_0_9_read sc_out sc_logic 1 signal 13 } 
	{ update_stream_ddr_0_10_dout sc_in sc_lv 96 signal 14 } 
	{ update_stream_ddr_0_10_num_data_valid sc_in sc_lv 3 signal 14 } 
	{ update_stream_ddr_0_10_fifo_cap sc_in sc_lv 3 signal 14 } 
	{ update_stream_ddr_0_10_empty_n sc_in sc_logic 1 signal 14 } 
	{ update_stream_ddr_0_10_read sc_out sc_logic 1 signal 14 } 
	{ update_stream_ddr_0_11_dout sc_in sc_lv 96 signal 15 } 
	{ update_stream_ddr_0_11_num_data_valid sc_in sc_lv 3 signal 15 } 
	{ update_stream_ddr_0_11_fifo_cap sc_in sc_lv 3 signal 15 } 
	{ update_stream_ddr_0_11_empty_n sc_in sc_logic 1 signal 15 } 
	{ update_stream_ddr_0_11_read sc_out sc_logic 1 signal 15 } 
	{ update_stream_ddr_0_12_dout sc_in sc_lv 96 signal 16 } 
	{ update_stream_ddr_0_12_num_data_valid sc_in sc_lv 3 signal 16 } 
	{ update_stream_ddr_0_12_fifo_cap sc_in sc_lv 3 signal 16 } 
	{ update_stream_ddr_0_12_empty_n sc_in sc_logic 1 signal 16 } 
	{ update_stream_ddr_0_12_read sc_out sc_logic 1 signal 16 } 
	{ update_stream_ddr_0_13_dout sc_in sc_lv 96 signal 17 } 
	{ update_stream_ddr_0_13_num_data_valid sc_in sc_lv 3 signal 17 } 
	{ update_stream_ddr_0_13_fifo_cap sc_in sc_lv 3 signal 17 } 
	{ update_stream_ddr_0_13_empty_n sc_in sc_logic 1 signal 17 } 
	{ update_stream_ddr_0_13_read sc_out sc_logic 1 signal 17 } 
	{ update_stream_ddr_0_14_dout sc_in sc_lv 96 signal 18 } 
	{ update_stream_ddr_0_14_num_data_valid sc_in sc_lv 3 signal 18 } 
	{ update_stream_ddr_0_14_fifo_cap sc_in sc_lv 3 signal 18 } 
	{ update_stream_ddr_0_14_empty_n sc_in sc_logic 1 signal 18 } 
	{ update_stream_ddr_0_14_read sc_out sc_logic 1 signal 18 } 
	{ update_stream_ddr_0_15_dout sc_in sc_lv 96 signal 19 } 
	{ update_stream_ddr_0_15_num_data_valid sc_in sc_lv 3 signal 19 } 
	{ update_stream_ddr_0_15_fifo_cap sc_in sc_lv 3 signal 19 } 
	{ update_stream_ddr_0_15_empty_n sc_in sc_logic 1 signal 19 } 
	{ update_stream_ddr_0_15_read sc_out sc_logic 1 signal 19 } 
}
set NewPortList {[ 
	{ "name": "ap_clk", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "clock", "bundle":{"name": "ap_clk", "role": "default" }} , 
 	{ "name": "ap_rst", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "reset", "bundle":{"name": "ap_rst", "role": "default" }} , 
 	{ "name": "ap_start", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "start", "bundle":{"name": "ap_start", "role": "default" }} , 
 	{ "name": "ap_done", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "predone", "bundle":{"name": "ap_done", "role": "default" }} , 
 	{ "name": "ap_continue", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "continue", "bundle":{"name": "ap_continue", "role": "default" }} , 
 	{ "name": "ap_idle", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "done", "bundle":{"name": "ap_idle", "role": "default" }} , 
 	{ "name": "ap_ready", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "ready", "bundle":{"name": "ap_ready", "role": "default" }} , 
 	{ "name": "m_axi_gmem0_AWVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "AWVALID" }} , 
 	{ "name": "m_axi_gmem0_AWREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "AWREADY" }} , 
 	{ "name": "m_axi_gmem0_AWADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem0", "role": "AWADDR" }} , 
 	{ "name": "m_axi_gmem0_AWID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "AWID" }} , 
 	{ "name": "m_axi_gmem0_AWLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "gmem0", "role": "AWLEN" }} , 
 	{ "name": "m_axi_gmem0_AWSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem0", "role": "AWSIZE" }} , 
 	{ "name": "m_axi_gmem0_AWBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem0", "role": "AWBURST" }} , 
 	{ "name": "m_axi_gmem0_AWLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem0", "role": "AWLOCK" }} , 
 	{ "name": "m_axi_gmem0_AWCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem0", "role": "AWCACHE" }} , 
 	{ "name": "m_axi_gmem0_AWPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem0", "role": "AWPROT" }} , 
 	{ "name": "m_axi_gmem0_AWQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem0", "role": "AWQOS" }} , 
 	{ "name": "m_axi_gmem0_AWREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem0", "role": "AWREGION" }} , 
 	{ "name": "m_axi_gmem0_AWUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "AWUSER" }} , 
 	{ "name": "m_axi_gmem0_WVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "WVALID" }} , 
 	{ "name": "m_axi_gmem0_WREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "WREADY" }} , 
 	{ "name": "m_axi_gmem0_WDATA", "direction": "out", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem0", "role": "WDATA" }} , 
 	{ "name": "m_axi_gmem0_WSTRB", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem0", "role": "WSTRB" }} , 
 	{ "name": "m_axi_gmem0_WLAST", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "WLAST" }} , 
 	{ "name": "m_axi_gmem0_WID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "WID" }} , 
 	{ "name": "m_axi_gmem0_WUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "WUSER" }} , 
 	{ "name": "m_axi_gmem0_ARVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "ARVALID" }} , 
 	{ "name": "m_axi_gmem0_ARREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "ARREADY" }} , 
 	{ "name": "m_axi_gmem0_ARADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem0", "role": "ARADDR" }} , 
 	{ "name": "m_axi_gmem0_ARID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "ARID" }} , 
 	{ "name": "m_axi_gmem0_ARLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "gmem0", "role": "ARLEN" }} , 
 	{ "name": "m_axi_gmem0_ARSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem0", "role": "ARSIZE" }} , 
 	{ "name": "m_axi_gmem0_ARBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem0", "role": "ARBURST" }} , 
 	{ "name": "m_axi_gmem0_ARLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem0", "role": "ARLOCK" }} , 
 	{ "name": "m_axi_gmem0_ARCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem0", "role": "ARCACHE" }} , 
 	{ "name": "m_axi_gmem0_ARPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem0", "role": "ARPROT" }} , 
 	{ "name": "m_axi_gmem0_ARQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem0", "role": "ARQOS" }} , 
 	{ "name": "m_axi_gmem0_ARREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem0", "role": "ARREGION" }} , 
 	{ "name": "m_axi_gmem0_ARUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "ARUSER" }} , 
 	{ "name": "m_axi_gmem0_RVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "RVALID" }} , 
 	{ "name": "m_axi_gmem0_RREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "RREADY" }} , 
 	{ "name": "m_axi_gmem0_RDATA", "direction": "in", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem0", "role": "RDATA" }} , 
 	{ "name": "m_axi_gmem0_RLAST", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "RLAST" }} , 
 	{ "name": "m_axi_gmem0_RID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "RID" }} , 
 	{ "name": "m_axi_gmem0_RFIFONUM", "direction": "in", "datatype": "sc_lv", "bitwidth":9, "type": "signal", "bundle":{"name": "gmem0", "role": "RFIFONUM" }} , 
 	{ "name": "m_axi_gmem0_RUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "RUSER" }} , 
 	{ "name": "m_axi_gmem0_RRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem0", "role": "RRESP" }} , 
 	{ "name": "m_axi_gmem0_BVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "BVALID" }} , 
 	{ "name": "m_axi_gmem0_BREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "BREADY" }} , 
 	{ "name": "m_axi_gmem0_BRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem0", "role": "BRESP" }} , 
 	{ "name": "m_axi_gmem0_BID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "BID" }} , 
 	{ "name": "m_axi_gmem0_BUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem0", "role": "BUSER" }} , 
 	{ "name": "pma_in", "direction": "in", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "pma_in", "role": "default" }} , 
 	{ "name": "m_axi_gmem2_AWVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "AWVALID" }} , 
 	{ "name": "m_axi_gmem2_AWREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "AWREADY" }} , 
 	{ "name": "m_axi_gmem2_AWADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem2", "role": "AWADDR" }} , 
 	{ "name": "m_axi_gmem2_AWID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "AWID" }} , 
 	{ "name": "m_axi_gmem2_AWLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "gmem2", "role": "AWLEN" }} , 
 	{ "name": "m_axi_gmem2_AWSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem2", "role": "AWSIZE" }} , 
 	{ "name": "m_axi_gmem2_AWBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem2", "role": "AWBURST" }} , 
 	{ "name": "m_axi_gmem2_AWLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem2", "role": "AWLOCK" }} , 
 	{ "name": "m_axi_gmem2_AWCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem2", "role": "AWCACHE" }} , 
 	{ "name": "m_axi_gmem2_AWPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem2", "role": "AWPROT" }} , 
 	{ "name": "m_axi_gmem2_AWQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem2", "role": "AWQOS" }} , 
 	{ "name": "m_axi_gmem2_AWREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem2", "role": "AWREGION" }} , 
 	{ "name": "m_axi_gmem2_AWUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "AWUSER" }} , 
 	{ "name": "m_axi_gmem2_WVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "WVALID" }} , 
 	{ "name": "m_axi_gmem2_WREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "WREADY" }} , 
 	{ "name": "m_axi_gmem2_WDATA", "direction": "out", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem2", "role": "WDATA" }} , 
 	{ "name": "m_axi_gmem2_WSTRB", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem2", "role": "WSTRB" }} , 
 	{ "name": "m_axi_gmem2_WLAST", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "WLAST" }} , 
 	{ "name": "m_axi_gmem2_WID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "WID" }} , 
 	{ "name": "m_axi_gmem2_WUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "WUSER" }} , 
 	{ "name": "m_axi_gmem2_ARVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "ARVALID" }} , 
 	{ "name": "m_axi_gmem2_ARREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "ARREADY" }} , 
 	{ "name": "m_axi_gmem2_ARADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem2", "role": "ARADDR" }} , 
 	{ "name": "m_axi_gmem2_ARID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "ARID" }} , 
 	{ "name": "m_axi_gmem2_ARLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "gmem2", "role": "ARLEN" }} , 
 	{ "name": "m_axi_gmem2_ARSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem2", "role": "ARSIZE" }} , 
 	{ "name": "m_axi_gmem2_ARBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem2", "role": "ARBURST" }} , 
 	{ "name": "m_axi_gmem2_ARLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem2", "role": "ARLOCK" }} , 
 	{ "name": "m_axi_gmem2_ARCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem2", "role": "ARCACHE" }} , 
 	{ "name": "m_axi_gmem2_ARPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem2", "role": "ARPROT" }} , 
 	{ "name": "m_axi_gmem2_ARQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem2", "role": "ARQOS" }} , 
 	{ "name": "m_axi_gmem2_ARREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem2", "role": "ARREGION" }} , 
 	{ "name": "m_axi_gmem2_ARUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "ARUSER" }} , 
 	{ "name": "m_axi_gmem2_RVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "RVALID" }} , 
 	{ "name": "m_axi_gmem2_RREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "RREADY" }} , 
 	{ "name": "m_axi_gmem2_RDATA", "direction": "in", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem2", "role": "RDATA" }} , 
 	{ "name": "m_axi_gmem2_RLAST", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "RLAST" }} , 
 	{ "name": "m_axi_gmem2_RID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "RID" }} , 
 	{ "name": "m_axi_gmem2_RFIFONUM", "direction": "in", "datatype": "sc_lv", "bitwidth":9, "type": "signal", "bundle":{"name": "gmem2", "role": "RFIFONUM" }} , 
 	{ "name": "m_axi_gmem2_RUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "RUSER" }} , 
 	{ "name": "m_axi_gmem2_RRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem2", "role": "RRESP" }} , 
 	{ "name": "m_axi_gmem2_BVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "BVALID" }} , 
 	{ "name": "m_axi_gmem2_BREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "BREADY" }} , 
 	{ "name": "m_axi_gmem2_BRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem2", "role": "BRESP" }} , 
 	{ "name": "m_axi_gmem2_BID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "BID" }} , 
 	{ "name": "m_axi_gmem2_BUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem2", "role": "BUSER" }} , 
 	{ "name": "pma_out", "direction": "in", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "pma_out", "role": "default" }} , 
 	{ "name": "update_stream_ddr_0_0_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_0", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_0_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_0", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_0_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_0", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_0_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_0", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_0_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_0", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_1_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_1", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_1_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_1", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_1_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_1", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_1_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_1", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_1_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_1", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_2_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_2", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_2_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_2", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_2_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_2", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_2_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_2", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_2_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_2", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_3_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_3", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_3_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_3", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_3_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_3", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_3_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_3", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_3_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_3", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_4_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_4", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_4_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_4", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_4_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_4", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_4_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_4", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_4_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_4", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_5_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_5", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_5_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_5", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_5_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_5", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_5_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_5", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_5_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_5", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_6_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_6", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_6_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_6", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_6_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_6", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_6_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_6", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_6_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_6", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_7_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_7", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_7_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_7", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_7_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_7", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_7_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_7", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_7_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_7", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_8_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_8", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_8_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_8", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_8_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_8", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_8_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_8", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_8_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_8", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_9_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_9", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_9_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_9", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_9_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_9", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_9_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_9", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_9_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_9", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_10_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_10", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_10_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_10", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_10_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_10", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_10_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_10", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_10_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_10", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_11_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_11", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_11_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_11", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_11_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_11", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_11_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_11", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_11_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_11", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_12_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_12", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_12_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_12", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_12_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_12", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_12_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_12", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_12_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_12", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_13_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_13", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_13_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_13", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_13_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_13", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_13_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_13", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_13_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_13", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_14_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_14", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_14_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_14", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_14_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_14", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_14_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_14", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_14_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_14", "role": "read" }} , 
 	{ "name": "update_stream_ddr_0_15_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_0_15", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_0_15_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_15", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_0_15_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_0_15", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_0_15_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_15", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_0_15_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_0_15", "role": "read" }}  ]}

set RtlHierarchyInfo {[
	{"ID" : "0", "Level" : "0", "Path" : "`AUTOTB_DUT_INST", "Parent" : "", "Child" : ["1"],
		"CDFG" : "process_r",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "1", "ap_idle" : "1", "real_start" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "0",
		"VariableLatency" : "1", "ExactLatency" : "-1", "EstimateLatencyMin" : "-1", "EstimateLatencyMax" : "-1",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "1",
		"HasNonBlockingOperation" : "0",
		"IsBlackBox" : "0",
		"Port" : [
			{"Name" : "gmem0", "Type" : "MAXI", "Direction" : "I",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "gmem0", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "pma_in", "Type" : "None", "Direction" : "I"},
			{"Name" : "gmem2", "Type" : "MAXI", "Direction" : "O",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "gmem2", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "pma_out", "Type" : "None", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_0", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_0", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_1", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_1", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_2", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_2", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_3", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_3", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_4", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_4", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_5", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_5", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_6", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_6", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_7", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_7", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_8", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_8", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_9", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_9", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_10", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_10", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_11", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_11", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_12", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_12", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_13", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_13", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_14", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_14", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_0_15", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_0_15", "Inst_start_state" : "2", "Inst_end_state" : "3"}]}],
		"Loop" : [
			{"Name" : "process_ddr_loop", "PipelineType" : "no",
				"LoopDec" : {"FSMBitwidth" : "4", "FirstState" : "ap_ST_fsm_state2", "LastState" : ["ap_ST_fsm_state4"], "QuitState" : ["ap_ST_fsm_state2"], "PreState" : ["ap_ST_fsm_state1"], "PostState" : ["ap_ST_fsm_state1"], "OneDepthLoop" : "0", "OneStateBlock": ""}}]},
	{"ID" : "1", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.grp_process_Pipeline_process_ddr_sub_loop_fu_108", "Parent" : "0", "Child" : ["2", "3"],
		"CDFG" : "process_Pipeline_process_ddr_sub_loop",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "0", "ap_idle" : "1", "real_start" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "0",
		"VariableLatency" : "1", "ExactLatency" : "-1", "EstimateLatencyMin" : "162", "EstimateLatencyMax" : "162",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "1",
		"IsBlackBox" : "0",
		"Port" : [
			{"Name" : "finish_r", "Type" : "None", "Direction" : "I"},
			{"Name" : "info", "Type" : "None", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_0", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_1", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_2", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_3", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_4", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_5", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_6", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_7", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_8", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_9", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_10", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_11", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_12", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_13", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_14", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_0_15", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "pma_in", "Type" : "None", "Direction" : "I"},
			{"Name" : "gmem0", "Type" : "MAXI", "Direction" : "I",
				"BlockSignal" : [
					{"Name" : "gmem0_blk_n_AR", "Type" : "RtlSignal"},
					{"Name" : "gmem0_blk_n_R", "Type" : "RtlSignal"}]},
			{"Name" : "pma_out", "Type" : "None", "Direction" : "I"},
			{"Name" : "gmem2", "Type" : "MAXI", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "gmem2_blk_n_AW", "Type" : "RtlSignal"},
					{"Name" : "gmem2_blk_n_W", "Type" : "RtlSignal"},
					{"Name" : "gmem2_blk_n_B", "Type" : "RtlSignal"}]},
			{"Name" : "finish_4_out", "Type" : "Vld", "Direction" : "O"},
			{"Name" : "info_4_out", "Type" : "Vld", "Direction" : "O"}],
		"Loop" : [
			{"Name" : "process_ddr_sub_loop", "PipelineType" : "UPC",
				"LoopDec" : {"FSMBitwidth" : "1", "FirstState" : "ap_ST_fsm_pp0_stage0", "FirstStateIter" : "ap_enable_reg_pp0_iter0", "FirstStateBlock" : "ap_block_pp0_stage0_subdone", "LastState" : "ap_ST_fsm_pp0_stage0", "LastStateIter" : "ap_enable_reg_pp0_iter145", "LastStateBlock" : "ap_block_pp0_stage0_subdone", "QuitState" : "ap_ST_fsm_pp0_stage0", "QuitStateIter" : "ap_enable_reg_pp0_iter145", "QuitStateBlock" : "ap_block_pp0_stage0_subdone", "OneDepthLoop" : "0", "has_ap_ctrl" : "1", "has_continue" : "0"}}]},
	{"ID" : "2", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_process_Pipeline_process_ddr_sub_loop_fu_108.sparsemux_7_2_512_1_1_U77", "Parent" : "1"},
	{"ID" : "3", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_process_Pipeline_process_ddr_sub_loop_fu_108.flow_control_loop_pipe_sequential_init_U", "Parent" : "1"}]}


set ArgLastReadFirstWriteLatency {
	process_r {
		gmem0 {Type I LastRead 73 FirstWrite -1}
		pma_in {Type I LastRead 0 FirstWrite -1}
		gmem2 {Type O LastRead 78 FirstWrite 77}
		pma_out {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_0 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_1 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_2 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_3 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_4 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_5 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_6 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_7 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_8 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_9 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_10 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_11 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_12 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_13 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_14 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_15 {Type I LastRead 0 FirstWrite -1}}
	process_Pipeline_process_ddr_sub_loop {
		finish_r {Type I LastRead 0 FirstWrite -1}
		info {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_0 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_1 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_2 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_3 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_4 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_5 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_6 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_7 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_8 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_9 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_10 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_11 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_12 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_13 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_14 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_0_15 {Type I LastRead 0 FirstWrite -1}
		pma_in {Type I LastRead 0 FirstWrite -1}
		gmem0 {Type I LastRead 73 FirstWrite -1}
		pma_out {Type I LastRead 0 FirstWrite -1}
		gmem2 {Type O LastRead 78 FirstWrite 77}
		finish_4_out {Type O LastRead -1 FirstWrite 144}
		info_4_out {Type O LastRead -1 FirstWrite 144}}}

set hasDtUnsupportedChannel 0

set PerformanceInfo {[
	{"Name" : "Latency", "Min" : "-1", "Max" : "-1"}
	, {"Name" : "Interval", "Min" : "-1", "Max" : "-1"}
]}

set PipelineEnableSignalInfo {[
]}

set Spec2ImplPortList { 
	 { m_axi {  { m_axi_gmem0_AWVALID VALID 1 1 }  { m_axi_gmem0_AWREADY READY 0 1 }  { m_axi_gmem0_AWADDR ADDR 1 64 }  { m_axi_gmem0_AWID ID 1 1 }  { m_axi_gmem0_AWLEN SIZE 1 32 }  { m_axi_gmem0_AWSIZE BURST 1 3 }  { m_axi_gmem0_AWBURST LOCK 1 2 }  { m_axi_gmem0_AWLOCK CACHE 1 2 }  { m_axi_gmem0_AWCACHE PROT 1 4 }  { m_axi_gmem0_AWPROT QOS 1 3 }  { m_axi_gmem0_AWQOS REGION 1 4 }  { m_axi_gmem0_AWREGION USER 1 4 }  { m_axi_gmem0_AWUSER DATA 1 1 }  { m_axi_gmem0_WVALID VALID 1 1 }  { m_axi_gmem0_WREADY READY 0 1 }  { m_axi_gmem0_WDATA FIFONUM 1 512 }  { m_axi_gmem0_WSTRB STRB 1 64 }  { m_axi_gmem0_WLAST LAST 1 1 }  { m_axi_gmem0_WID ID 1 1 }  { m_axi_gmem0_WUSER DATA 1 1 }  { m_axi_gmem0_ARVALID VALID 1 1 }  { m_axi_gmem0_ARREADY READY 0 1 }  { m_axi_gmem0_ARADDR ADDR 1 64 }  { m_axi_gmem0_ARID ID 1 1 }  { m_axi_gmem0_ARLEN SIZE 1 32 }  { m_axi_gmem0_ARSIZE BURST 1 3 }  { m_axi_gmem0_ARBURST LOCK 1 2 }  { m_axi_gmem0_ARLOCK CACHE 1 2 }  { m_axi_gmem0_ARCACHE PROT 1 4 }  { m_axi_gmem0_ARPROT QOS 1 3 }  { m_axi_gmem0_ARQOS REGION 1 4 }  { m_axi_gmem0_ARREGION USER 1 4 }  { m_axi_gmem0_ARUSER DATA 1 1 }  { m_axi_gmem0_RVALID VALID 0 1 }  { m_axi_gmem0_RREADY READY 1 1 }  { m_axi_gmem0_RDATA FIFONUM 0 512 }  { m_axi_gmem0_RLAST LAST 0 1 }  { m_axi_gmem0_RID ID 0 1 }  { m_axi_gmem0_RFIFONUM LEN 0 9 }  { m_axi_gmem0_RUSER DATA 0 1 }  { m_axi_gmem0_RRESP RESP 0 2 }  { m_axi_gmem0_BVALID VALID 0 1 }  { m_axi_gmem0_BREADY READY 1 1 }  { m_axi_gmem0_BRESP RESP 0 2 }  { m_axi_gmem0_BID ID 0 1 }  { m_axi_gmem0_BUSER DATA 0 1 } } }
	pma_in { ap_none {  { pma_in in_data 0 64 } } }
	 { m_axi {  { m_axi_gmem2_AWVALID VALID 1 1 }  { m_axi_gmem2_AWREADY READY 0 1 }  { m_axi_gmem2_AWADDR ADDR 1 64 }  { m_axi_gmem2_AWID ID 1 1 }  { m_axi_gmem2_AWLEN SIZE 1 32 }  { m_axi_gmem2_AWSIZE BURST 1 3 }  { m_axi_gmem2_AWBURST LOCK 1 2 }  { m_axi_gmem2_AWLOCK CACHE 1 2 }  { m_axi_gmem2_AWCACHE PROT 1 4 }  { m_axi_gmem2_AWPROT QOS 1 3 }  { m_axi_gmem2_AWQOS REGION 1 4 }  { m_axi_gmem2_AWREGION USER 1 4 }  { m_axi_gmem2_AWUSER DATA 1 1 }  { m_axi_gmem2_WVALID VALID 1 1 }  { m_axi_gmem2_WREADY READY 0 1 }  { m_axi_gmem2_WDATA FIFONUM 1 512 }  { m_axi_gmem2_WSTRB STRB 1 64 }  { m_axi_gmem2_WLAST LAST 1 1 }  { m_axi_gmem2_WID ID 1 1 }  { m_axi_gmem2_WUSER DATA 1 1 }  { m_axi_gmem2_ARVALID VALID 1 1 }  { m_axi_gmem2_ARREADY READY 0 1 }  { m_axi_gmem2_ARADDR ADDR 1 64 }  { m_axi_gmem2_ARID ID 1 1 }  { m_axi_gmem2_ARLEN SIZE 1 32 }  { m_axi_gmem2_ARSIZE BURST 1 3 }  { m_axi_gmem2_ARBURST LOCK 1 2 }  { m_axi_gmem2_ARLOCK CACHE 1 2 }  { m_axi_gmem2_ARCACHE PROT 1 4 }  { m_axi_gmem2_ARPROT QOS 1 3 }  { m_axi_gmem2_ARQOS REGION 1 4 }  { m_axi_gmem2_ARREGION USER 1 4 }  { m_axi_gmem2_ARUSER DATA 1 1 }  { m_axi_gmem2_RVALID VALID 0 1 }  { m_axi_gmem2_RREADY READY 1 1 }  { m_axi_gmem2_RDATA FIFONUM 0 512 }  { m_axi_gmem2_RLAST LAST 0 1 }  { m_axi_gmem2_RID ID 0 1 }  { m_axi_gmem2_RFIFONUM LEN 0 9 }  { m_axi_gmem2_RUSER DATA 0 1 }  { m_axi_gmem2_RRESP RESP 0 2 }  { m_axi_gmem2_BVALID VALID 0 1 }  { m_axi_gmem2_BREADY READY 1 1 }  { m_axi_gmem2_BRESP RESP 0 2 }  { m_axi_gmem2_BID ID 0 1 }  { m_axi_gmem2_BUSER DATA 0 1 } } }
	pma_out { ap_none {  { pma_out in_data 0 64 } } }
	update_stream_ddr_0_0 { ap_fifo {  { update_stream_ddr_0_0_dout fifo_data_in 0 96 }  { update_stream_ddr_0_0_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_0_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_0_empty_n fifo_status 0 1 }  { update_stream_ddr_0_0_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_1 { ap_fifo {  { update_stream_ddr_0_1_dout fifo_data_in 0 96 }  { update_stream_ddr_0_1_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_1_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_1_empty_n fifo_status 0 1 }  { update_stream_ddr_0_1_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_2 { ap_fifo {  { update_stream_ddr_0_2_dout fifo_data_in 0 96 }  { update_stream_ddr_0_2_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_2_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_2_empty_n fifo_status 0 1 }  { update_stream_ddr_0_2_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_3 { ap_fifo {  { update_stream_ddr_0_3_dout fifo_data_in 0 96 }  { update_stream_ddr_0_3_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_3_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_3_empty_n fifo_status 0 1 }  { update_stream_ddr_0_3_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_4 { ap_fifo {  { update_stream_ddr_0_4_dout fifo_data_in 0 96 }  { update_stream_ddr_0_4_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_4_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_4_empty_n fifo_status 0 1 }  { update_stream_ddr_0_4_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_5 { ap_fifo {  { update_stream_ddr_0_5_dout fifo_data_in 0 96 }  { update_stream_ddr_0_5_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_5_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_5_empty_n fifo_status 0 1 }  { update_stream_ddr_0_5_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_6 { ap_fifo {  { update_stream_ddr_0_6_dout fifo_data_in 0 96 }  { update_stream_ddr_0_6_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_6_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_6_empty_n fifo_status 0 1 }  { update_stream_ddr_0_6_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_7 { ap_fifo {  { update_stream_ddr_0_7_dout fifo_data_in 0 96 }  { update_stream_ddr_0_7_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_7_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_7_empty_n fifo_status 0 1 }  { update_stream_ddr_0_7_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_8 { ap_fifo {  { update_stream_ddr_0_8_dout fifo_data_in 0 96 }  { update_stream_ddr_0_8_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_8_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_8_empty_n fifo_status 0 1 }  { update_stream_ddr_0_8_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_9 { ap_fifo {  { update_stream_ddr_0_9_dout fifo_data_in 0 96 }  { update_stream_ddr_0_9_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_9_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_9_empty_n fifo_status 0 1 }  { update_stream_ddr_0_9_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_10 { ap_fifo {  { update_stream_ddr_0_10_dout fifo_data_in 0 96 }  { update_stream_ddr_0_10_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_10_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_10_empty_n fifo_status 0 1 }  { update_stream_ddr_0_10_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_11 { ap_fifo {  { update_stream_ddr_0_11_dout fifo_data_in 0 96 }  { update_stream_ddr_0_11_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_11_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_11_empty_n fifo_status 0 1 }  { update_stream_ddr_0_11_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_12 { ap_fifo {  { update_stream_ddr_0_12_dout fifo_data_in 0 96 }  { update_stream_ddr_0_12_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_12_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_12_empty_n fifo_status 0 1 }  { update_stream_ddr_0_12_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_13 { ap_fifo {  { update_stream_ddr_0_13_dout fifo_data_in 0 96 }  { update_stream_ddr_0_13_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_13_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_13_empty_n fifo_status 0 1 }  { update_stream_ddr_0_13_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_14 { ap_fifo {  { update_stream_ddr_0_14_dout fifo_data_in 0 96 }  { update_stream_ddr_0_14_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_14_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_14_empty_n fifo_status 0 1 }  { update_stream_ddr_0_14_read fifo_port_we 1 1 } } }
	update_stream_ddr_0_15 { ap_fifo {  { update_stream_ddr_0_15_dout fifo_data_in 0 96 }  { update_stream_ddr_0_15_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_0_15_fifo_cap fifo_update 0 3 }  { update_stream_ddr_0_15_empty_n fifo_status 0 1 }  { update_stream_ddr_0_15_read fifo_port_we 1 1 } } }
}
