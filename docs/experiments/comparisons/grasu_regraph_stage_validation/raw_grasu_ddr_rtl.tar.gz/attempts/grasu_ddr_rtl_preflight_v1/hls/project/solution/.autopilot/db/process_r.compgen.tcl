# This script segment is generated automatically by AutoPilot

# clear list
if {${::AESL::PGuard_autoexp_gen}} {
    cg_default_interface_gen_dc_begin
    cg_default_interface_gen_bundle_begin
    AESL_LIB_XILADAPTER::native_axis_begin
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 103 \
    name gmem0 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_gmem0 \
    op interface \
    ports { m_axi_gmem0_AWVALID { O 1 bit } m_axi_gmem0_AWREADY { I 1 bit } m_axi_gmem0_AWADDR { O 64 vector } m_axi_gmem0_AWID { O 1 vector } m_axi_gmem0_AWLEN { O 32 vector } m_axi_gmem0_AWSIZE { O 3 vector } m_axi_gmem0_AWBURST { O 2 vector } m_axi_gmem0_AWLOCK { O 2 vector } m_axi_gmem0_AWCACHE { O 4 vector } m_axi_gmem0_AWPROT { O 3 vector } m_axi_gmem0_AWQOS { O 4 vector } m_axi_gmem0_AWREGION { O 4 vector } m_axi_gmem0_AWUSER { O 1 vector } m_axi_gmem0_WVALID { O 1 bit } m_axi_gmem0_WREADY { I 1 bit } m_axi_gmem0_WDATA { O 512 vector } m_axi_gmem0_WSTRB { O 64 vector } m_axi_gmem0_WLAST { O 1 bit } m_axi_gmem0_WID { O 1 vector } m_axi_gmem0_WUSER { O 1 vector } m_axi_gmem0_ARVALID { O 1 bit } m_axi_gmem0_ARREADY { I 1 bit } m_axi_gmem0_ARADDR { O 64 vector } m_axi_gmem0_ARID { O 1 vector } m_axi_gmem0_ARLEN { O 32 vector } m_axi_gmem0_ARSIZE { O 3 vector } m_axi_gmem0_ARBURST { O 2 vector } m_axi_gmem0_ARLOCK { O 2 vector } m_axi_gmem0_ARCACHE { O 4 vector } m_axi_gmem0_ARPROT { O 3 vector } m_axi_gmem0_ARQOS { O 4 vector } m_axi_gmem0_ARREGION { O 4 vector } m_axi_gmem0_ARUSER { O 1 vector } m_axi_gmem0_RVALID { I 1 bit } m_axi_gmem0_RREADY { O 1 bit } m_axi_gmem0_RDATA { I 512 vector } m_axi_gmem0_RLAST { I 1 bit } m_axi_gmem0_RID { I 1 vector } m_axi_gmem0_RFIFONUM { I 9 vector } m_axi_gmem0_RUSER { I 1 vector } m_axi_gmem0_RRESP { I 2 vector } m_axi_gmem0_BVALID { I 1 bit } m_axi_gmem0_BREADY { O 1 bit } m_axi_gmem0_BRESP { I 2 vector } m_axi_gmem0_BID { I 1 vector } m_axi_gmem0_BUSER { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 104 \
    name pma_in \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_pma_in \
    op interface \
    ports { pma_in { I 64 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 105 \
    name gmem2 \
    type other \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_gmem2 \
    op interface \
    ports { m_axi_gmem2_AWVALID { O 1 bit } m_axi_gmem2_AWREADY { I 1 bit } m_axi_gmem2_AWADDR { O 64 vector } m_axi_gmem2_AWID { O 1 vector } m_axi_gmem2_AWLEN { O 32 vector } m_axi_gmem2_AWSIZE { O 3 vector } m_axi_gmem2_AWBURST { O 2 vector } m_axi_gmem2_AWLOCK { O 2 vector } m_axi_gmem2_AWCACHE { O 4 vector } m_axi_gmem2_AWPROT { O 3 vector } m_axi_gmem2_AWQOS { O 4 vector } m_axi_gmem2_AWREGION { O 4 vector } m_axi_gmem2_AWUSER { O 1 vector } m_axi_gmem2_WVALID { O 1 bit } m_axi_gmem2_WREADY { I 1 bit } m_axi_gmem2_WDATA { O 512 vector } m_axi_gmem2_WSTRB { O 64 vector } m_axi_gmem2_WLAST { O 1 bit } m_axi_gmem2_WID { O 1 vector } m_axi_gmem2_WUSER { O 1 vector } m_axi_gmem2_ARVALID { O 1 bit } m_axi_gmem2_ARREADY { I 1 bit } m_axi_gmem2_ARADDR { O 64 vector } m_axi_gmem2_ARID { O 1 vector } m_axi_gmem2_ARLEN { O 32 vector } m_axi_gmem2_ARSIZE { O 3 vector } m_axi_gmem2_ARBURST { O 2 vector } m_axi_gmem2_ARLOCK { O 2 vector } m_axi_gmem2_ARCACHE { O 4 vector } m_axi_gmem2_ARPROT { O 3 vector } m_axi_gmem2_ARQOS { O 4 vector } m_axi_gmem2_ARREGION { O 4 vector } m_axi_gmem2_ARUSER { O 1 vector } m_axi_gmem2_RVALID { I 1 bit } m_axi_gmem2_RREADY { O 1 bit } m_axi_gmem2_RDATA { I 512 vector } m_axi_gmem2_RLAST { I 1 bit } m_axi_gmem2_RID { I 1 vector } m_axi_gmem2_RFIFONUM { I 9 vector } m_axi_gmem2_RUSER { I 1 vector } m_axi_gmem2_RRESP { I 2 vector } m_axi_gmem2_BVALID { I 1 bit } m_axi_gmem2_BREADY { O 1 bit } m_axi_gmem2_BRESP { I 2 vector } m_axi_gmem2_BID { I 1 vector } m_axi_gmem2_BUSER { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 106 \
    name pma_out \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_pma_out \
    op interface \
    ports { pma_out { I 64 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 107 \
    name update_stream_ddr_0_0 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_0 \
    op interface \
    ports { update_stream_ddr_0_0_dout { I 96 vector } update_stream_ddr_0_0_num_data_valid { I 3 vector } update_stream_ddr_0_0_fifo_cap { I 3 vector } update_stream_ddr_0_0_empty_n { I 1 bit } update_stream_ddr_0_0_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 108 \
    name update_stream_ddr_0_1 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_1 \
    op interface \
    ports { update_stream_ddr_0_1_dout { I 96 vector } update_stream_ddr_0_1_num_data_valid { I 3 vector } update_stream_ddr_0_1_fifo_cap { I 3 vector } update_stream_ddr_0_1_empty_n { I 1 bit } update_stream_ddr_0_1_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 109 \
    name update_stream_ddr_0_2 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_2 \
    op interface \
    ports { update_stream_ddr_0_2_dout { I 96 vector } update_stream_ddr_0_2_num_data_valid { I 3 vector } update_stream_ddr_0_2_fifo_cap { I 3 vector } update_stream_ddr_0_2_empty_n { I 1 bit } update_stream_ddr_0_2_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 110 \
    name update_stream_ddr_0_3 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_3 \
    op interface \
    ports { update_stream_ddr_0_3_dout { I 96 vector } update_stream_ddr_0_3_num_data_valid { I 3 vector } update_stream_ddr_0_3_fifo_cap { I 3 vector } update_stream_ddr_0_3_empty_n { I 1 bit } update_stream_ddr_0_3_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 111 \
    name update_stream_ddr_0_4 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_4 \
    op interface \
    ports { update_stream_ddr_0_4_dout { I 96 vector } update_stream_ddr_0_4_num_data_valid { I 3 vector } update_stream_ddr_0_4_fifo_cap { I 3 vector } update_stream_ddr_0_4_empty_n { I 1 bit } update_stream_ddr_0_4_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 112 \
    name update_stream_ddr_0_5 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_5 \
    op interface \
    ports { update_stream_ddr_0_5_dout { I 96 vector } update_stream_ddr_0_5_num_data_valid { I 3 vector } update_stream_ddr_0_5_fifo_cap { I 3 vector } update_stream_ddr_0_5_empty_n { I 1 bit } update_stream_ddr_0_5_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 113 \
    name update_stream_ddr_0_6 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_6 \
    op interface \
    ports { update_stream_ddr_0_6_dout { I 96 vector } update_stream_ddr_0_6_num_data_valid { I 3 vector } update_stream_ddr_0_6_fifo_cap { I 3 vector } update_stream_ddr_0_6_empty_n { I 1 bit } update_stream_ddr_0_6_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 114 \
    name update_stream_ddr_0_7 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_7 \
    op interface \
    ports { update_stream_ddr_0_7_dout { I 96 vector } update_stream_ddr_0_7_num_data_valid { I 3 vector } update_stream_ddr_0_7_fifo_cap { I 3 vector } update_stream_ddr_0_7_empty_n { I 1 bit } update_stream_ddr_0_7_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 115 \
    name update_stream_ddr_0_8 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_8 \
    op interface \
    ports { update_stream_ddr_0_8_dout { I 96 vector } update_stream_ddr_0_8_num_data_valid { I 3 vector } update_stream_ddr_0_8_fifo_cap { I 3 vector } update_stream_ddr_0_8_empty_n { I 1 bit } update_stream_ddr_0_8_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 116 \
    name update_stream_ddr_0_9 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_9 \
    op interface \
    ports { update_stream_ddr_0_9_dout { I 96 vector } update_stream_ddr_0_9_num_data_valid { I 3 vector } update_stream_ddr_0_9_fifo_cap { I 3 vector } update_stream_ddr_0_9_empty_n { I 1 bit } update_stream_ddr_0_9_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 117 \
    name update_stream_ddr_0_10 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_10 \
    op interface \
    ports { update_stream_ddr_0_10_dout { I 96 vector } update_stream_ddr_0_10_num_data_valid { I 3 vector } update_stream_ddr_0_10_fifo_cap { I 3 vector } update_stream_ddr_0_10_empty_n { I 1 bit } update_stream_ddr_0_10_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 118 \
    name update_stream_ddr_0_11 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_11 \
    op interface \
    ports { update_stream_ddr_0_11_dout { I 96 vector } update_stream_ddr_0_11_num_data_valid { I 3 vector } update_stream_ddr_0_11_fifo_cap { I 3 vector } update_stream_ddr_0_11_empty_n { I 1 bit } update_stream_ddr_0_11_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 119 \
    name update_stream_ddr_0_12 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_12 \
    op interface \
    ports { update_stream_ddr_0_12_dout { I 96 vector } update_stream_ddr_0_12_num_data_valid { I 3 vector } update_stream_ddr_0_12_fifo_cap { I 3 vector } update_stream_ddr_0_12_empty_n { I 1 bit } update_stream_ddr_0_12_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 120 \
    name update_stream_ddr_0_13 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_13 \
    op interface \
    ports { update_stream_ddr_0_13_dout { I 96 vector } update_stream_ddr_0_13_num_data_valid { I 3 vector } update_stream_ddr_0_13_fifo_cap { I 3 vector } update_stream_ddr_0_13_empty_n { I 1 bit } update_stream_ddr_0_13_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 121 \
    name update_stream_ddr_0_14 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_14 \
    op interface \
    ports { update_stream_ddr_0_14_dout { I 96 vector } update_stream_ddr_0_14_num_data_valid { I 3 vector } update_stream_ddr_0_14_fifo_cap { I 3 vector } update_stream_ddr_0_14_empty_n { I 1 bit } update_stream_ddr_0_14_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 122 \
    name update_stream_ddr_0_15 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_0_15 \
    op interface \
    ports { update_stream_ddr_0_15_dout { I 96 vector } update_stream_ddr_0_15_num_data_valid { I 3 vector } update_stream_ddr_0_15_fifo_cap { I 3 vector } update_stream_ddr_0_15_empty_n { I 1 bit } update_stream_ddr_0_15_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id -1 \
    name ap_ctrl \
    type ap_ctrl \
    reset_level 1 \
    sync_rst true \
    corename ap_ctrl \
    op interface \
    ports { ap_start { I 1 bit } ap_ready { O 1 bit } ap_done { O 1 bit } ap_idle { O 1 bit } ap_continue { I 1 bit } } \
} "
}


# Adapter definition:
set PortName ap_clk
set DataWd 1 
if {${::AESL::PGuard_autoexp_gen}} {
if {[info proc cg_default_interface_gen_clock] == "cg_default_interface_gen_clock"} {
eval "cg_default_interface_gen_clock { \
    id -2 \
    name ${PortName} \
    reset_level 1 \
    sync_rst true \
    corename apif_ap_clk \
    data_wd ${DataWd} \
    op interface \
}"
} else {
puts "@W \[IMPL-113\] Cannot find bus interface model in the library. Ignored generation of bus interface for '${PortName}'"
}
}


# Adapter definition:
set PortName ap_rst
set DataWd 1 
if {${::AESL::PGuard_autoexp_gen}} {
if {[info proc cg_default_interface_gen_reset] == "cg_default_interface_gen_reset"} {
eval "cg_default_interface_gen_reset { \
    id -3 \
    name ${PortName} \
    reset_level 1 \
    sync_rst true \
    corename apif_ap_rst \
    data_wd ${DataWd} \
    op interface \
}"
} else {
puts "@W \[IMPL-114\] Cannot find bus interface model in the library. Ignored generation of bus interface for '${PortName}'"
}
}



# merge
if {${::AESL::PGuard_autoexp_gen}} {
    cg_default_interface_gen_dc_end
    cg_default_interface_gen_bundle_end
    AESL_LIB_XILADAPTER::native_axis_end
}


