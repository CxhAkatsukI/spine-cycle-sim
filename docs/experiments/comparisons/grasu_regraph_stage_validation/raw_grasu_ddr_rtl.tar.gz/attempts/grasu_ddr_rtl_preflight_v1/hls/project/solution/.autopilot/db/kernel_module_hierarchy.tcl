set ModuleHierarchy {[{
"Name" : "process_ddr","ID" : "0","Type" : "dataflow",
"SubInsts" : [
	{"Name" : "dispatch_update_U0","ID" : "1","Type" : "sequential",
		"SubInsts" : [
		{"Name" : "grp_dispatch_update_Pipeline_dispatch_loop_fu_358","ID" : "2","Type" : "sequential",
			"SubLoops" : [
			{"Name" : "dispatch_loop","ID" : "3","Type" : "pipeline"},]},]},
	{"Name" : "process_U0","ID" : "4","Type" : "sequential",
		"SubLoops" : [
		{"Name" : "process_ddr_loop","ID" : "5","Type" : "no",
		"SubInsts" : [
		{"Name" : "grp_process_Pipeline_process_ddr_sub_loop_fu_108","ID" : "6","Type" : "sequential",
				"SubLoops" : [
				{"Name" : "process_ddr_sub_loop","ID" : "7","Type" : "pipeline"},]},]},]},
	{"Name" : "process_1_U0","ID" : "8","Type" : "sequential",
		"SubLoops" : [
		{"Name" : "process_ddr_loop","ID" : "9","Type" : "no",
		"SubInsts" : [
		{"Name" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108","ID" : "10","Type" : "sequential",
				"SubLoops" : [
				{"Name" : "process_ddr_sub_loop","ID" : "11","Type" : "pipeline"},]},]},]},]
}]}