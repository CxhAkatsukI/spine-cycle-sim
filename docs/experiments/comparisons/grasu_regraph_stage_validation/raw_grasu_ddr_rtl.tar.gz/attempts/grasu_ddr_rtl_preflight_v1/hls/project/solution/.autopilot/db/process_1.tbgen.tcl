set moduleName process_1
set isTopModule 0
set isCombinational 0
set isDatapathOnly 0
set isPipelined 0
set pipeline_type none
set FunctionProtocol ap_ctrl_hs
set isOneStateSeq 0
set ProfileFlag 0
set StallSigGenFlag 0
set isEnableWaveformDebug 1
set hasInterrupt 0
set DLRegFirstOffset 0
set DLRegItemOffset 0
set C_modelName {process.1}
set C_modelType { void 0 }
set ap_memory_interface_dict [dict create]
set C_modelArgList {
	{ gmem1 int 512 regular {axi_master 0}  }
	{ pma_in int 64 regular  }
	{ gmem3 int 512 regular {axi_master 1}  }
	{ pma_out int 64 regular  }
	{ update_stream_ddr_1_0 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_1 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_2 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_3 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_4 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_5 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_6 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_7 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_8 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_9 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_10 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_11 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_12 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_13 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_14 int 96 regular {fifo 0 volatile }  }
	{ update_stream_ddr_1_15 int 96 regular {fifo 0 volatile }  }
}
set hasAXIMCache 0
set hasAXIML2Cache 0
set AXIMCacheInstDict [dict create]
set C_modelArgMapList {[ 
	{ "Name" : "gmem1", "interface" : "axi_master", "bitwidth" : 512, "direction" : "READONLY", "bitSlice":[ {"cElement": [{"cName": "pma_in1_ddr","offset": { "type": "dynamic","port_name": "pma_in1_ddr","bundle": "control"},"direction": "READONLY"}]}]} , 
 	{ "Name" : "pma_in", "interface" : "wire", "bitwidth" : 64, "direction" : "READONLY"} , 
 	{ "Name" : "gmem3", "interface" : "axi_master", "bitwidth" : 512, "direction" : "WRITEONLY", "bitSlice":[ {"cElement": [{"cName": "pma_out1_ddr","offset": { "type": "dynamic","port_name": "pma_out1_ddr","bundle": "control"},"direction": "WRITEONLY"}]}]} , 
 	{ "Name" : "pma_out", "interface" : "wire", "bitwidth" : 64, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_0", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_1", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_2", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_3", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_4", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_5", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_6", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_7", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_8", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_9", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_10", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_11", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_12", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_13", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_14", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} , 
 	{ "Name" : "update_stream_ddr_1_15", "interface" : "fifo", "bitwidth" : 96, "direction" : "READONLY"} ]}
# RTL Port declarations: 
set portNum 181
set portList { 
	{ ap_clk sc_in sc_logic 1 clock -1 } 
	{ ap_rst sc_in sc_logic 1 reset -1 active_high_sync } 
	{ ap_start sc_in sc_logic 1 start -1 } 
	{ ap_done sc_out sc_logic 1 predone -1 } 
	{ ap_continue sc_in sc_logic 1 continue -1 } 
	{ ap_idle sc_out sc_logic 1 done -1 } 
	{ ap_ready sc_out sc_logic 1 ready -1 } 
	{ m_axi_gmem1_AWVALID sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem1_AWREADY sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem1_AWADDR sc_out sc_lv 64 signal 0 } 
	{ m_axi_gmem1_AWID sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem1_AWLEN sc_out sc_lv 32 signal 0 } 
	{ m_axi_gmem1_AWSIZE sc_out sc_lv 3 signal 0 } 
	{ m_axi_gmem1_AWBURST sc_out sc_lv 2 signal 0 } 
	{ m_axi_gmem1_AWLOCK sc_out sc_lv 2 signal 0 } 
	{ m_axi_gmem1_AWCACHE sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem1_AWPROT sc_out sc_lv 3 signal 0 } 
	{ m_axi_gmem1_AWQOS sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem1_AWREGION sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem1_AWUSER sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem1_WVALID sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem1_WREADY sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem1_WDATA sc_out sc_lv 512 signal 0 } 
	{ m_axi_gmem1_WSTRB sc_out sc_lv 64 signal 0 } 
	{ m_axi_gmem1_WLAST sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem1_WID sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem1_WUSER sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem1_ARVALID sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem1_ARREADY sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem1_ARADDR sc_out sc_lv 64 signal 0 } 
	{ m_axi_gmem1_ARID sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem1_ARLEN sc_out sc_lv 32 signal 0 } 
	{ m_axi_gmem1_ARSIZE sc_out sc_lv 3 signal 0 } 
	{ m_axi_gmem1_ARBURST sc_out sc_lv 2 signal 0 } 
	{ m_axi_gmem1_ARLOCK sc_out sc_lv 2 signal 0 } 
	{ m_axi_gmem1_ARCACHE sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem1_ARPROT sc_out sc_lv 3 signal 0 } 
	{ m_axi_gmem1_ARQOS sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem1_ARREGION sc_out sc_lv 4 signal 0 } 
	{ m_axi_gmem1_ARUSER sc_out sc_lv 1 signal 0 } 
	{ m_axi_gmem1_RVALID sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem1_RREADY sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem1_RDATA sc_in sc_lv 512 signal 0 } 
	{ m_axi_gmem1_RLAST sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem1_RID sc_in sc_lv 1 signal 0 } 
	{ m_axi_gmem1_RFIFONUM sc_in sc_lv 9 signal 0 } 
	{ m_axi_gmem1_RUSER sc_in sc_lv 1 signal 0 } 
	{ m_axi_gmem1_RRESP sc_in sc_lv 2 signal 0 } 
	{ m_axi_gmem1_BVALID sc_in sc_logic 1 signal 0 } 
	{ m_axi_gmem1_BREADY sc_out sc_logic 1 signal 0 } 
	{ m_axi_gmem1_BRESP sc_in sc_lv 2 signal 0 } 
	{ m_axi_gmem1_BID sc_in sc_lv 1 signal 0 } 
	{ m_axi_gmem1_BUSER sc_in sc_lv 1 signal 0 } 
	{ pma_in sc_in sc_lv 64 signal 1 } 
	{ m_axi_gmem3_AWVALID sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem3_AWREADY sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem3_AWADDR sc_out sc_lv 64 signal 2 } 
	{ m_axi_gmem3_AWID sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem3_AWLEN sc_out sc_lv 32 signal 2 } 
	{ m_axi_gmem3_AWSIZE sc_out sc_lv 3 signal 2 } 
	{ m_axi_gmem3_AWBURST sc_out sc_lv 2 signal 2 } 
	{ m_axi_gmem3_AWLOCK sc_out sc_lv 2 signal 2 } 
	{ m_axi_gmem3_AWCACHE sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem3_AWPROT sc_out sc_lv 3 signal 2 } 
	{ m_axi_gmem3_AWQOS sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem3_AWREGION sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem3_AWUSER sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem3_WVALID sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem3_WREADY sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem3_WDATA sc_out sc_lv 512 signal 2 } 
	{ m_axi_gmem3_WSTRB sc_out sc_lv 64 signal 2 } 
	{ m_axi_gmem3_WLAST sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem3_WID sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem3_WUSER sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem3_ARVALID sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem3_ARREADY sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem3_ARADDR sc_out sc_lv 64 signal 2 } 
	{ m_axi_gmem3_ARID sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem3_ARLEN sc_out sc_lv 32 signal 2 } 
	{ m_axi_gmem3_ARSIZE sc_out sc_lv 3 signal 2 } 
	{ m_axi_gmem3_ARBURST sc_out sc_lv 2 signal 2 } 
	{ m_axi_gmem3_ARLOCK sc_out sc_lv 2 signal 2 } 
	{ m_axi_gmem3_ARCACHE sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem3_ARPROT sc_out sc_lv 3 signal 2 } 
	{ m_axi_gmem3_ARQOS sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem3_ARREGION sc_out sc_lv 4 signal 2 } 
	{ m_axi_gmem3_ARUSER sc_out sc_lv 1 signal 2 } 
	{ m_axi_gmem3_RVALID sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem3_RREADY sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem3_RDATA sc_in sc_lv 512 signal 2 } 
	{ m_axi_gmem3_RLAST sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem3_RID sc_in sc_lv 1 signal 2 } 
	{ m_axi_gmem3_RFIFONUM sc_in sc_lv 9 signal 2 } 
	{ m_axi_gmem3_RUSER sc_in sc_lv 1 signal 2 } 
	{ m_axi_gmem3_RRESP sc_in sc_lv 2 signal 2 } 
	{ m_axi_gmem3_BVALID sc_in sc_logic 1 signal 2 } 
	{ m_axi_gmem3_BREADY sc_out sc_logic 1 signal 2 } 
	{ m_axi_gmem3_BRESP sc_in sc_lv 2 signal 2 } 
	{ m_axi_gmem3_BID sc_in sc_lv 1 signal 2 } 
	{ m_axi_gmem3_BUSER sc_in sc_lv 1 signal 2 } 
	{ pma_out sc_in sc_lv 64 signal 3 } 
	{ update_stream_ddr_1_0_dout sc_in sc_lv 96 signal 4 } 
	{ update_stream_ddr_1_0_num_data_valid sc_in sc_lv 3 signal 4 } 
	{ update_stream_ddr_1_0_fifo_cap sc_in sc_lv 3 signal 4 } 
	{ update_stream_ddr_1_0_empty_n sc_in sc_logic 1 signal 4 } 
	{ update_stream_ddr_1_0_read sc_out sc_logic 1 signal 4 } 
	{ update_stream_ddr_1_1_dout sc_in sc_lv 96 signal 5 } 
	{ update_stream_ddr_1_1_num_data_valid sc_in sc_lv 3 signal 5 } 
	{ update_stream_ddr_1_1_fifo_cap sc_in sc_lv 3 signal 5 } 
	{ update_stream_ddr_1_1_empty_n sc_in sc_logic 1 signal 5 } 
	{ update_stream_ddr_1_1_read sc_out sc_logic 1 signal 5 } 
	{ update_stream_ddr_1_2_dout sc_in sc_lv 96 signal 6 } 
	{ update_stream_ddr_1_2_num_data_valid sc_in sc_lv 3 signal 6 } 
	{ update_stream_ddr_1_2_fifo_cap sc_in sc_lv 3 signal 6 } 
	{ update_stream_ddr_1_2_empty_n sc_in sc_logic 1 signal 6 } 
	{ update_stream_ddr_1_2_read sc_out sc_logic 1 signal 6 } 
	{ update_stream_ddr_1_3_dout sc_in sc_lv 96 signal 7 } 
	{ update_stream_ddr_1_3_num_data_valid sc_in sc_lv 3 signal 7 } 
	{ update_stream_ddr_1_3_fifo_cap sc_in sc_lv 3 signal 7 } 
	{ update_stream_ddr_1_3_empty_n sc_in sc_logic 1 signal 7 } 
	{ update_stream_ddr_1_3_read sc_out sc_logic 1 signal 7 } 
	{ update_stream_ddr_1_4_dout sc_in sc_lv 96 signal 8 } 
	{ update_stream_ddr_1_4_num_data_valid sc_in sc_lv 3 signal 8 } 
	{ update_stream_ddr_1_4_fifo_cap sc_in sc_lv 3 signal 8 } 
	{ update_stream_ddr_1_4_empty_n sc_in sc_logic 1 signal 8 } 
	{ update_stream_ddr_1_4_read sc_out sc_logic 1 signal 8 } 
	{ update_stream_ddr_1_5_dout sc_in sc_lv 96 signal 9 } 
	{ update_stream_ddr_1_5_num_data_valid sc_in sc_lv 3 signal 9 } 
	{ update_stream_ddr_1_5_fifo_cap sc_in sc_lv 3 signal 9 } 
	{ update_stream_ddr_1_5_empty_n sc_in sc_logic 1 signal 9 } 
	{ update_stream_ddr_1_5_read sc_out sc_logic 1 signal 9 } 
	{ update_stream_ddr_1_6_dout sc_in sc_lv 96 signal 10 } 
	{ update_stream_ddr_1_6_num_data_valid sc_in sc_lv 3 signal 10 } 
	{ update_stream_ddr_1_6_fifo_cap sc_in sc_lv 3 signal 10 } 
	{ update_stream_ddr_1_6_empty_n sc_in sc_logic 1 signal 10 } 
	{ update_stream_ddr_1_6_read sc_out sc_logic 1 signal 10 } 
	{ update_stream_ddr_1_7_dout sc_in sc_lv 96 signal 11 } 
	{ update_stream_ddr_1_7_num_data_valid sc_in sc_lv 3 signal 11 } 
	{ update_stream_ddr_1_7_fifo_cap sc_in sc_lv 3 signal 11 } 
	{ update_stream_ddr_1_7_empty_n sc_in sc_logic 1 signal 11 } 
	{ update_stream_ddr_1_7_read sc_out sc_logic 1 signal 11 } 
	{ update_stream_ddr_1_8_dout sc_in sc_lv 96 signal 12 } 
	{ update_stream_ddr_1_8_num_data_valid sc_in sc_lv 3 signal 12 } 
	{ update_stream_ddr_1_8_fifo_cap sc_in sc_lv 3 signal 12 } 
	{ update_stream_ddr_1_8_empty_n sc_in sc_logic 1 signal 12 } 
	{ update_stream_ddr_1_8_read sc_out sc_logic 1 signal 12 } 
	{ update_stream_ddr_1_9_dout sc_in sc_lv 96 signal 13 } 
	{ update_stream_ddr_1_9_num_data_valid sc_in sc_lv 3 signal 13 } 
	{ update_stream_ddr_1_9_fifo_cap sc_in sc_lv 3 signal 13 } 
	{ update_stream_ddr_1_9_empty_n sc_in sc_logic 1 signal 13 } 
	{ update_stream_ddr_1_9_read sc_out sc_logic 1 signal 13 } 
	{ update_stream_ddr_1_10_dout sc_in sc_lv 96 signal 14 } 
	{ update_stream_ddr_1_10_num_data_valid sc_in sc_lv 3 signal 14 } 
	{ update_stream_ddr_1_10_fifo_cap sc_in sc_lv 3 signal 14 } 
	{ update_stream_ddr_1_10_empty_n sc_in sc_logic 1 signal 14 } 
	{ update_stream_ddr_1_10_read sc_out sc_logic 1 signal 14 } 
	{ update_stream_ddr_1_11_dout sc_in sc_lv 96 signal 15 } 
	{ update_stream_ddr_1_11_num_data_valid sc_in sc_lv 3 signal 15 } 
	{ update_stream_ddr_1_11_fifo_cap sc_in sc_lv 3 signal 15 } 
	{ update_stream_ddr_1_11_empty_n sc_in sc_logic 1 signal 15 } 
	{ update_stream_ddr_1_11_read sc_out sc_logic 1 signal 15 } 
	{ update_stream_ddr_1_12_dout sc_in sc_lv 96 signal 16 } 
	{ update_stream_ddr_1_12_num_data_valid sc_in sc_lv 3 signal 16 } 
	{ update_stream_ddr_1_12_fifo_cap sc_in sc_lv 3 signal 16 } 
	{ update_stream_ddr_1_12_empty_n sc_in sc_logic 1 signal 16 } 
	{ update_stream_ddr_1_12_read sc_out sc_logic 1 signal 16 } 
	{ update_stream_ddr_1_13_dout sc_in sc_lv 96 signal 17 } 
	{ update_stream_ddr_1_13_num_data_valid sc_in sc_lv 3 signal 17 } 
	{ update_stream_ddr_1_13_fifo_cap sc_in sc_lv 3 signal 17 } 
	{ update_stream_ddr_1_13_empty_n sc_in sc_logic 1 signal 17 } 
	{ update_stream_ddr_1_13_read sc_out sc_logic 1 signal 17 } 
	{ update_stream_ddr_1_14_dout sc_in sc_lv 96 signal 18 } 
	{ update_stream_ddr_1_14_num_data_valid sc_in sc_lv 3 signal 18 } 
	{ update_stream_ddr_1_14_fifo_cap sc_in sc_lv 3 signal 18 } 
	{ update_stream_ddr_1_14_empty_n sc_in sc_logic 1 signal 18 } 
	{ update_stream_ddr_1_14_read sc_out sc_logic 1 signal 18 } 
	{ update_stream_ddr_1_15_dout sc_in sc_lv 96 signal 19 } 
	{ update_stream_ddr_1_15_num_data_valid sc_in sc_lv 3 signal 19 } 
	{ update_stream_ddr_1_15_fifo_cap sc_in sc_lv 3 signal 19 } 
	{ update_stream_ddr_1_15_empty_n sc_in sc_logic 1 signal 19 } 
	{ update_stream_ddr_1_15_read sc_out sc_logic 1 signal 19 } 
}
set NewPortList {[ 
	{ "name": "ap_clk", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "clock", "bundle":{"name": "ap_clk", "role": "default" }} , 
 	{ "name": "ap_rst", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "reset", "bundle":{"name": "ap_rst", "role": "default" }} , 
 	{ "name": "ap_start", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "start", "bundle":{"name": "ap_start", "role": "default" }} , 
 	{ "name": "ap_done", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "predone", "bundle":{"name": "ap_done", "role": "default" }} , 
 	{ "name": "ap_continue", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "continue", "bundle":{"name": "ap_continue", "role": "default" }} , 
 	{ "name": "ap_idle", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "done", "bundle":{"name": "ap_idle", "role": "default" }} , 
 	{ "name": "ap_ready", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "ready", "bundle":{"name": "ap_ready", "role": "default" }} , 
 	{ "name": "m_axi_gmem1_AWVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "AWVALID" }} , 
 	{ "name": "m_axi_gmem1_AWREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "AWREADY" }} , 
 	{ "name": "m_axi_gmem1_AWADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem1", "role": "AWADDR" }} , 
 	{ "name": "m_axi_gmem1_AWID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "AWID" }} , 
 	{ "name": "m_axi_gmem1_AWLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "gmem1", "role": "AWLEN" }} , 
 	{ "name": "m_axi_gmem1_AWSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem1", "role": "AWSIZE" }} , 
 	{ "name": "m_axi_gmem1_AWBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem1", "role": "AWBURST" }} , 
 	{ "name": "m_axi_gmem1_AWLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem1", "role": "AWLOCK" }} , 
 	{ "name": "m_axi_gmem1_AWCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem1", "role": "AWCACHE" }} , 
 	{ "name": "m_axi_gmem1_AWPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem1", "role": "AWPROT" }} , 
 	{ "name": "m_axi_gmem1_AWQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem1", "role": "AWQOS" }} , 
 	{ "name": "m_axi_gmem1_AWREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem1", "role": "AWREGION" }} , 
 	{ "name": "m_axi_gmem1_AWUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "AWUSER" }} , 
 	{ "name": "m_axi_gmem1_WVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "WVALID" }} , 
 	{ "name": "m_axi_gmem1_WREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "WREADY" }} , 
 	{ "name": "m_axi_gmem1_WDATA", "direction": "out", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem1", "role": "WDATA" }} , 
 	{ "name": "m_axi_gmem1_WSTRB", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem1", "role": "WSTRB" }} , 
 	{ "name": "m_axi_gmem1_WLAST", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "WLAST" }} , 
 	{ "name": "m_axi_gmem1_WID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "WID" }} , 
 	{ "name": "m_axi_gmem1_WUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "WUSER" }} , 
 	{ "name": "m_axi_gmem1_ARVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "ARVALID" }} , 
 	{ "name": "m_axi_gmem1_ARREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "ARREADY" }} , 
 	{ "name": "m_axi_gmem1_ARADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem1", "role": "ARADDR" }} , 
 	{ "name": "m_axi_gmem1_ARID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "ARID" }} , 
 	{ "name": "m_axi_gmem1_ARLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "gmem1", "role": "ARLEN" }} , 
 	{ "name": "m_axi_gmem1_ARSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem1", "role": "ARSIZE" }} , 
 	{ "name": "m_axi_gmem1_ARBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem1", "role": "ARBURST" }} , 
 	{ "name": "m_axi_gmem1_ARLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem1", "role": "ARLOCK" }} , 
 	{ "name": "m_axi_gmem1_ARCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem1", "role": "ARCACHE" }} , 
 	{ "name": "m_axi_gmem1_ARPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem1", "role": "ARPROT" }} , 
 	{ "name": "m_axi_gmem1_ARQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem1", "role": "ARQOS" }} , 
 	{ "name": "m_axi_gmem1_ARREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem1", "role": "ARREGION" }} , 
 	{ "name": "m_axi_gmem1_ARUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "ARUSER" }} , 
 	{ "name": "m_axi_gmem1_RVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "RVALID" }} , 
 	{ "name": "m_axi_gmem1_RREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "RREADY" }} , 
 	{ "name": "m_axi_gmem1_RDATA", "direction": "in", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem1", "role": "RDATA" }} , 
 	{ "name": "m_axi_gmem1_RLAST", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "RLAST" }} , 
 	{ "name": "m_axi_gmem1_RID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "RID" }} , 
 	{ "name": "m_axi_gmem1_RFIFONUM", "direction": "in", "datatype": "sc_lv", "bitwidth":9, "type": "signal", "bundle":{"name": "gmem1", "role": "RFIFONUM" }} , 
 	{ "name": "m_axi_gmem1_RUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "RUSER" }} , 
 	{ "name": "m_axi_gmem1_RRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem1", "role": "RRESP" }} , 
 	{ "name": "m_axi_gmem1_BVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "BVALID" }} , 
 	{ "name": "m_axi_gmem1_BREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "BREADY" }} , 
 	{ "name": "m_axi_gmem1_BRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem1", "role": "BRESP" }} , 
 	{ "name": "m_axi_gmem1_BID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "BID" }} , 
 	{ "name": "m_axi_gmem1_BUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem1", "role": "BUSER" }} , 
 	{ "name": "pma_in", "direction": "in", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "pma_in", "role": "default" }} , 
 	{ "name": "m_axi_gmem3_AWVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "AWVALID" }} , 
 	{ "name": "m_axi_gmem3_AWREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "AWREADY" }} , 
 	{ "name": "m_axi_gmem3_AWADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem3", "role": "AWADDR" }} , 
 	{ "name": "m_axi_gmem3_AWID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "AWID" }} , 
 	{ "name": "m_axi_gmem3_AWLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "gmem3", "role": "AWLEN" }} , 
 	{ "name": "m_axi_gmem3_AWSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem3", "role": "AWSIZE" }} , 
 	{ "name": "m_axi_gmem3_AWBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem3", "role": "AWBURST" }} , 
 	{ "name": "m_axi_gmem3_AWLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem3", "role": "AWLOCK" }} , 
 	{ "name": "m_axi_gmem3_AWCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem3", "role": "AWCACHE" }} , 
 	{ "name": "m_axi_gmem3_AWPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem3", "role": "AWPROT" }} , 
 	{ "name": "m_axi_gmem3_AWQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem3", "role": "AWQOS" }} , 
 	{ "name": "m_axi_gmem3_AWREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem3", "role": "AWREGION" }} , 
 	{ "name": "m_axi_gmem3_AWUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "AWUSER" }} , 
 	{ "name": "m_axi_gmem3_WVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "WVALID" }} , 
 	{ "name": "m_axi_gmem3_WREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "WREADY" }} , 
 	{ "name": "m_axi_gmem3_WDATA", "direction": "out", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem3", "role": "WDATA" }} , 
 	{ "name": "m_axi_gmem3_WSTRB", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem3", "role": "WSTRB" }} , 
 	{ "name": "m_axi_gmem3_WLAST", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "WLAST" }} , 
 	{ "name": "m_axi_gmem3_WID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "WID" }} , 
 	{ "name": "m_axi_gmem3_WUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "WUSER" }} , 
 	{ "name": "m_axi_gmem3_ARVALID", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "ARVALID" }} , 
 	{ "name": "m_axi_gmem3_ARREADY", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "ARREADY" }} , 
 	{ "name": "m_axi_gmem3_ARADDR", "direction": "out", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "gmem3", "role": "ARADDR" }} , 
 	{ "name": "m_axi_gmem3_ARID", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "ARID" }} , 
 	{ "name": "m_axi_gmem3_ARLEN", "direction": "out", "datatype": "sc_lv", "bitwidth":32, "type": "signal", "bundle":{"name": "gmem3", "role": "ARLEN" }} , 
 	{ "name": "m_axi_gmem3_ARSIZE", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem3", "role": "ARSIZE" }} , 
 	{ "name": "m_axi_gmem3_ARBURST", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem3", "role": "ARBURST" }} , 
 	{ "name": "m_axi_gmem3_ARLOCK", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem3", "role": "ARLOCK" }} , 
 	{ "name": "m_axi_gmem3_ARCACHE", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem3", "role": "ARCACHE" }} , 
 	{ "name": "m_axi_gmem3_ARPROT", "direction": "out", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "gmem3", "role": "ARPROT" }} , 
 	{ "name": "m_axi_gmem3_ARQOS", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem3", "role": "ARQOS" }} , 
 	{ "name": "m_axi_gmem3_ARREGION", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "gmem3", "role": "ARREGION" }} , 
 	{ "name": "m_axi_gmem3_ARUSER", "direction": "out", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "ARUSER" }} , 
 	{ "name": "m_axi_gmem3_RVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "RVALID" }} , 
 	{ "name": "m_axi_gmem3_RREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "RREADY" }} , 
 	{ "name": "m_axi_gmem3_RDATA", "direction": "in", "datatype": "sc_lv", "bitwidth":512, "type": "signal", "bundle":{"name": "gmem3", "role": "RDATA" }} , 
 	{ "name": "m_axi_gmem3_RLAST", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "RLAST" }} , 
 	{ "name": "m_axi_gmem3_RID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "RID" }} , 
 	{ "name": "m_axi_gmem3_RFIFONUM", "direction": "in", "datatype": "sc_lv", "bitwidth":9, "type": "signal", "bundle":{"name": "gmem3", "role": "RFIFONUM" }} , 
 	{ "name": "m_axi_gmem3_RUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "RUSER" }} , 
 	{ "name": "m_axi_gmem3_RRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem3", "role": "RRESP" }} , 
 	{ "name": "m_axi_gmem3_BVALID", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "BVALID" }} , 
 	{ "name": "m_axi_gmem3_BREADY", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "BREADY" }} , 
 	{ "name": "m_axi_gmem3_BRESP", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "gmem3", "role": "BRESP" }} , 
 	{ "name": "m_axi_gmem3_BID", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "BID" }} , 
 	{ "name": "m_axi_gmem3_BUSER", "direction": "in", "datatype": "sc_lv", "bitwidth":1, "type": "signal", "bundle":{"name": "gmem3", "role": "BUSER" }} , 
 	{ "name": "pma_out", "direction": "in", "datatype": "sc_lv", "bitwidth":64, "type": "signal", "bundle":{"name": "pma_out", "role": "default" }} , 
 	{ "name": "update_stream_ddr_1_0_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_0", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_0_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_0", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_0_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_0", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_0_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_0", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_0_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_0", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_1_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_1", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_1_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_1", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_1_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_1", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_1_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_1", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_1_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_1", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_2_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_2", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_2_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_2", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_2_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_2", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_2_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_2", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_2_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_2", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_3_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_3", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_3_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_3", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_3_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_3", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_3_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_3", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_3_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_3", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_4_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_4", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_4_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_4", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_4_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_4", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_4_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_4", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_4_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_4", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_5_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_5", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_5_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_5", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_5_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_5", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_5_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_5", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_5_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_5", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_6_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_6", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_6_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_6", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_6_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_6", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_6_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_6", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_6_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_6", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_7_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_7", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_7_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_7", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_7_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_7", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_7_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_7", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_7_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_7", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_8_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_8", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_8_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_8", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_8_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_8", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_8_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_8", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_8_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_8", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_9_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_9", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_9_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_9", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_9_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_9", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_9_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_9", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_9_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_9", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_10_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_10", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_10_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_10", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_10_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_10", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_10_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_10", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_10_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_10", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_11_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_11", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_11_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_11", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_11_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_11", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_11_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_11", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_11_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_11", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_12_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_12", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_12_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_12", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_12_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_12", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_12_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_12", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_12_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_12", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_13_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_13", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_13_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_13", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_13_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_13", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_13_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_13", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_13_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_13", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_14_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_14", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_14_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_14", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_14_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_14", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_14_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_14", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_14_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_14", "role": "read" }} , 
 	{ "name": "update_stream_ddr_1_15_dout", "direction": "in", "datatype": "sc_lv", "bitwidth":96, "type": "signal", "bundle":{"name": "update_stream_ddr_1_15", "role": "dout" }} , 
 	{ "name": "update_stream_ddr_1_15_num_data_valid", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_15", "role": "num_data_valid" }} , 
 	{ "name": "update_stream_ddr_1_15_fifo_cap", "direction": "in", "datatype": "sc_lv", "bitwidth":3, "type": "signal", "bundle":{"name": "update_stream_ddr_1_15", "role": "fifo_cap" }} , 
 	{ "name": "update_stream_ddr_1_15_empty_n", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_15", "role": "empty_n" }} , 
 	{ "name": "update_stream_ddr_1_15_read", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "signal", "bundle":{"name": "update_stream_ddr_1_15", "role": "read" }}  ]}

set RtlHierarchyInfo {[
	{"ID" : "0", "Level" : "0", "Path" : "`AUTOTB_DUT_INST", "Parent" : "", "Child" : ["1"],
		"CDFG" : "process_1",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "1", "ap_idle" : "1", "real_start" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "0",
		"VariableLatency" : "1", "ExactLatency" : "-1", "EstimateLatencyMin" : "-1", "EstimateLatencyMax" : "-1",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "1",
		"HasNonBlockingOperation" : "0",
		"IsBlackBox" : "0",
		"Port" : [
			{"Name" : "gmem1", "Type" : "MAXI", "Direction" : "I",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "gmem1", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "pma_in", "Type" : "None", "Direction" : "I"},
			{"Name" : "gmem3", "Type" : "MAXI", "Direction" : "O",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "gmem3", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "pma_out", "Type" : "None", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_0", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_0", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_1", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_1", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_2", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_2", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_3", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_3", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_4", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_4", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_5", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_5", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_6", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_6", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_7", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_7", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_8", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_8", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_9", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_9", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_10", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_10", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_11", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_11", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_12", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_12", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_13", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_13", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_14", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_14", "Inst_start_state" : "2", "Inst_end_state" : "3"}]},
			{"Name" : "update_stream_ddr_1_15", "Type" : "Fifo", "Direction" : "I", "DependentProc" : ["0"], "DependentChan" : "0", "DependentChanDepth" : "2", "DependentChanType" : "0",
				"SubConnect" : [
					{"ID" : "1", "SubInstance" : "grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Port" : "update_stream_ddr_1_15", "Inst_start_state" : "2", "Inst_end_state" : "3"}]}],
		"Loop" : [
			{"Name" : "process_ddr_loop", "PipelineType" : "no",
				"LoopDec" : {"FSMBitwidth" : "4", "FirstState" : "ap_ST_fsm_state2", "LastState" : ["ap_ST_fsm_state4"], "QuitState" : ["ap_ST_fsm_state2"], "PreState" : ["ap_ST_fsm_state1"], "PostState" : ["ap_ST_fsm_state1"], "OneDepthLoop" : "0", "OneStateBlock": ""}}]},
	{"ID" : "1", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.grp_process_1_Pipeline_process_ddr_sub_loop_fu_108", "Parent" : "0", "Child" : ["2", "3"],
		"CDFG" : "process_1_Pipeline_process_ddr_sub_loop",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "0", "ap_idle" : "1", "real_start" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "0",
		"VariableLatency" : "1", "ExactLatency" : "-1", "EstimateLatencyMin" : "162", "EstimateLatencyMax" : "162",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "1",
		"IsBlackBox" : "0",
		"Port" : [
			{"Name" : "finish_r", "Type" : "None", "Direction" : "I"},
			{"Name" : "info", "Type" : "None", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_0", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_1", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_2", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_3", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_4", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_5", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_6", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_7", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_8", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_9", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_10", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_11", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_12", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_13", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_14", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "update_stream_ddr_1_15", "Type" : "Fifo", "Direction" : "I"},
			{"Name" : "pma_in", "Type" : "None", "Direction" : "I"},
			{"Name" : "gmem1", "Type" : "MAXI", "Direction" : "I",
				"BlockSignal" : [
					{"Name" : "gmem1_blk_n_AR", "Type" : "RtlSignal"},
					{"Name" : "gmem1_blk_n_R", "Type" : "RtlSignal"}]},
			{"Name" : "pma_out", "Type" : "None", "Direction" : "I"},
			{"Name" : "gmem3", "Type" : "MAXI", "Direction" : "O",
				"BlockSignal" : [
					{"Name" : "gmem3_blk_n_AW", "Type" : "RtlSignal"},
					{"Name" : "gmem3_blk_n_W", "Type" : "RtlSignal"},
					{"Name" : "gmem3_blk_n_B", "Type" : "RtlSignal"}]},
			{"Name" : "finish_1_out", "Type" : "Vld", "Direction" : "O"},
			{"Name" : "info_1_out", "Type" : "Vld", "Direction" : "O"}],
		"Loop" : [
			{"Name" : "process_ddr_sub_loop", "PipelineType" : "UPC",
				"LoopDec" : {"FSMBitwidth" : "1", "FirstState" : "ap_ST_fsm_pp0_stage0", "FirstStateIter" : "ap_enable_reg_pp0_iter0", "FirstStateBlock" : "ap_block_pp0_stage0_subdone", "LastState" : "ap_ST_fsm_pp0_stage0", "LastStateIter" : "ap_enable_reg_pp0_iter145", "LastStateBlock" : "ap_block_pp0_stage0_subdone", "QuitState" : "ap_ST_fsm_pp0_stage0", "QuitStateIter" : "ap_enable_reg_pp0_iter145", "QuitStateBlock" : "ap_block_pp0_stage0_subdone", "OneDepthLoop" : "0", "has_ap_ctrl" : "1", "has_continue" : "0"}}]},
	{"ID" : "2", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_process_1_Pipeline_process_ddr_sub_loop_fu_108.sparsemux_7_2_512_1_1_U123", "Parent" : "1"},
	{"ID" : "3", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_process_1_Pipeline_process_ddr_sub_loop_fu_108.flow_control_loop_pipe_sequential_init_U", "Parent" : "1"}]}


set ArgLastReadFirstWriteLatency {
	process_1 {
		gmem1 {Type I LastRead 73 FirstWrite -1}
		pma_in {Type I LastRead 0 FirstWrite -1}
		gmem3 {Type O LastRead 78 FirstWrite 77}
		pma_out {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_0 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_1 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_2 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_3 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_4 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_5 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_6 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_7 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_8 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_9 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_10 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_11 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_12 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_13 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_14 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_15 {Type I LastRead 0 FirstWrite -1}}
	process_1_Pipeline_process_ddr_sub_loop {
		finish_r {Type I LastRead 0 FirstWrite -1}
		info {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_0 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_1 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_2 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_3 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_4 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_5 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_6 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_7 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_8 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_9 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_10 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_11 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_12 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_13 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_14 {Type I LastRead 0 FirstWrite -1}
		update_stream_ddr_1_15 {Type I LastRead 0 FirstWrite -1}
		pma_in {Type I LastRead 0 FirstWrite -1}
		gmem1 {Type I LastRead 73 FirstWrite -1}
		pma_out {Type I LastRead 0 FirstWrite -1}
		gmem3 {Type O LastRead 78 FirstWrite 77}
		finish_1_out {Type O LastRead -1 FirstWrite 144}
		info_1_out {Type O LastRead -1 FirstWrite 144}}}

set hasDtUnsupportedChannel 0

set PerformanceInfo {[
	{"Name" : "Latency", "Min" : "-1", "Max" : "-1"}
	, {"Name" : "Interval", "Min" : "-1", "Max" : "-1"}
]}

set PipelineEnableSignalInfo {[
]}

set Spec2ImplPortList { 
	 { m_axi {  { m_axi_gmem1_AWVALID VALID 1 1 }  { m_axi_gmem1_AWREADY READY 0 1 }  { m_axi_gmem1_AWADDR ADDR 1 64 }  { m_axi_gmem1_AWID ID 1 1 }  { m_axi_gmem1_AWLEN SIZE 1 32 }  { m_axi_gmem1_AWSIZE BURST 1 3 }  { m_axi_gmem1_AWBURST LOCK 1 2 }  { m_axi_gmem1_AWLOCK CACHE 1 2 }  { m_axi_gmem1_AWCACHE PROT 1 4 }  { m_axi_gmem1_AWPROT QOS 1 3 }  { m_axi_gmem1_AWQOS REGION 1 4 }  { m_axi_gmem1_AWREGION USER 1 4 }  { m_axi_gmem1_AWUSER DATA 1 1 }  { m_axi_gmem1_WVALID VALID 1 1 }  { m_axi_gmem1_WREADY READY 0 1 }  { m_axi_gmem1_WDATA FIFONUM 1 512 }  { m_axi_gmem1_WSTRB STRB 1 64 }  { m_axi_gmem1_WLAST LAST 1 1 }  { m_axi_gmem1_WID ID 1 1 }  { m_axi_gmem1_WUSER DATA 1 1 }  { m_axi_gmem1_ARVALID VALID 1 1 }  { m_axi_gmem1_ARREADY READY 0 1 }  { m_axi_gmem1_ARADDR ADDR 1 64 }  { m_axi_gmem1_ARID ID 1 1 }  { m_axi_gmem1_ARLEN SIZE 1 32 }  { m_axi_gmem1_ARSIZE BURST 1 3 }  { m_axi_gmem1_ARBURST LOCK 1 2 }  { m_axi_gmem1_ARLOCK CACHE 1 2 }  { m_axi_gmem1_ARCACHE PROT 1 4 }  { m_axi_gmem1_ARPROT QOS 1 3 }  { m_axi_gmem1_ARQOS REGION 1 4 }  { m_axi_gmem1_ARREGION USER 1 4 }  { m_axi_gmem1_ARUSER DATA 1 1 }  { m_axi_gmem1_RVALID VALID 0 1 }  { m_axi_gmem1_RREADY READY 1 1 }  { m_axi_gmem1_RDATA FIFONUM 0 512 }  { m_axi_gmem1_RLAST LAST 0 1 }  { m_axi_gmem1_RID ID 0 1 }  { m_axi_gmem1_RFIFONUM LEN 0 9 }  { m_axi_gmem1_RUSER DATA 0 1 }  { m_axi_gmem1_RRESP RESP 0 2 }  { m_axi_gmem1_BVALID VALID 0 1 }  { m_axi_gmem1_BREADY READY 1 1 }  { m_axi_gmem1_BRESP RESP 0 2 }  { m_axi_gmem1_BID ID 0 1 }  { m_axi_gmem1_BUSER DATA 0 1 } } }
	pma_in { ap_none {  { pma_in in_data 0 64 } } }
	 { m_axi {  { m_axi_gmem3_AWVALID VALID 1 1 }  { m_axi_gmem3_AWREADY READY 0 1 }  { m_axi_gmem3_AWADDR ADDR 1 64 }  { m_axi_gmem3_AWID ID 1 1 }  { m_axi_gmem3_AWLEN SIZE 1 32 }  { m_axi_gmem3_AWSIZE BURST 1 3 }  { m_axi_gmem3_AWBURST LOCK 1 2 }  { m_axi_gmem3_AWLOCK CACHE 1 2 }  { m_axi_gmem3_AWCACHE PROT 1 4 }  { m_axi_gmem3_AWPROT QOS 1 3 }  { m_axi_gmem3_AWQOS REGION 1 4 }  { m_axi_gmem3_AWREGION USER 1 4 }  { m_axi_gmem3_AWUSER DATA 1 1 }  { m_axi_gmem3_WVALID VALID 1 1 }  { m_axi_gmem3_WREADY READY 0 1 }  { m_axi_gmem3_WDATA FIFONUM 1 512 }  { m_axi_gmem3_WSTRB STRB 1 64 }  { m_axi_gmem3_WLAST LAST 1 1 }  { m_axi_gmem3_WID ID 1 1 }  { m_axi_gmem3_WUSER DATA 1 1 }  { m_axi_gmem3_ARVALID VALID 1 1 }  { m_axi_gmem3_ARREADY READY 0 1 }  { m_axi_gmem3_ARADDR ADDR 1 64 }  { m_axi_gmem3_ARID ID 1 1 }  { m_axi_gmem3_ARLEN SIZE 1 32 }  { m_axi_gmem3_ARSIZE BURST 1 3 }  { m_axi_gmem3_ARBURST LOCK 1 2 }  { m_axi_gmem3_ARLOCK CACHE 1 2 }  { m_axi_gmem3_ARCACHE PROT 1 4 }  { m_axi_gmem3_ARPROT QOS 1 3 }  { m_axi_gmem3_ARQOS REGION 1 4 }  { m_axi_gmem3_ARREGION USER 1 4 }  { m_axi_gmem3_ARUSER DATA 1 1 }  { m_axi_gmem3_RVALID VALID 0 1 }  { m_axi_gmem3_RREADY READY 1 1 }  { m_axi_gmem3_RDATA FIFONUM 0 512 }  { m_axi_gmem3_RLAST LAST 0 1 }  { m_axi_gmem3_RID ID 0 1 }  { m_axi_gmem3_RFIFONUM LEN 0 9 }  { m_axi_gmem3_RUSER DATA 0 1 }  { m_axi_gmem3_RRESP RESP 0 2 }  { m_axi_gmem3_BVALID VALID 0 1 }  { m_axi_gmem3_BREADY READY 1 1 }  { m_axi_gmem3_BRESP RESP 0 2 }  { m_axi_gmem3_BID ID 0 1 }  { m_axi_gmem3_BUSER DATA 0 1 } } }
	pma_out { ap_none {  { pma_out in_data 0 64 } } }
	update_stream_ddr_1_0 { ap_fifo {  { update_stream_ddr_1_0_dout fifo_data_in 0 96 }  { update_stream_ddr_1_0_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_0_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_0_empty_n fifo_status 0 1 }  { update_stream_ddr_1_0_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_1 { ap_fifo {  { update_stream_ddr_1_1_dout fifo_data_in 0 96 }  { update_stream_ddr_1_1_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_1_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_1_empty_n fifo_status 0 1 }  { update_stream_ddr_1_1_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_2 { ap_fifo {  { update_stream_ddr_1_2_dout fifo_data_in 0 96 }  { update_stream_ddr_1_2_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_2_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_2_empty_n fifo_status 0 1 }  { update_stream_ddr_1_2_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_3 { ap_fifo {  { update_stream_ddr_1_3_dout fifo_data_in 0 96 }  { update_stream_ddr_1_3_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_3_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_3_empty_n fifo_status 0 1 }  { update_stream_ddr_1_3_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_4 { ap_fifo {  { update_stream_ddr_1_4_dout fifo_data_in 0 96 }  { update_stream_ddr_1_4_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_4_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_4_empty_n fifo_status 0 1 }  { update_stream_ddr_1_4_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_5 { ap_fifo {  { update_stream_ddr_1_5_dout fifo_data_in 0 96 }  { update_stream_ddr_1_5_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_5_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_5_empty_n fifo_status 0 1 }  { update_stream_ddr_1_5_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_6 { ap_fifo {  { update_stream_ddr_1_6_dout fifo_data_in 0 96 }  { update_stream_ddr_1_6_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_6_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_6_empty_n fifo_status 0 1 }  { update_stream_ddr_1_6_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_7 { ap_fifo {  { update_stream_ddr_1_7_dout fifo_data_in 0 96 }  { update_stream_ddr_1_7_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_7_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_7_empty_n fifo_status 0 1 }  { update_stream_ddr_1_7_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_8 { ap_fifo {  { update_stream_ddr_1_8_dout fifo_data_in 0 96 }  { update_stream_ddr_1_8_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_8_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_8_empty_n fifo_status 0 1 }  { update_stream_ddr_1_8_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_9 { ap_fifo {  { update_stream_ddr_1_9_dout fifo_data_in 0 96 }  { update_stream_ddr_1_9_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_9_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_9_empty_n fifo_status 0 1 }  { update_stream_ddr_1_9_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_10 { ap_fifo {  { update_stream_ddr_1_10_dout fifo_data_in 0 96 }  { update_stream_ddr_1_10_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_10_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_10_empty_n fifo_status 0 1 }  { update_stream_ddr_1_10_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_11 { ap_fifo {  { update_stream_ddr_1_11_dout fifo_data_in 0 96 }  { update_stream_ddr_1_11_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_11_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_11_empty_n fifo_status 0 1 }  { update_stream_ddr_1_11_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_12 { ap_fifo {  { update_stream_ddr_1_12_dout fifo_data_in 0 96 }  { update_stream_ddr_1_12_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_12_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_12_empty_n fifo_status 0 1 }  { update_stream_ddr_1_12_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_13 { ap_fifo {  { update_stream_ddr_1_13_dout fifo_data_in 0 96 }  { update_stream_ddr_1_13_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_13_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_13_empty_n fifo_status 0 1 }  { update_stream_ddr_1_13_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_14 { ap_fifo {  { update_stream_ddr_1_14_dout fifo_data_in 0 96 }  { update_stream_ddr_1_14_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_14_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_14_empty_n fifo_status 0 1 }  { update_stream_ddr_1_14_read fifo_port_we 1 1 } } }
	update_stream_ddr_1_15 { ap_fifo {  { update_stream_ddr_1_15_dout fifo_data_in 0 96 }  { update_stream_ddr_1_15_num_data_valid fifo_status_num_data_valid 0 3 }  { update_stream_ddr_1_15_fifo_cap fifo_update 0 3 }  { update_stream_ddr_1_15_empty_n fifo_status 0 1 }  { update_stream_ddr_1_15_read fifo_port_we 1 1 } } }
}
