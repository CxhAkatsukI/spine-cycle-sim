open_project project
set_top process_ddr
add_files {/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/grasu_ddr_rtl_preflight_v1/hls/source/kernel_process_ddr.cpp} -cflags {-I/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3/results/upstream_stage_controls/grasu_ddr_rtl_preflight_v1/hls/source -I/data/yxx/tools/xilinx/Vitis_HLS/2024.1/include/etc}
open_solution -flow_target vitis solution
set_part {xcu250-figd2104-2L-e}
create_clock -period 5 -name default
csynth_design
exit
