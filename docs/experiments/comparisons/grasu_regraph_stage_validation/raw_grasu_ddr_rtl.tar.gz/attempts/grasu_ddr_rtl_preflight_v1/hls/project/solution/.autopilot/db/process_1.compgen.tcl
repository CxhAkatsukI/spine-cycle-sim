# This script segment is generated automatically by AutoPilot

# clear list
if {${::AESL::PGuard_autoexp_gen}} {
    cg_default_interface_gen_dc_begin
    cg_default_interface_gen_bundle_begin
    AESL_LIB_XILADAPTER::native_axis_begin
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 148 \
    name gmem1 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_gmem1 \
    op interface \
    ports { m_axi_gmem1_AWVALID { O 1 bit } m_axi_gmem1_AWREADY { I 1 bit } m_axi_gmem1_AWADDR { O 64 vector } m_axi_gmem1_AWID { O 1 vector } m_axi_gmem1_AWLEN { O 32 vector } m_axi_gmem1_AWSIZE { O 3 vector } m_axi_gmem1_AWBURST { O 2 vector } m_axi_gmem1_AWLOCK { O 2 vector } m_axi_gmem1_AWCACHE { O 4 vector } m_axi_gmem1_AWPROT { O 3 vector } m_axi_gmem1_AWQOS { O 4 vector } m_axi_gmem1_AWREGION { O 4 vector } m_axi_gmem1_AWUSER { O 1 vector } m_axi_gmem1_WVALID { O 1 bit } m_axi_gmem1_WREADY { I 1 bit } m_axi_gmem1_WDATA { O 512 vector } m_axi_gmem1_WSTRB { O 64 vector } m_axi_gmem1_WLAST { O 1 bit } m_axi_gmem1_WID { O 1 vector } m_axi_gmem1_WUSER { O 1 vector } m_axi_gmem1_ARVALID { O 1 bit } m_axi_gmem1_ARREADY { I 1 bit } m_axi_gmem1_ARADDR { O 64 vector } m_axi_gmem1_ARID { O 1 vector } m_axi_gmem1_ARLEN { O 32 vector } m_axi_gmem1_ARSIZE { O 3 vector } m_axi_gmem1_ARBURST { O 2 vector } m_axi_gmem1_ARLOCK { O 2 vector } m_axi_gmem1_ARCACHE { O 4 vector } m_axi_gmem1_ARPROT { O 3 vector } m_axi_gmem1_ARQOS { O 4 vector } m_axi_gmem1_ARREGION { O 4 vector } m_axi_gmem1_ARUSER { O 1 vector } m_axi_gmem1_RVALID { I 1 bit } m_axi_gmem1_RREADY { O 1 bit } m_axi_gmem1_RDATA { I 512 vector } m_axi_gmem1_RLAST { I 1 bit } m_axi_gmem1_RID { I 1 vector } m_axi_gmem1_RFIFONUM { I 9 vector } m_axi_gmem1_RUSER { I 1 vector } m_axi_gmem1_RRESP { I 2 vector } m_axi_gmem1_BVALID { I 1 bit } m_axi_gmem1_BREADY { O 1 bit } m_axi_gmem1_BRESP { I 2 vector } m_axi_gmem1_BID { I 1 vector } m_axi_gmem1_BUSER { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 149 \
    name pma_in \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_pma_in \
    op interface \
    ports { pma_in { I 64 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 150 \
    name gmem3 \
    type other \
    dir O \
    reset_level 1 \
    sync_rst true \
    corename dc_gmem3 \
    op interface \
    ports { m_axi_gmem3_AWVALID { O 1 bit } m_axi_gmem3_AWREADY { I 1 bit } m_axi_gmem3_AWADDR { O 64 vector } m_axi_gmem3_AWID { O 1 vector } m_axi_gmem3_AWLEN { O 32 vector } m_axi_gmem3_AWSIZE { O 3 vector } m_axi_gmem3_AWBURST { O 2 vector } m_axi_gmem3_AWLOCK { O 2 vector } m_axi_gmem3_AWCACHE { O 4 vector } m_axi_gmem3_AWPROT { O 3 vector } m_axi_gmem3_AWQOS { O 4 vector } m_axi_gmem3_AWREGION { O 4 vector } m_axi_gmem3_AWUSER { O 1 vector } m_axi_gmem3_WVALID { O 1 bit } m_axi_gmem3_WREADY { I 1 bit } m_axi_gmem3_WDATA { O 512 vector } m_axi_gmem3_WSTRB { O 64 vector } m_axi_gmem3_WLAST { O 1 bit } m_axi_gmem3_WID { O 1 vector } m_axi_gmem3_WUSER { O 1 vector } m_axi_gmem3_ARVALID { O 1 bit } m_axi_gmem3_ARREADY { I 1 bit } m_axi_gmem3_ARADDR { O 64 vector } m_axi_gmem3_ARID { O 1 vector } m_axi_gmem3_ARLEN { O 32 vector } m_axi_gmem3_ARSIZE { O 3 vector } m_axi_gmem3_ARBURST { O 2 vector } m_axi_gmem3_ARLOCK { O 2 vector } m_axi_gmem3_ARCACHE { O 4 vector } m_axi_gmem3_ARPROT { O 3 vector } m_axi_gmem3_ARQOS { O 4 vector } m_axi_gmem3_ARREGION { O 4 vector } m_axi_gmem3_ARUSER { O 1 vector } m_axi_gmem3_RVALID { I 1 bit } m_axi_gmem3_RREADY { O 1 bit } m_axi_gmem3_RDATA { I 512 vector } m_axi_gmem3_RLAST { I 1 bit } m_axi_gmem3_RID { I 1 vector } m_axi_gmem3_RFIFONUM { I 9 vector } m_axi_gmem3_RUSER { I 1 vector } m_axi_gmem3_RRESP { I 2 vector } m_axi_gmem3_BVALID { I 1 bit } m_axi_gmem3_BREADY { O 1 bit } m_axi_gmem3_BRESP { I 2 vector } m_axi_gmem3_BID { I 1 vector } m_axi_gmem3_BUSER { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 151 \
    name pma_out \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_pma_out \
    op interface \
    ports { pma_out { I 64 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 152 \
    name update_stream_ddr_1_0 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_0 \
    op interface \
    ports { update_stream_ddr_1_0_dout { I 96 vector } update_stream_ddr_1_0_num_data_valid { I 3 vector } update_stream_ddr_1_0_fifo_cap { I 3 vector } update_stream_ddr_1_0_empty_n { I 1 bit } update_stream_ddr_1_0_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 153 \
    name update_stream_ddr_1_1 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_1 \
    op interface \
    ports { update_stream_ddr_1_1_dout { I 96 vector } update_stream_ddr_1_1_num_data_valid { I 3 vector } update_stream_ddr_1_1_fifo_cap { I 3 vector } update_stream_ddr_1_1_empty_n { I 1 bit } update_stream_ddr_1_1_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 154 \
    name update_stream_ddr_1_2 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_2 \
    op interface \
    ports { update_stream_ddr_1_2_dout { I 96 vector } update_stream_ddr_1_2_num_data_valid { I 3 vector } update_stream_ddr_1_2_fifo_cap { I 3 vector } update_stream_ddr_1_2_empty_n { I 1 bit } update_stream_ddr_1_2_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 155 \
    name update_stream_ddr_1_3 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_3 \
    op interface \
    ports { update_stream_ddr_1_3_dout { I 96 vector } update_stream_ddr_1_3_num_data_valid { I 3 vector } update_stream_ddr_1_3_fifo_cap { I 3 vector } update_stream_ddr_1_3_empty_n { I 1 bit } update_stream_ddr_1_3_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 156 \
    name update_stream_ddr_1_4 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_4 \
    op interface \
    ports { update_stream_ddr_1_4_dout { I 96 vector } update_stream_ddr_1_4_num_data_valid { I 3 vector } update_stream_ddr_1_4_fifo_cap { I 3 vector } update_stream_ddr_1_4_empty_n { I 1 bit } update_stream_ddr_1_4_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 157 \
    name update_stream_ddr_1_5 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_5 \
    op interface \
    ports { update_stream_ddr_1_5_dout { I 96 vector } update_stream_ddr_1_5_num_data_valid { I 3 vector } update_stream_ddr_1_5_fifo_cap { I 3 vector } update_stream_ddr_1_5_empty_n { I 1 bit } update_stream_ddr_1_5_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 158 \
    name update_stream_ddr_1_6 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_6 \
    op interface \
    ports { update_stream_ddr_1_6_dout { I 96 vector } update_stream_ddr_1_6_num_data_valid { I 3 vector } update_stream_ddr_1_6_fifo_cap { I 3 vector } update_stream_ddr_1_6_empty_n { I 1 bit } update_stream_ddr_1_6_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 159 \
    name update_stream_ddr_1_7 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_7 \
    op interface \
    ports { update_stream_ddr_1_7_dout { I 96 vector } update_stream_ddr_1_7_num_data_valid { I 3 vector } update_stream_ddr_1_7_fifo_cap { I 3 vector } update_stream_ddr_1_7_empty_n { I 1 bit } update_stream_ddr_1_7_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 160 \
    name update_stream_ddr_1_8 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_8 \
    op interface \
    ports { update_stream_ddr_1_8_dout { I 96 vector } update_stream_ddr_1_8_num_data_valid { I 3 vector } update_stream_ddr_1_8_fifo_cap { I 3 vector } update_stream_ddr_1_8_empty_n { I 1 bit } update_stream_ddr_1_8_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 161 \
    name update_stream_ddr_1_9 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_9 \
    op interface \
    ports { update_stream_ddr_1_9_dout { I 96 vector } update_stream_ddr_1_9_num_data_valid { I 3 vector } update_stream_ddr_1_9_fifo_cap { I 3 vector } update_stream_ddr_1_9_empty_n { I 1 bit } update_stream_ddr_1_9_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 162 \
    name update_stream_ddr_1_10 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_10 \
    op interface \
    ports { update_stream_ddr_1_10_dout { I 96 vector } update_stream_ddr_1_10_num_data_valid { I 3 vector } update_stream_ddr_1_10_fifo_cap { I 3 vector } update_stream_ddr_1_10_empty_n { I 1 bit } update_stream_ddr_1_10_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 163 \
    name update_stream_ddr_1_11 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_11 \
    op interface \
    ports { update_stream_ddr_1_11_dout { I 96 vector } update_stream_ddr_1_11_num_data_valid { I 3 vector } update_stream_ddr_1_11_fifo_cap { I 3 vector } update_stream_ddr_1_11_empty_n { I 1 bit } update_stream_ddr_1_11_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 164 \
    name update_stream_ddr_1_12 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_12 \
    op interface \
    ports { update_stream_ddr_1_12_dout { I 96 vector } update_stream_ddr_1_12_num_data_valid { I 3 vector } update_stream_ddr_1_12_fifo_cap { I 3 vector } update_stream_ddr_1_12_empty_n { I 1 bit } update_stream_ddr_1_12_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 165 \
    name update_stream_ddr_1_13 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_13 \
    op interface \
    ports { update_stream_ddr_1_13_dout { I 96 vector } update_stream_ddr_1_13_num_data_valid { I 3 vector } update_stream_ddr_1_13_fifo_cap { I 3 vector } update_stream_ddr_1_13_empty_n { I 1 bit } update_stream_ddr_1_13_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 166 \
    name update_stream_ddr_1_14 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_14 \
    op interface \
    ports { update_stream_ddr_1_14_dout { I 96 vector } update_stream_ddr_1_14_num_data_valid { I 3 vector } update_stream_ddr_1_14_fifo_cap { I 3 vector } update_stream_ddr_1_14_empty_n { I 1 bit } update_stream_ddr_1_14_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 167 \
    name update_stream_ddr_1_15 \
    type fifo \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_update_stream_ddr_1_15 \
    op interface \
    ports { update_stream_ddr_1_15_dout { I 96 vector } update_stream_ddr_1_15_num_data_valid { I 3 vector } update_stream_ddr_1_15_fifo_cap { I 3 vector } update_stream_ddr_1_15_empty_n { I 1 bit } update_stream_ddr_1_15_read { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id -1 \
    name ap_ctrl \
    type ap_ctrl \
    reset_level 1 \
    sync_rst true \
    corename ap_ctrl \
    op interface \
    ports { ap_start { I 1 bit } ap_ready { O 1 bit } ap_done { O 1 bit } ap_idle { O 1 bit } ap_continue { I 1 bit } } \
} "
}


# Adapter definition:
set PortName ap_clk
set DataWd 1 
if {${::AESL::PGuard_autoexp_gen}} {
if {[info proc cg_default_interface_gen_clock] == "cg_default_interface_gen_clock"} {
eval "cg_default_interface_gen_clock { \
    id -2 \
    name ${PortName} \
    reset_level 1 \
    sync_rst true \
    corename apif_ap_clk \
    data_wd ${DataWd} \
    op interface \
}"
} else {
puts "@W \[IMPL-113\] Cannot find bus interface model in the library. Ignored generation of bus interface for '${PortName}'"
}
}


# Adapter definition:
set PortName ap_rst
set DataWd 1 
if {${::AESL::PGuard_autoexp_gen}} {
if {[info proc cg_default_interface_gen_reset] == "cg_default_interface_gen_reset"} {
eval "cg_default_interface_gen_reset { \
    id -3 \
    name ${PortName} \
    reset_level 1 \
    sync_rst true \
    corename apif_ap_rst \
    data_wd ${DataWd} \
    op interface \
}"
} else {
puts "@W \[IMPL-114\] Cannot find bus interface model in the library. Ignored generation of bus interface for '${PortName}'"
}
}



# merge
if {${::AESL::PGuard_autoexp_gen}} {
    cg_default_interface_gen_dc_end
    cg_default_interface_gen_bundle_end
    AESL_LIB_XILADAPTER::native_axis_end
}


