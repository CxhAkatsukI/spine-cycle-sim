"""Admit only the complete predeclared connected host-functional matrix."""

import re

from ..analysis import COUNTS


LINE = re.compile(
    r"PRODUCTION_CONNECTED_PASS updates=(\d+) generation=([01]) capacity=131072 "
    r"search=4 cache=2 cold=2 external_channels=12 internal_channels=1356 completions=4 "
    r"blocked=(\d+) same_addresses=1")


def functional(stdout):
    rows = []
    for line in stdout.splitlines():
        match = LINE.fullmatch(line)
        if not match:
            raise ValueError("unexpected connected-G functional output")
        count, generation, blocked = map(int, match.groups())
        if count >= 63 and not blocked:
            raise ValueError("connected-G backpressure was not exercised")
        rows.append({"updates": count, "generation": generation, "blocked_writes": blocked})
    if [(row["updates"], row["generation"]) for row in rows] != [(count, generation)
            for count in COUNTS for generation in (0, 1)]:
        raise ValueError("missing, duplicate or reordered connected-G execution")
    return rows


def stale_rejection(step, stdout, stderr):
    if (step["exit_code"] != 1 or step["stop_reason"] != "process_exit" or
            step["cleanup_snapshot_error"] or stderr != "integrated PMA state mismatch\n"):
        raise ValueError("stale-metadata control did not reject for the expected reason")
    expected = [(0, 0), (0, 1), (1, 0)]
    observed = []
    for line in stdout.splitlines():
        match = LINE.fullmatch(line)
        if not match:
            raise ValueError("unexpected stale-metadata control output")
        observed.append(tuple(map(int, match.groups()[:2])))
    if observed != expected:
        raise ValueError("stale-metadata control failed at the wrong transaction")
    return {"expected_rejection": True, "rejected_at": {"updates": 1, "generation": 1},
            "reason": "integrated PMA state mismatch"}
