#ifndef __KERNEL_CONFIG__
#define __KERNEL_CONFIG__

#define EMPTY (0x8000000000000000UL)
#define END_EDGE (0xFFFFFFFFFFFFFFFFUL)

#define END_INDEX 0xFFFFFFFFU
#define READ_MASK 0x80000000U

#ifndef GRASU_MAX_CACHE_SEGMENT
#define GRASU_MAX_CACHE_SEGMENT 131072
#endif
#define MAX_CACHE_SEGMENT GRASU_MAX_CACHE_SEGMENT

#define SEGMENT_SIZE 16

#define OUTPUT_RESULT 0


#include <hls_stream.h>
#include <stdio.h>
#include <ap_axi_sdata.h>
#include <ap_int.h>

#if defined(SW_EMU) && !defined(__SYNTHESIS__)
#define GRASU_KDEBUG(fmt, ...) do { printf("[KDEBUG] " fmt, ##__VA_ARGS__); fflush(stdout); } while (0)
#else
#define GRASU_KDEBUG(fmt, ...)
#endif

typedef ap_axiu<96, 0, 0, 0> pipe_type_96;
typedef ap_axiu<32, 0, 0, 0> grasu_done_pkt_t;

#ifdef GRASU_ENABLE_COMPLETION_TOKEN
static void write_grasu_completion_token(hls::stream<grasu_done_pkt_t> &done_stream,
                                         ap_uint<32> value) {
    grasu_done_pkt_t done;
    done.data = value;
    done.keep = -1;
    done.strb = -1;
    done.last = 1;
    done_stream.write(done);
}
#endif

#endif
