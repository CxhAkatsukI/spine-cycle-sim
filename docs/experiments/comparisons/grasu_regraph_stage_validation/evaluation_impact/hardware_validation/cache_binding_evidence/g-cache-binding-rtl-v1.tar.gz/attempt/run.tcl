open_project -reset project
set_top process_cache
add_files ../source/cache_binding.cpp -cflags {-DCACHE_BANK_REGISTERED -DCACHE_PRODUCTION_BINDING -DGRASU_ENABLE_COMPLETION_TOKEN -D_GTHREAD_USE_COND_INIT_FUNC -I/data/yxx/tools/xilinx/Vitis_HLS/2024.1/include/etc}
add_files -tb ../source/cache_full_control.cpp -cflags {-DCACHE_BANK_REGISTERED -DCACHE_PRODUCTION_BINDING -DGRASU_ENABLE_COMPLETION_TOKEN -D_GTHREAD_USE_COND_INIT_FUNC -I/data/yxx/tools/xilinx/Vitis_HLS/2024.1/include/etc}
open_solution -reset solution -flow_target vitis
set_part {xcu55c-fsvh2892-2L-e}
create_clock -period 5 -name default
config_rtl -deadlock_detection sim
csim_design
csynth_design
cosim_design -rtl verilog -tool xsim
export_design -format xo -output process_cache.hw.xo
exit
