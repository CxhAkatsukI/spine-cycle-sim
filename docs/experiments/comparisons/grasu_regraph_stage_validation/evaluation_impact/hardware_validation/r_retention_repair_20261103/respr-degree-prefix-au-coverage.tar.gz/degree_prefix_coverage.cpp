#define GRASU_REGRAPH_NO_MAIN 1
#include "weighted_pma_native_host.cpp"

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    using grasu::integration::build_weighted_partitioned_pma_graph;
    using grasu::integration::kWeightedPmaDelete;
    const auto dataset = read_dataset(argv[1]);
    const auto graph = build_weighted_partitioned_pma_graph(
        dataset.node_size, kPartitionSize, dataset.static_edges, dataset.update_edges);
    std::size_t hint = 0;
    for (const auto &update : graph.physical_internal)
        hint = std::max(hint, static_cast<std::size_t>(update.source) + 1);
    const auto prefix = std::min({hint, dataset.node_size, std::size_t{32768}});
    std::cout << "logical_updates=" << dataset.update_edges.size()
              << " physical_updates=" << graph.physical_internal.size()
              << " hint=" << hint << " clamped_prefix=" << prefix << '\n';
    std::size_t cached_total = 0;
    std::size_t seen = 0;
    for (std::size_t i = 0; i < graph.shards.size(); ++i) {
        const auto &updates = graph.shards[i].physical_updates;
        if (updates.empty()) continue;
        const auto lines = updates.size() >= 16 && (prefix + 3) / 4 <= updates.size()
                               ? (prefix + 15) / 16 : 0;
        const auto cached = std::count_if(updates.begin(), updates.end(),
            [lines](std::uint64_t update) { return ((update & ~kWeightedPmaDelete) >> 32) / 16 < lines; });
        seen += updates.size();
        cached_total += cached;
        std::cout << "shard=" << i << " updates=" << updates.size()
                  << " lines=" << lines << " cached=" << cached
                  << " direct=" << updates.size() - cached << '\n';
    }
    if (seen != graph.physical_internal.size()) return 3;
    std::cout << "cached_total=" << cached_total << " direct_total=" << seen - cached_total << '\n';
}
