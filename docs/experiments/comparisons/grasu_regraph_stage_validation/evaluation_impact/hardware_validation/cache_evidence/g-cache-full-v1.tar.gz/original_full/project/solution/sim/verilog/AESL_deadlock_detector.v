`timescale 1 ns / 1 ps

module AESL_deadlock_detector (
    input dl_reset,
    input all_finish,
    input dl_clock);

    wire [1:0] proc_0_data_FIFO_blk;
    wire [1:0] proc_0_data_PIPO_blk;
    wire [1:0] proc_0_start_FIFO_blk;
    wire [1:0] proc_0_TLF_FIFO_blk;
    wire [1:0] proc_0_input_sync_blk;
    wire [1:0] proc_0_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_0;
    reg [1:0] proc_dep_vld_vec_0_reg;
    wire [1:0] in_chan_dep_vld_vec_0;
    wire [5:0] in_chan_dep_data_vec_0;
    wire [1:0] token_in_vec_0;
    wire [1:0] out_chan_dep_vld_vec_0;
    wire [2:0] out_chan_dep_data_0;
    wire [1:0] token_out_vec_0;
    wire dl_detect_out_0;
    wire dep_chan_vld_1_0;
    wire [2:0] dep_chan_data_1_0;
    wire token_1_0;
    wire dep_chan_vld_2_0;
    wire [2:0] dep_chan_data_2_0;
    wire token_2_0;
    wire [1:0] proc_1_data_FIFO_blk;
    wire [1:0] proc_1_data_PIPO_blk;
    wire [1:0] proc_1_start_FIFO_blk;
    wire [1:0] proc_1_TLF_FIFO_blk;
    wire [1:0] proc_1_input_sync_blk;
    wire [1:0] proc_1_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_1;
    reg [1:0] proc_dep_vld_vec_1_reg;
    wire [1:0] in_chan_dep_vld_vec_1;
    wire [5:0] in_chan_dep_data_vec_1;
    wire [1:0] token_in_vec_1;
    wire [1:0] out_chan_dep_vld_vec_1;
    wire [2:0] out_chan_dep_data_1;
    wire [1:0] token_out_vec_1;
    wire dl_detect_out_1;
    wire dep_chan_vld_0_1;
    wire [2:0] dep_chan_data_0_1;
    wire token_0_1;
    wire dep_chan_vld_2_1;
    wire [2:0] dep_chan_data_2_1;
    wire token_2_1;
    wire [1:0] proc_2_data_FIFO_blk;
    wire [1:0] proc_2_data_PIPO_blk;
    wire [1:0] proc_2_start_FIFO_blk;
    wire [1:0] proc_2_TLF_FIFO_blk;
    wire [1:0] proc_2_input_sync_blk;
    wire [1:0] proc_2_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_2;
    reg [1:0] proc_dep_vld_vec_2_reg;
    wire [1:0] in_chan_dep_vld_vec_2;
    wire [5:0] in_chan_dep_data_vec_2;
    wire [1:0] token_in_vec_2;
    wire [1:0] out_chan_dep_vld_vec_2;
    wire [2:0] out_chan_dep_data_2;
    wire [1:0] token_out_vec_2;
    wire dl_detect_out_2;
    wire dep_chan_vld_0_2;
    wire [2:0] dep_chan_data_0_2;
    wire token_0_2;
    wire dep_chan_vld_1_2;
    wire [2:0] dep_chan_data_1_2;
    wire token_1_2;
    wire [2:0] dl_in_vec;
    wire dl_detect_out;
    wire token_clear;
    wire [2:0] origin;

    // Process: AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.entry_proc_U0
    AESL_deadlock_detect_unit #(3, 0, 2, 2) AESL_deadlock_detect_unit_0 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_0),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_0),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_0),
        .token_in_vec(token_in_vec_0),
        .dl_detect_in(dl_detect_out),
        .origin(origin[0]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_0),
        .out_chan_dep_data(out_chan_dep_data_0),
        .token_out_vec(token_out_vec_0),
        .dl_detect_out(dl_in_vec[0]));

    assign proc_0_data_FIFO_blk[0] = 1'b0 | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.entry_proc_U0.pma_cache_c_blk_n);
    assign proc_0_data_PIPO_blk[0] = 1'b0;
    assign proc_0_start_FIFO_blk[0] = 1'b0;
    assign proc_0_TLF_FIFO_blk[0] = 1'b0;
    assign proc_0_input_sync_blk[0] = 1'b0 | (AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.ap_sync_entry_proc_U0_ap_ready & AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.entry_proc_U0.ap_idle & ~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.ap_sync_process_U0_ap_ready);
    assign proc_0_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_0[0] = dl_detect_out ? proc_dep_vld_vec_0_reg[0] : (proc_0_data_FIFO_blk[0] | proc_0_data_PIPO_blk[0] | proc_0_start_FIFO_blk[0] | proc_0_TLF_FIFO_blk[0] | proc_0_input_sync_blk[0] | proc_0_output_sync_blk[0]);
    assign proc_0_data_FIFO_blk[1] = 1'b0;
    assign proc_0_data_PIPO_blk[1] = 1'b0;
    assign proc_0_start_FIFO_blk[1] = 1'b0;
    assign proc_0_TLF_FIFO_blk[1] = 1'b0;
    assign proc_0_input_sync_blk[1] = 1'b0 | (AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.ap_sync_entry_proc_U0_ap_ready & AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.entry_proc_U0.ap_idle & ~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.ap_sync_dispatch_update_U0_ap_ready);
    assign proc_0_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_0[1] = dl_detect_out ? proc_dep_vld_vec_0_reg[1] : (proc_0_data_FIFO_blk[1] | proc_0_data_PIPO_blk[1] | proc_0_start_FIFO_blk[1] | proc_0_TLF_FIFO_blk[1] | proc_0_input_sync_blk[1] | proc_0_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_0_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_0_reg <= proc_dep_vld_vec_0;
        end
    end
    assign in_chan_dep_vld_vec_0[0] = dep_chan_vld_1_0;
    assign in_chan_dep_data_vec_0[2 : 0] = dep_chan_data_1_0;
    assign token_in_vec_0[0] = token_1_0;
    assign in_chan_dep_vld_vec_0[1] = dep_chan_vld_2_0;
    assign in_chan_dep_data_vec_0[5 : 3] = dep_chan_data_2_0;
    assign token_in_vec_0[1] = token_2_0;
    assign dep_chan_vld_0_2 = out_chan_dep_vld_vec_0[0];
    assign dep_chan_data_0_2 = out_chan_dep_data_0;
    assign token_0_2 = token_out_vec_0[0];
    assign dep_chan_vld_0_1 = out_chan_dep_vld_vec_0[1];
    assign dep_chan_data_0_1 = out_chan_dep_data_0;
    assign token_0_1 = token_out_vec_0[1];

    // Process: AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0
    AESL_deadlock_detect_unit #(3, 1, 2, 2) AESL_deadlock_detect_unit_1 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_1),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_1),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_1),
        .token_in_vec(token_in_vec_1),
        .dl_detect_in(dl_detect_out),
        .origin(origin[1]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_1),
        .out_chan_dep_data(out_chan_dep_data_1),
        .token_out_vec(token_out_vec_1),
        .dl_detect_out(dl_in_vec[1]));

    assign proc_1_data_FIFO_blk[0] = 1'b0 | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_1_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_2_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_3_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_4_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_5_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_6_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_7_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_8_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_9_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_10_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_11_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_12_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_13_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_14_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.grp_dispatch_update_Pipeline_VITIS_LOOP_19_1_fu_110.update_stream_cache_15_blk_n);
    assign proc_1_data_PIPO_blk[0] = 1'b0;
    assign proc_1_start_FIFO_blk[0] = 1'b0;
    assign proc_1_TLF_FIFO_blk[0] = 1'b0;
    assign proc_1_input_sync_blk[0] = 1'b0 | (AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.ap_sync_dispatch_update_U0_ap_ready & AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.ap_idle & ~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.ap_sync_process_U0_ap_ready);
    assign proc_1_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_1[0] = dl_detect_out ? proc_dep_vld_vec_1_reg[0] : (proc_1_data_FIFO_blk[0] | proc_1_data_PIPO_blk[0] | proc_1_start_FIFO_blk[0] | proc_1_TLF_FIFO_blk[0] | proc_1_input_sync_blk[0] | proc_1_output_sync_blk[0]);
    assign proc_1_data_FIFO_blk[1] = 1'b0;
    assign proc_1_data_PIPO_blk[1] = 1'b0;
    assign proc_1_start_FIFO_blk[1] = 1'b0;
    assign proc_1_TLF_FIFO_blk[1] = 1'b0;
    assign proc_1_input_sync_blk[1] = 1'b0 | (AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.ap_sync_dispatch_update_U0_ap_ready & AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.dispatch_update_U0.ap_idle & ~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.ap_sync_entry_proc_U0_ap_ready);
    assign proc_1_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_1[1] = dl_detect_out ? proc_dep_vld_vec_1_reg[1] : (proc_1_data_FIFO_blk[1] | proc_1_data_PIPO_blk[1] | proc_1_start_FIFO_blk[1] | proc_1_TLF_FIFO_blk[1] | proc_1_input_sync_blk[1] | proc_1_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_1_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_1_reg <= proc_dep_vld_vec_1;
        end
    end
    assign in_chan_dep_vld_vec_1[0] = dep_chan_vld_0_1;
    assign in_chan_dep_data_vec_1[2 : 0] = dep_chan_data_0_1;
    assign token_in_vec_1[0] = token_0_1;
    assign in_chan_dep_vld_vec_1[1] = dep_chan_vld_2_1;
    assign in_chan_dep_data_vec_1[5 : 3] = dep_chan_data_2_1;
    assign token_in_vec_1[1] = token_2_1;
    assign dep_chan_vld_1_2 = out_chan_dep_vld_vec_1[0];
    assign dep_chan_data_1_2 = out_chan_dep_data_1;
    assign token_1_2 = token_out_vec_1[0];
    assign dep_chan_vld_1_0 = out_chan_dep_vld_vec_1[1];
    assign dep_chan_data_1_0 = out_chan_dep_data_1;
    assign token_1_0 = token_out_vec_1[1];

    // Process: AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0
    AESL_deadlock_detect_unit #(3, 2, 2, 2) AESL_deadlock_detect_unit_2 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_2),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_2),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_2),
        .token_in_vec(token_in_vec_2),
        .dl_detect_in(dl_detect_out),
        .origin(origin[2]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_2),
        .out_chan_dep_data(out_chan_dep_data_2),
        .token_out_vec(token_out_vec_2),
        .dl_detect_out(dl_in_vec[2]));

    assign proc_2_data_FIFO_blk[0] = 1'b0 | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.pma_blk_n);
    assign proc_2_data_PIPO_blk[0] = 1'b0;
    assign proc_2_start_FIFO_blk[0] = 1'b0;
    assign proc_2_TLF_FIFO_blk[0] = 1'b0;
    assign proc_2_input_sync_blk[0] = 1'b0 | (AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.ap_sync_process_U0_ap_ready & AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.ap_idle & ~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.ap_sync_entry_proc_U0_ap_ready);
    assign proc_2_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_2[0] = dl_detect_out ? proc_dep_vld_vec_2_reg[0] : (proc_2_data_FIFO_blk[0] | proc_2_data_PIPO_blk[0] | proc_2_start_FIFO_blk[0] | proc_2_TLF_FIFO_blk[0] | proc_2_input_sync_blk[0] | proc_2_output_sync_blk[0]);
    assign proc_2_data_FIFO_blk[1] = 1'b0 | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_200.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_207.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_214.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_221.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_228.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_235.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_242.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_249.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_256.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_263.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_270.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_277.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_284.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_291.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_298.update_stream_cache_0_blk_n) | (~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.grp_process_1_fu_305.update_stream_cache_0_blk_n);
    assign proc_2_data_PIPO_blk[1] = 1'b0;
    assign proc_2_start_FIFO_blk[1] = 1'b0;
    assign proc_2_TLF_FIFO_blk[1] = 1'b0;
    assign proc_2_input_sync_blk[1] = 1'b0 | (AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.ap_sync_process_U0_ap_ready & AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.process_U0.ap_idle & ~AESL_inst_cache_full_probe.grp_process_cache_1_fu_72.ap_sync_dispatch_update_U0_ap_ready);
    assign proc_2_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_2[1] = dl_detect_out ? proc_dep_vld_vec_2_reg[1] : (proc_2_data_FIFO_blk[1] | proc_2_data_PIPO_blk[1] | proc_2_start_FIFO_blk[1] | proc_2_TLF_FIFO_blk[1] | proc_2_input_sync_blk[1] | proc_2_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_2_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_2_reg <= proc_dep_vld_vec_2;
        end
    end
    assign in_chan_dep_vld_vec_2[0] = dep_chan_vld_0_2;
    assign in_chan_dep_data_vec_2[2 : 0] = dep_chan_data_0_2;
    assign token_in_vec_2[0] = token_0_2;
    assign in_chan_dep_vld_vec_2[1] = dep_chan_vld_1_2;
    assign in_chan_dep_data_vec_2[5 : 3] = dep_chan_data_1_2;
    assign token_in_vec_2[1] = token_1_2;
    assign dep_chan_vld_2_0 = out_chan_dep_vld_vec_2[0];
    assign dep_chan_data_2_0 = out_chan_dep_data_2;
    assign token_2_0 = token_out_vec_2[0];
    assign dep_chan_vld_2_1 = out_chan_dep_vld_vec_2[1];
    assign dep_chan_data_2_1 = out_chan_dep_data_2;
    assign token_2_1 = token_out_vec_2[1];


    wire [2:0] dl_in_vec_comb = dl_in_vec & ~{2{all_finish}};
    AESL_deadlock_report_unit #(3) AESL_deadlock_report_unit_inst (
        .dl_reset(dl_reset),
        .dl_clock(dl_clock),
        .dl_in_vec(dl_in_vec_comb),
        .dl_detect_out(dl_detect_out),
        .origin(origin),
        .token_clear(token_clear));

endmodule
