#pragma once

#include "weighted_pma_runtime_plan.hpp"
#include "weighted_pma_update_reference.hpp"
#include <fstream>
#include <stdexcept>

namespace grasu_gap {
using namespace grasu::integration;

inline WeightedPartitionedPmaGraph load_graph(const char* path, unsigned partition) {
    std::ifstream input(path);
    std::size_t vertices{}, initial_count{}, update_count{};
    if (!(input >> vertices >> initial_count >> update_count) || vertices == 0 ||
        vertices > 524288 || initial_count > 5000000 || update_count == 0 || update_count > 524416)
        throw std::runtime_error("bounded G insertion workload required");
    std::vector<WeightedEdgeRecord> initial, updates;
    const auto read = [&](bool update) {
        unsigned source{}, destination{}, weight{}, operation{1};
        if (!(input >> source >> destination >> weight) || (update && !(input >> operation)) ||
            source >= vertices || destination >= vertices || weight == 0 || weight > 4095 || operation != 1)
            throw std::runtime_error("invalid G insertion record");
        return WeightedEdgeRecord{source, destination, static_cast<std::uint16_t>(weight), false};
    };
    for (std::size_t i = 0; i < initial_count; ++i) initial.push_back(read(false));
    for (std::size_t i = 0; i < update_count; ++i) updates.push_back(read(true));
    std::string trailing;
    if (input >> trailing) throw std::runtime_error("trailing G workload data");
    return build_weighted_partitioned_pma_graph(vertices, partition, initial, updates);
}

inline auto expected_state(const WeightedPartitionedPmaGraph& graph,
                           const std::vector<WeightedPmaPackedShardBuffers>& packed) {
    std::vector<std::array<std::vector<std::uint32_t>, 4>> result;
    for (const auto& shard : packed) result.push_back(shard.pma_words);
    for (const auto& segment : build_weighted_pma_update_reference(graph, 131072))
        std::copy(segment.expected.begin(), segment.expected.end(),
                  result.at(segment.shard).at(segment.port).begin() + segment.port_word_offset);
    return result;
}
}  // namespace grasu_gap
