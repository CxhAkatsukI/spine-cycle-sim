// The pinned original-G runtime owns board leasing, BDF checks and XRT setup.
#include "runtime.hpp"
#include "grasu_gap_model.hpp"
#include <iomanip>
#include <iostream>

namespace {
using namespace original_g_board;
using namespace grasu_gap;

template<class T>
cl::Buffer buffer(Session& session, unsigned bank, const std::vector<T>& values,
                  cl_mem_flags access) {
    require(bank < 23 && !values.empty() && values.size() * sizeof(T) <= 64ull * 1024 * 1024,
            "bounded G allocation required");
    cl_mem_ext_ptr_t extension{}; extension.flags = bank | XCL_MEM_TOPOLOGY;
    cl_int error{};
    cl::Buffer result(session.context, access | CL_MEM_EXT_PTR_XILINX,
                      values.size() * sizeof(T), &extension, &error);
    checked(error, "allocate G control buffer");
    checked(session.queue.enqueueWriteBuffer(result, CL_TRUE, 0, values.size() * sizeof(T), values.data()),
            "preload G control buffer");
    return result;
}

struct ShardBuffers {
    std::array<cl::Buffer, 4> pma, edges, rows, binary;
};

void run(const char* xclbin, const char* input, unsigned partition, bool integrated,
         bool replicas, unsigned device, bool runtime_placement) {
    const auto graph = load_graph(input, partition);
    require(!runtime_placement || (integrated && !replicas), "runtime placement uses current shared metadata");
    const auto plan = build_weighted_pma_runtime_plan(graph, 131072, 23, 512ull * 1024 * 1024,
        runtime_placement ? WeightedPmaChannelPolicy::lane_aware_u55c : WeightedPmaChannelPolicy::unrestricted,
        runtime_placement);
    const auto packed = pack_weighted_pma_runtime_buffers(graph, plan);
    const auto expected = expected_state(graph, packed);
    Session session(xclbin, device);
    std::vector<ShardBuffers> buffers(graph.shards.size());
    std::vector<cl::Memory> resident;
    std::size_t slots{}, checked_words{};
    for (std::size_t s = 0; s < buffers.size(); ++s) {
        auto& b = buffers[s]; const auto& p = packed[s];
        slots += graph.shards[s].initial_pma_words.size();
        for (unsigned lane = 0; lane < 4; ++lane) {
            const unsigned bank = integrated ? lane * 6 : lane;
            const auto bank_for = [&](const std::string& role) {
                return runtime_placement ? unsigned(find_weighted_pma_region(plan, s, role).channel) : bank;
            };
            b.pma[lane] = buffer(session, bank_for("pma" + std::to_string(lane)), p.pma_words[lane], CL_MEM_READ_WRITE);
            b.edges[lane] = buffer(session, bank_for("update" + std::to_string(lane)), p.updates[lane], CL_MEM_READ_ONLY);
            resident.push_back(b.pma[lane]); resident.push_back(b.edges[lane]);
            checked_words += p.pma_words[lane].size();
            if (lane == 0 || replicas) {
                b.rows[lane] = buffer(session, bank_for("row"), p.row_bounds, CL_MEM_READ_ONLY);
                b.binary[lane] = buffer(session, bank_for("binary"), p.binary_heads, CL_MEM_READ_ONLY);
                resident.push_back(b.rows[lane]); resident.push_back(b.binary[lane]);
            } else {
                b.rows[lane] = b.rows[0]; b.binary[lane] = b.binary[0];
            }
        }
    }
    checked(session.queue.enqueueMigrateMemObjects(resident, 0), "establish input residency");
    checked(session.queue.finish(), "finish input residency");
    std::vector<cl::Kernel> kernels;
    for (const auto& kind : {"process_cache", "process_ddr", "dispatch", "bin_search"}) {
        const unsigned n = std::string(kind) == "bin_search" ? 4 : std::string(kind) == "dispatch" ? 1 : 2;
        for (unsigned i = 0; i < n; ++i) {
            const auto instance = std::string(kind) + "_" + std::to_string(i + 1);
            kernels.push_back(session.kernel(std::string(kind) + ":{" + instance + "}"));
        }
    }
    cl::Kernel barrier;
    if (integrated) barrier = session.kernel("pma_completion_barrier:{pma_completion_barrier_1}");
    std::cout << "G_CONTROL_CONFIG {\"vertices\":" << graph.vertices << ",\"updates\":" << graph.physical_internal.size()
              << ",\"shards\":" << buffers.size() << ",\"pma_slots\":" << slots
              << ",\"full_pma_words_checked_per_repeat\":" << checked_words
              << ",\"metadata_replicas\":" << (replicas ? 4 : 1)
              << ",\"runtime_placement\":" << (runtime_placement ? "true" : "false") << "}\n";
    for (unsigned repeat = 0; repeat < 4; ++repeat) {
        for (std::size_t s = 0; s < buffers.size(); ++s)
            for (unsigned lane = 0; lane < 4; ++lane) {
                const auto& words = packed[s].pma_words[lane];
                checked(session.queue.enqueueWriteBuffer(buffers[s].pma[lane], CL_TRUE, 0,
                        words.size() * sizeof(std::uint32_t), words.data()), "restore initial PMA");
            }
        std::vector<std::array<cl::Event, 9>> events(buffers.size());
        for (std::size_t s = 0; s < buffers.size(); ++s) {
            const auto& b = buffers[s];
            if (graph.shards[s].physical_updates.empty()) continue;
            for (unsigned half = 0; half < 2; ++half) {
                checked(kernels[half].setArg(0, b.pma[2 * half]), "bind cache PMA");
                const unsigned n = kernels[half].getInfo<CL_KERNEL_NUM_ARGS>();
                require(n == (integrated ? 4u : 2u), "unexpected cache ABI");
                if (integrated) {
                    const unsigned extent = weighted_pma_cache_valid_segments(plan.shards[s], half, 131072);
                    checked(kernels[half].setArg(3, extent), "bind cache extent");
                }
                for (unsigned arg = 0; arg < 4; ++arg)
                    checked(kernels[2 + half].setArg(arg, b.pma[2 * half + 1]), "bind DDR PMA");
            }
            checked(kernels[4].setArg(0, unsigned(graph.shards[s].physical_updates.size())), "bind dispatch count");
            for (unsigned lane = 0; lane < 4; ++lane) {
                checked(kernels[5 + lane].setArg(0, b.edges[lane]), "bind update lane");
                for (unsigned arg = 1; arg <= 4; ++arg) {
                    checked(kernels[5 + lane].setArg(arg, b.binary[lane]), "bind binary");
                    checked(kernels[5 + lane].setArg(arg + 4, b.rows[lane]), "bind rows");
                }
                checked(kernels[5 + lane].setArg(9, unsigned(plan.shards[s].update_counts[lane])), "bind search count");
            }
            for (unsigned i = 0; i < 9; ++i)
                checked(session.queue.enqueueTask(kernels[i], nullptr, &events[s][i]), "enqueue G pipeline");
            if (integrated) checked(session.queue.enqueueTask(barrier), "enqueue completion drain");
            checked(session.queue.finish(), "finish G shard");
        }
        // Readback and all logging are outside the measured multi-shard envelope.
        for (std::size_t s = 0; s < buffers.size(); ++s)
            for (unsigned lane = 0; lane < 4; ++lane) session.verify(buffers[s].pma[lane], expected[s][lane]);
        cl_ulong first = UINT64_MAX, last{}, previous{};
        for (std::size_t s = 0; s < events.size(); ++s) {
            if (graph.shards[s].physical_updates.empty()) continue;
            cl_ulong begin = UINT64_MAX, end{};
            for (unsigned i = 0; i < 9; ++i) {
                const auto start = events[s][i].getProfilingInfo<CL_PROFILING_COMMAND_START>();
                const auto stop = events[s][i].getProfilingInfo<CL_PROFILING_COMMAND_END>();
                require(stop > start, "invalid G event");
                begin = std::min(begin, start); end = std::max(end, stop);
                std::cout << "G_CONTROL_EVENT {\"repeat\":" << repeat << ",\"shard\":" << s
                          << ",\"cu\":" << i << ",\"start_ns\":" << start << ",\"end_ns\":" << stop << "}\n";
            }
            std::cout << "G_CONTROL_SHARD {\"repeat\":" << repeat << ",\"shard\":" << s
                      << ",\"span_ns\":" << end - begin << ",\"gap_ns\":" << (previous ? begin - previous : 0) << "}\n";
            first = std::min(first, begin); last = std::max(last, end); previous = end;
        }
        std::cout << "G_CONTROL_RESULT {\"repeat\":" << repeat << ",\"full_pma_pass\":true,\"event_span_ns\":"
                  << last - first << "}\n" << std::flush;
    }
}
}  // namespace

int main(int argc, char** argv) {
    try {
        require(argc == 7 || argc == 8, "usage: control XCLBIN INPUT PARTITION INTEGRATED REPLICAS DEVICE [RUNTIME_PLACEMENT]");
        require(number(argv[4]) <= 1 && number(argv[5]) <= 1, "binary mode required");
        require(argc == 7 || number(argv[7]) <= 1, "binary placement mode required");
        run(argv[1], argv[2], number(argv[3]), number(argv[4]), number(argv[5]), number(argv[6]),
            argc == 8 && number(argv[7]) == 1);
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n'; return 1;
    }
}
