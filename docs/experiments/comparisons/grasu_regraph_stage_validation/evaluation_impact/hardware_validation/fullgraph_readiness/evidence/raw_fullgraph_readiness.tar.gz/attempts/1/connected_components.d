probe: \
 /data/chuxiao/experiments/baseline_hardware_validation_20261015/fullgraph-host-readiness-v2/source/tools/sharded_k4_native_host.cpp \
 /usr/include/stdc-predef.h \
 /data/chuxiao/experiments/baseline_hardware_validation_20261015/fullgraph-host-readiness-v2/source/tools/weighted_pma_native_host.cpp \
 /usr/include/CL/cl2.hpp /usr/include/CL/opencl.hpp \
 /usr/include/CL/opencl.h /usr/include/CL/cl.h \
 /usr/include/CL/cl_version.h /usr/include/CL/cl_platform.h \
 /usr/lib/gcc/x86_64-linux-gnu/15/include/stdint.h /usr/include/stdint.h \
 /usr/include/x86_64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/x86_64-linux-gnu/bits/wordsize.h \
 /usr/include/x86_64-linux-gnu/bits/timesize.h \
 /usr/include/x86_64-linux-gnu/sys/cdefs.h \
 /usr/include/x86_64-linux-gnu/bits/long-double.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
 /usr/include/x86_64-linux-gnu/bits/types.h \
 /usr/include/x86_64-linux-gnu/bits/typesizes.h \
 /usr/include/x86_64-linux-gnu/bits/time64.h \
 /usr/include/x86_64-linux-gnu/bits/wchar.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-intn.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-least.h \
 /usr/lib/gcc/x86_64-linux-gnu/15/include/stddef.h \
 /usr/lib/gcc/x86_64-linux-gnu/15/include/xmmintrin.h \
 /usr/lib/gcc/x86_64-linux-gnu/15/include/mmintrin.h \
 /usr/lib/gcc/x86_64-linux-gnu/15/include/mm_malloc.h \
 /usr/include/c++/15/stdlib.h /usr/include/c++/15/cstdlib \
 /usr/include/x86_64-linux-gnu/c++/15/bits/c++config.h \
 /usr/include/x86_64-linux-gnu/c++/15/bits/os_defines.h \
 /usr/include/x86_64-linux-gnu/c++/15/bits/cpu_defines.h \
 /usr/include/c++/15/pstl/pstl_config.h /usr/include/stdlib.h \
 /usr/include/x86_64-linux-gnu/bits/waitflags.h \
 /usr/include/x86_64-linux-gnu/bits/waitstatus.h \
 /usr/include/x86_64-linux-gnu/bits/floatn.h \
 /usr/include/x86_64-linux-gnu/bits/floatn-common.h \
 /usr/include/x86_64-linux-gnu/bits/types/locale_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/x86_64-linux-gnu/sys/types.h \
 /usr/include/x86_64-linux-gnu/bits/types/clock_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/clockid_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/time_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/timer_t.h /usr/include/endian.h \
 /usr/include/x86_64-linux-gnu/bits/endian.h \
 /usr/include/x86_64-linux-gnu/bits/endianness.h \
 /usr/include/x86_64-linux-gnu/bits/byteswap.h \
 /usr/include/x86_64-linux-gnu/bits/uintn-identity.h \
 /usr/include/x86_64-linux-gnu/sys/select.h \
 /usr/include/x86_64-linux-gnu/bits/select.h \
 /usr/include/x86_64-linux-gnu/bits/types/sigset_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__sigset_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h \
 /usr/include/x86_64-linux-gnu/bits/pthreadtypes.h \
 /usr/include/x86_64-linux-gnu/bits/thread-shared-types.h \
 /usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h \
 /usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h \
 /usr/include/x86_64-linux-gnu/bits/struct_mutex.h \
 /usr/include/x86_64-linux-gnu/bits/struct_rwlock.h /usr/include/alloca.h \
 /usr/include/x86_64-linux-gnu/bits/stdlib-bsearch.h \
 /usr/include/x86_64-linux-gnu/bits/stdlib-float.h \
 /usr/include/c++/15/bits/std_abs.h \
 /usr/lib/gcc/x86_64-linux-gnu/15/include/emmintrin.h \
 /usr/include/CL/cl_gl.h /opt/xilinx/xrt/include/CL/cl_ext.h \
 /opt/xilinx/xrt/include/CL/cl_ext_xilinx.h /usr/include/CL/cl_ext.h \
 /usr/include/c++/15/utility /usr/include/c++/15/bits/stl_relops.h \
 /usr/include/c++/15/bits/stl_pair.h /usr/include/c++/15/type_traits \
 /usr/include/c++/15/bits/version.h /usr/include/c++/15/bits/move.h \
 /usr/include/c++/15/bits/utility.h /usr/include/c++/15/initializer_list \
 /usr/include/c++/15/limits /usr/include/c++/15/iterator \
 /usr/include/c++/15/bits/stl_iterator_base_types.h \
 /usr/include/c++/15/bits/stl_iterator_base_funcs.h \
 /usr/include/c++/15/bits/concept_check.h \
 /usr/include/c++/15/debug/assertions.h \
 /usr/include/c++/15/bits/stl_iterator.h \
 /usr/include/c++/15/bits/cpp_type_traits.h \
 /usr/include/c++/15/ext/type_traits.h \
 /usr/include/c++/15/bits/ptr_traits.h \
 /usr/include/c++/15/bits/stream_iterator.h /usr/include/c++/15/iosfwd \
 /usr/include/c++/15/bits/requires_hosted.h \
 /usr/include/c++/15/bits/stringfwd.h \
 /usr/include/c++/15/bits/memoryfwd.h /usr/include/c++/15/bits/postypes.h \
 /usr/include/c++/15/cwchar /usr/include/wchar.h \
 /usr/lib/gcc/x86_64-linux-gnu/15/include/stdarg.h \
 /usr/include/x86_64-linux-gnu/bits/types/wint_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/mbstate_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__FILE.h \
 /usr/include/x86_64-linux-gnu/bits/types/FILE.h \
 /usr/include/c++/15/debug/debug.h \
 /usr/include/c++/15/bits/streambuf_iterator.h \
 /usr/include/c++/15/streambuf /usr/include/c++/15/bits/localefwd.h \
 /usr/include/x86_64-linux-gnu/c++/15/bits/c++locale.h \
 /usr/include/c++/15/clocale /usr/include/locale.h \
 /usr/include/x86_64-linux-gnu/bits/locale.h /usr/include/c++/15/cctype \
 /usr/include/ctype.h /usr/include/c++/15/bits/ios_base.h \
 /usr/include/c++/15/ext/atomicity.h \
 /usr/include/x86_64-linux-gnu/c++/15/bits/gthr.h \
 /usr/include/x86_64-linux-gnu/c++/15/bits/gthr-default.h \
 /usr/include/pthread.h /usr/include/sched.h \
 /usr/include/x86_64-linux-gnu/bits/sched.h \
 /usr/include/linux/sched/types.h /usr/include/linux/types.h \
 /usr/lib/linux/uapi/x86/asm/types.h /usr/include/asm-generic/types.h \
 /usr/include/asm-generic/int-ll64.h \
 /usr/lib/linux/uapi/x86/asm/bitsperlong.h \
 /usr/include/asm-generic/bitsperlong.h /usr/include/linux/posix_types.h \
 /usr/include/linux/stddef.h /usr/lib/linux/uapi/x86/asm/posix_types.h \
 /usr/lib/linux/uapi/x86/asm/posix_types_64.h \
 /usr/include/asm-generic/posix_types.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_sched_param.h \
 /usr/include/x86_64-linux-gnu/bits/cpu-set.h /usr/include/time.h \
 /usr/include/x86_64-linux-gnu/bits/time.h \
 /usr/include/x86_64-linux-gnu/bits/timex.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_tm.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_itimerspec.h \
 /usr/include/x86_64-linux-gnu/bits/setjmp.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct___jmp_buf_tag.h \
 /usr/include/x86_64-linux-gnu/bits/pthread_stack_min-dynamic.h \
 /usr/include/x86_64-linux-gnu/c++/15/bits/atomic_word.h \
 /usr/include/x86_64-linux-gnu/sys/single_threaded.h \
 /usr/include/c++/15/bits/locale_classes.h /usr/include/c++/15/string \
 /usr/include/c++/15/bits/char_traits.h \
 /usr/include/c++/15/bits/allocator.h \
 /usr/include/x86_64-linux-gnu/c++/15/bits/c++allocator.h \
 /usr/include/c++/15/bits/new_allocator.h /usr/include/c++/15/new \
 /usr/include/c++/15/bits/exception.h \
 /usr/include/c++/15/bits/functexcept.h \
 /usr/include/c++/15/bits/exception_defines.h \
 /usr/include/c++/15/bits/ostream_insert.h \
 /usr/include/c++/15/bits/cxxabi_forced.h \
 /usr/include/c++/15/bits/stl_function.h \
 /usr/include/c++/15/backward/binders.h \
 /usr/include/c++/15/ext/numeric_traits.h \
 /usr/include/c++/15/bits/stl_algobase.h \
 /usr/include/c++/15/bits/predefined_ops.h /usr/include/c++/15/bit \
 /usr/include/c++/15/concepts /usr/include/c++/15/bits/refwrap.h \
 /usr/include/c++/15/bits/invoke.h \
 /usr/include/c++/15/bits/range_access.h \
 /usr/include/c++/15/bits/basic_string.h \
 /usr/include/c++/15/ext/alloc_traits.h \
 /usr/include/c++/15/bits/alloc_traits.h \
 /usr/include/c++/15/bits/stl_construct.h /usr/include/c++/15/string_view \
 /usr/include/c++/15/bits/functional_hash.h \
 /usr/include/c++/15/bits/hash_bytes.h \
 /usr/include/c++/15/bits/string_view.tcc \
 /usr/include/c++/15/ext/string_conversions.h /usr/include/c++/15/cstdio \
 /usr/include/stdio.h /usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h \
 /usr/include/x86_64-linux-gnu/bits/types/cookie_io_functions_t.h \
 /usr/include/x86_64-linux-gnu/bits/stdio_lim.h \
 /usr/include/x86_64-linux-gnu/bits/stdio.h /usr/include/c++/15/cerrno \
 /usr/include/errno.h /usr/include/x86_64-linux-gnu/bits/errno.h \
 /usr/include/linux/errno.h /usr/lib/linux/uapi/x86/asm/errno.h \
 /usr/include/asm-generic/errno.h /usr/include/asm-generic/errno-base.h \
 /usr/include/x86_64-linux-gnu/bits/types/error_t.h \
 /usr/include/c++/15/bits/charconv.h \
 /usr/include/c++/15/bits/basic_string.tcc \
 /usr/include/c++/15/bits/memory_resource.h /usr/include/c++/15/cstddef \
 /usr/include/c++/15/bits/uses_allocator.h \
 /usr/include/c++/15/bits/uses_allocator_args.h /usr/include/c++/15/tuple \
 /usr/include/c++/15/bits/locale_classes.tcc \
 /usr/include/c++/15/system_error \
 /usr/include/x86_64-linux-gnu/c++/15/bits/error_constants.h \
 /usr/include/c++/15/stdexcept /usr/include/c++/15/exception \
 /usr/include/c++/15/bits/exception_ptr.h \
 /usr/include/c++/15/bits/cxxabi_init_exception.h \
 /usr/include/c++/15/typeinfo /usr/include/c++/15/bits/nested_exception.h \
 /usr/include/c++/15/bits/streambuf.tcc /usr/include/c++/15/mutex \
 /usr/include/c++/15/bits/chrono.h /usr/include/c++/15/ratio \
 /usr/include/c++/15/cstdint /usr/include/c++/15/ctime \
 /usr/include/c++/15/bits/parse_numbers.h \
 /usr/include/c++/15/bits/std_mutex.h \
 /usr/include/c++/15/bits/unique_lock.h /usr/include/c++/15/cstring \
 /usr/include/string.h /usr/include/strings.h \
 /usr/include/c++/15/functional /usr/include/c++/15/bits/std_function.h \
 /usr/include/c++/15/unordered_map \
 /usr/include/c++/15/bits/unordered_map.h \
 /usr/include/c++/15/bits/hashtable.h \
 /usr/include/c++/15/bits/hashtable_policy.h \
 /usr/include/c++/15/ext/aligned_buffer.h \
 /usr/include/c++/15/bits/enable_special_members.h \
 /usr/include/c++/15/bits/node_handle.h \
 /usr/include/c++/15/bits/erase_if.h /usr/include/c++/15/vector \
 /usr/include/c++/15/bits/stl_uninitialized.h \
 /usr/include/c++/15/bits/stl_vector.h \
 /usr/include/c++/15/bits/stl_bvector.h \
 /usr/include/c++/15/bits/vector.tcc /usr/include/c++/15/array \
 /usr/include/c++/15/compare /usr/include/c++/15/algorithm \
 /usr/include/c++/15/bits/stl_algo.h \
 /usr/include/c++/15/bits/algorithmfwd.h \
 /usr/include/c++/15/bits/stl_heap.h \
 /usr/include/c++/15/bits/uniform_int_dist.h \
 /usr/include/c++/15/bits/stl_tempbuf.h \
 /usr/include/c++/15/pstl/glue_algorithm_defs.h \
 /usr/include/c++/15/pstl/execution_defs.h /usr/include/c++/15/chrono \
 /usr/include/c++/15/fstream /usr/include/c++/15/istream \
 /usr/include/c++/15/ios /usr/include/c++/15/bits/basic_ios.h \
 /usr/include/c++/15/bits/locale_facets.h /usr/include/c++/15/cwctype \
 /usr/include/wctype.h /usr/include/x86_64-linux-gnu/bits/wctype-wchar.h \
 /usr/include/x86_64-linux-gnu/c++/15/bits/ctype_base.h \
 /usr/include/x86_64-linux-gnu/c++/15/bits/ctype_inline.h \
 /usr/include/c++/15/bits/locale_facets.tcc \
 /usr/include/c++/15/bits/basic_ios.tcc /usr/include/c++/15/ostream \
 /usr/include/c++/15/bits/ostream.h /usr/include/c++/15/bits/ostream.tcc \
 /usr/include/c++/15/bits/istream.tcc /usr/include/c++/15/bits/codecvt.h \
 /usr/include/x86_64-linux-gnu/c++/15/bits/basic_file.h \
 /usr/include/x86_64-linux-gnu/c++/15/bits/c++io.h \
 /usr/include/c++/15/bits/fstream.tcc /usr/include/c++/15/iomanip \
 /usr/include/c++/15/locale \
 /usr/include/c++/15/bits/locale_facets_nonio.h \
 /usr/include/x86_64-linux-gnu/c++/15/bits/time_members.h \
 /usr/include/x86_64-linux-gnu/c++/15/bits/messages_members.h \
 /usr/include/libintl.h /usr/include/c++/15/bits/locale_facets_nonio.tcc \
 /usr/include/c++/15/bits/locale_conv.h \
 /usr/include/c++/15/bits/quoted_string.h /usr/include/c++/15/sstream \
 /usr/include/c++/15/bits/sstream.tcc /usr/include/c++/15/iostream \
 /usr/include/c++/15/map /usr/include/c++/15/bits/stl_tree.h \
 /usr/include/c++/15/bits/stl_map.h \
 /usr/include/c++/15/bits/stl_multimap.h \
 /data/chuxiao/experiments/baseline_hardware_validation_20261015/fullgraph-host-readiness-v2/source/include/weighted_pma_graph.hpp \
 /usr/include/c++/15/set /usr/include/c++/15/bits/stl_set.h \
 /usr/include/c++/15/bits/stl_multiset.h \
 /data/chuxiao/experiments/baseline_hardware_validation_20261015/fullgraph-host-readiness-v2/source/include/sharded_event_trace.hpp \
 /data/chuxiao/experiments/baseline_hardware_validation_20261015/fullgraph-host-readiness-v2/source/include/weighted_pma_runtime_plan.hpp \
 /data/chuxiao/experiments/baseline_hardware_validation_20261015/fullgraph-host-readiness-v2/source/include/weighted_pma_update_reference.hpp \
 /usr/include/c++/15/numeric /usr/include/c++/15/bits/stl_numeric.h \
 /usr/include/c++/15/pstl/glue_numeric_defs.h
