probe: \
 /data/chuxiao/experiments/baseline_evaluation_impact_20261012/g-search-pipeline-v1/source-controls-v4/source/cpp/src/original_grasu/types.cpp \
 /data/chuxiao/experiments/baseline_evaluation_impact_20261012/g-search-pipeline-v1/source-controls-v4/source/cpp/include/spine_sim/original_grasu/types.hpp \
 /data/chuxiao/experiments/baseline_evaluation_impact_20261012/g-search-pipeline-v1/source-controls-v4/source/cpp/include/spine_sim/axi.hpp \
 /data/chuxiao/experiments/baseline_evaluation_impact_20261012/g-search-pipeline-v1/source-controls-v4/source/cpp/include/spine_sim/component.hpp \
 /data/chuxiao/experiments/baseline_evaluation_impact_20261012/g-search-pipeline-v1/source-controls-v4/source/cpp/include/spine_sim/fifo.hpp \
 /data/chuxiao/experiments/baseline_evaluation_impact_20261012/g-search-pipeline-v1/source-controls-v4/source/cpp/include/spine_sim/memory_backend.hpp
