#pragma once

#include <cstdlib>
#include <memory>
#include <new>

// Keep this storage alive until every CL_MEM_USE_HOST_PTR buffer is released.
// CONTENT_UNDEFINED residency must precede prefix writes; this is not input data.
using MaintenanceHostBacking = std::unique_ptr<void, decltype(&std::free)>;

inline MaintenanceHostBacking allocate_maintenance_backing(size_t bytes) {
    void *data = nullptr;
    if (bytes == 0 || posix_memalign(&data, 4096, bytes) != 0) {
        throw std::bad_alloc();
    }
    return MaintenanceHostBacking(data, &std::free);
}
