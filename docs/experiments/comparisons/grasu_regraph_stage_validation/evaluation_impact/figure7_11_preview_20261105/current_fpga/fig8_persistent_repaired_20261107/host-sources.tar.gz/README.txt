Persistent Fig. 8 host source archive

files/<absolute path without leading slash> preserves frozen source layout.
manifest.json records both builds, source hashes and parsed original commands.
SHA256SUMS covers every other archive member. Original .d, command and hash
receipts are retained byte-for-byte under files/. Binaries, objects, graph
inputs, images and experiment results are deliberately not bundled.

Extract into a new directory; from that directory run:
  sha256sum -c SHA256SUMS
  python3 build.py --dry-run
  python3 build.py --arm gr
  python3 build.py --arm spine

Rebuilds write only to rebuilt/. No FPGA is launched. Install a compatible
C++17 compiler, XRT/OpenCL and Xilinx HLS/Vitis SDK headers separately. SDK
paths retain recorded defaults and can be relocated explicitly, for example:
  python3 build.py --path-map /opt/xilinx/xrt=/new/xrt --dry-run

Source/include and output paths are relocated, and GRASU_PERSISTENT_HOST_SOURCE
and SPINE_SETUP_ONCE_HOST_SOURCE select the extracted production sources.
No source bytes, optimization flags, capacity definitions or timing logic
are rewritten. The original binary hashes are provenance, not a guarantee
that another compiler/toolchain will produce bit-identical binaries.
