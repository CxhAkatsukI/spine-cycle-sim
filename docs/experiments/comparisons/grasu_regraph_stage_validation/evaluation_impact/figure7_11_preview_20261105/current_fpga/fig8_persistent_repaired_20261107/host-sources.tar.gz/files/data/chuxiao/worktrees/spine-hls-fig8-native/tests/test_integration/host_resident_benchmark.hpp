#ifndef SPINE_HOST_RESIDENT_BENCHMARK_HPP
#define SPINE_HOST_RESIDENT_BENCHMARK_HPP

// Private host driver module: uses the smoke host's graph/state ABI helpers.
// CPU references are prepared before the resident wall window, never per round.
struct ResidentBenchmarkResult {
    unsigned iterations = 0;
    double wall_ms = 0.0;
};

struct ResidentBenchmarkSeed {
    std::vector<uint32_t> state;
    std::vector<uint32_t> active;
};

static ResidentBenchmarkSeed resident_pagerank_seed(
    const std::vector<uint32_t> &initial_state,
    const SliceWorkload &graph
) {
    const size_t span = state_span(graph.num_vertices);
    std::vector<float> rank((size_t)graph.num_vertices);
    for (int vertex = 0; vertex < graph.num_vertices; vertex++) {
        rank[(size_t)vertex] = bits_float(initial_state[(size_t)vertex]);
    }
    const auto residual = pagerank_correction_residual(
        graph.adjacency, rank, 0.85f);
    ResidentBenchmarkSeed seed{initial_state, {}};
    for (int vertex = 0; vertex < graph.num_vertices; vertex++) {
        const size_t index = (size_t)vertex;
        seed.state[span + index] = float_bits(residual[index]);
        seed.state[2ULL * span + index] =
            (uint32_t)graph.adjacency[index].size();
        if (std::fabs(residual[index]) > 1.0e-6f) {
            seed.active.push_back((uint32_t)vertex);
        }
    }
    return seed;
}

static std::vector<uint32_t> resident_pagerank_reference(
    const std::vector<uint32_t> &initial_state,
    const SliceWorkload &graph,
    unsigned iteration_limit
) {
    auto seed = resident_pagerank_seed(initial_state, graph);
    const size_t vertices = (size_t)graph.num_vertices;
    const size_t span = state_span(graph.num_vertices);
    std::vector<float> rank(vertices), residual(vertices), inverse(vertices);
    for (size_t vertex = 0; vertex < vertices; vertex++) {
        rank[vertex] = bits_float(seed.state[vertex]);
        residual[vertex] = bits_float(seed.state[span + vertex]);
        const size_t degree = graph.adjacency[vertex].size();
        inverse[vertex] = degree ? 1.0f / (float)degree : 0.0f;
    }
    unsigned iterations = 0;
    while (!seed.active.empty() && iterations < iteration_limit) {
        std::vector<float> payload(vertices, 0.0f);
        for (uint32_t source : seed.active) {
            payload[source] = residual[source];
            rank[source] += residual[source];
            residual[source] = 0.0f;
        }
        std::vector<uint8_t> touched(vertices, 0);
        for (uint32_t source : seed.active) {
            const float contribution = 0.85f * payload[source] * inverse[source];
            for (uint32_t target : graph.adjacency[source]) {
                residual[target] += contribution;
                touched[target] = 1;
            }
        }
        seed.active.clear();
        for (size_t vertex = 0; vertex < vertices; vertex++) {
            if (touched[vertex] && std::fabs(residual[vertex]) > 1.0e-6f) {
                seed.active.push_back((uint32_t)vertex);
            }
        }
        iterations++;
    }
    require(seed.active.empty(), "resident CPU PageRank reference did not converge");
    for (size_t vertex = 0; vertex < vertices; vertex++) {
        seed.state[vertex] = float_bits(rank[vertex]);
        seed.state[span + vertex] = float_bits(residual[vertex]);
    }
    return seed.state;
}

struct ResidentBenchmarkReference {
    std::vector<uint32_t> initial_state;
    std::vector<uint32_t> expected_state;
};

static ResidentBenchmarkReference prepare_resident_benchmark_reference(
    const SliceWorkload &baseline,
    const SliceWorkload &graph,
    uint32_t source,
    unsigned iteration_limit
) {
    require(baseline.num_vertices == graph.num_vertices &&
                source < (uint32_t)graph.num_vertices,
            "resident benchmark vertex domain mismatch");
    ResidentBenchmarkReference reference;
    reference.initial_state.assign(state_word_count(graph.num_vertices), 0);
    if (SPINE_ALGORITHM_KIND == kWeightedSssp ||
        SPINE_ALGORITHM_KIND == kConnectedComponents) {
        const auto initial = SPINE_ALGORITHM_KIND == kWeightedSssp
            ? weighted_sssp_distances(baseline.adjacency, baseline.weights,
                                      baseline.num_vertices, source)
            : connected_component_labels(baseline);
        const auto expected = SPINE_ALGORITHM_KIND == kWeightedSssp
            ? weighted_sssp_distances(graph.adjacency, graph.weights,
                                      graph.num_vertices, source)
            : connected_component_labels(graph);
        std::copy(initial.begin(), initial.end(), reference.initial_state.begin());
        reference.expected_state = reference.initial_state;
        std::copy(expected.begin(), expected.end(), reference.expected_state.begin());
    } else {
        const auto rank = full_pagerank_rank(baseline, 128, 0.85f);
        const size_t span = state_span(graph.num_vertices);
        for (int vertex = 0; vertex < graph.num_vertices; vertex++) {
            reference.initial_state[(size_t)vertex] = float_bits(rank[(size_t)vertex]);
            reference.initial_state[2ULL * span + (size_t)vertex] =
                (uint32_t)baseline.adjacency[(size_t)vertex].size();
        }
        reference.expected_state = resident_pagerank_reference(
            reference.initial_state, graph, iteration_limit);
    }
    return reference;
}

static void validate_resident_benchmark_state(
    const std::vector<uint32_t> &state,
    const std::vector<uint32_t> &expected,
    int num_vertices
) {
    require(state.size() == expected.size(), "resident benchmark state extent mismatch");
    const size_t span = state_span(num_vertices);
    double rank_error_l1 = 0.0;
    double expected_rank_l1 = 0.0;
    for (int vertex = 0; vertex < num_vertices; vertex++) {
        const size_t index = (size_t)vertex;
        if (SPINE_ALGORITHM_KIND == kResidualPagerank) {
            require(std::isfinite(bits_float(state[index])) &&
                        std::isfinite(bits_float(state[span + index])) &&
                        std::isfinite(bits_float(expected[index])) &&
                        std::isfinite(bits_float(expected[span + index])) &&
                        close_float(bits_float(state[index]),
                                    bits_float(expected[index]), 2.0e-5f) &&
                        close_float(bits_float(state[span + index]),
                                    bits_float(expected[span + index]), 2.0e-5f) &&
                        state[2ULL * span + index] == expected[2ULL * span + index],
                    "resident PageRank final state mismatch at vertex " +
                        std::to_string(vertex));
            expected_rank_l1 += std::abs((double)bits_float(expected[index]));
            rank_error_l1 += std::abs((double)bits_float(state[index]) -
                                      (double)bits_float(expected[index]));
        } else {
            require(state[index] == expected[index],
                    "resident final state mismatch at vertex " +
                        std::to_string(vertex));
        }
    }
    if (SPINE_ALGORITHM_KIND == kResidualPagerank) {
        // Match G+R's aggregate guard: small errors at every vertex must not hide
        // an all-zero or materially biased rank vector on a large graph.
        const double limit = 1.0e-4 + 1.0e-3 * expected_rank_l1;
        require(std::isfinite(rank_error_l1) && std::isfinite(expected_rank_l1) &&
                    rank_error_l1 <= limit,
                "resident PageRank rank L1 error exceeds aggregate limit");
    }
}

// Runtime is injectable so sequencing and rejection can be tested without a card.
template <typename Runtime>
static ResidentBenchmarkResult run_resident_benchmark(
    Runtime &runtime,
    const SliceWorkload &baseline,
    const SliceWorkload &graph,
    const std::vector<DynamicUpdate> &updates,
    size_t logical_updates,
    uint32_t source,
    unsigned iteration_limit = 256
) {
    require(SPINE_ALGORITHM_KIND != kFullPagerank && iteration_limit > 0,
            "resident benchmark requires SSSP/CC/ResPR and a positive round limit");
    require(std::all_of(updates.begin(), updates.end(),
                        [](const DynamicUpdate &update) { return update.diff > 0; }),
            "resident benchmark currently admits insertion-only batches");
    const auto reference = prepare_resident_benchmark_reference(
        baseline, graph, source, std::max(256U, iteration_limit));
    runtime.preload_resident_state(reference.initial_state);
    runtime.prepare_updates(updates, logical_updates);
    std::vector<uint32_t> state = reference.initial_state;
    std::vector<IterationResult> round_ledgers;
    std::vector<std::vector<uint32_t>> round_sources;
    round_ledgers.reserve(iteration_limit);
    round_sources.reserve(iteration_limit);
    PartitionedActiveBinFlat frontier;
    frontier.offsets.fill(0);
    frontier.counts.fill(0);

    const auto start = std::chrono::steady_clock::now();
    runtime.apply_prepared_updates();
    std::vector<uint32_t> active = dynamic_update_sources(updates);
    if (SPINE_ALGORITHM_KIND == kResidualPagerank) {
        const auto correction_start = std::chrono::steady_clock::now();
        auto seed = resident_pagerank_seed(reference.initial_state, graph);
        state = std::move(seed.state);
        active = std::move(seed.active);
        const auto correction_end = std::chrono::steady_clock::now();
        runtime.install_host_prepared_state(
            state, std::chrono::duration<double, std::milli>(
                correction_end - correction_start).count());
    }
    auto end = std::chrono::steady_clock::now();
    ResidentBenchmarkResult result;
    while (!active.empty() && result.iterations < iteration_limit) {
        auto output = runtime.run(
            SPINE_ALGORITHM_KIND, float_bits(0.85f), float_bits(1.0e-6f),
            active, frontier, state,
            SPINE_ALGORITHM_KIND != kResidualPagerank && result.iterations == 0);
        end = output.readback_completed;
        state = std::move(output.state);
        round_sources.push_back(std::move(active));
        active = sorted_unique(std::move(output.active_ids));
        IterationResult ledger;
        ledger.result = std::move(output.result);
        round_ledgers.push_back(std::move(ledger));
        result.iterations++;
    }
    require(active.empty(), "resident benchmark did not converge within the round limit");
    if (result.iterations == 0) {
        auto output = runtime.read_resident_state();
        end = output.readback_completed;
        state = std::move(output.state);
    }
    require(end >= start && end <= std::chrono::steady_clock::now(),
            "resident benchmark has an invalid readback completion timestamp");
    result.wall_ms = std::chrono::duration<double, std::milli>(end - start).count();
    // Reference edge counting and ledger validation are outside the wall window.
    for (size_t round = 0; round < round_ledgers.size(); round++) {
        validate_common("resident_benchmark", (int)round, round_ledgers[round],
                        active_edge_count(graph.adjacency, round_sources[round]));
    }
    validate_resident_benchmark_state(state, reference.expected_state, graph.num_vertices);
    return result;
}

#endif
