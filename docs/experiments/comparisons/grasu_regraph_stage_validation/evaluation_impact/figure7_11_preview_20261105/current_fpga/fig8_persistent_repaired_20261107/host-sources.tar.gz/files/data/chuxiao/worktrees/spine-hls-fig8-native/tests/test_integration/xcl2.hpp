// ============================================================================
// XCL2 — Minimal Xilinx OpenCL utility helpers
// Adapted from Xilinx Vitis examples.
// ============================================================================

#ifndef XCL2_HPP
#define XCL2_HPP

#define CL_HPP_TARGET_OPENCL_VERSION 120
#define CL_HPP_MINIMUM_OPENCL_VERSION 120
#include <CL/opencl.hpp>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace xcl {

// Aligned allocator for OpenCL host buffers (4KB alignment required by XRT)
template <typename T>
struct aligned_allocator {
    using value_type = T;

    T *allocate(std::size_t n) {
        void *ptr = nullptr;
        if (posix_memalign(&ptr, 4096, n * sizeof(T))) {
            throw std::bad_alloc();
        }
        return reinterpret_cast<T *>(ptr);
    }

    void deallocate(T *ptr, std::size_t) {
        free(ptr);
    }
};

// Get list of Xilinx devices
std::vector<cl::Device> get_xil_devices();

// Read binary file into memory
std::vector<unsigned char> read_binary_file(const std::string &xclbin_file);

} // namespace xcl

// Error checking macro
#define OCL_CHECK(error, call)                                                 \
    call;                                                                      \
    if (error != CL_SUCCESS) {                                                 \
        std::cerr << "OpenCL Error " << error << " at " << __FILE__ << ":"     \
                  << __LINE__ << " — " #call << std::endl;                     \
        exit(EXIT_FAILURE);                                                    \
    }

#endif // XCL2_HPP
