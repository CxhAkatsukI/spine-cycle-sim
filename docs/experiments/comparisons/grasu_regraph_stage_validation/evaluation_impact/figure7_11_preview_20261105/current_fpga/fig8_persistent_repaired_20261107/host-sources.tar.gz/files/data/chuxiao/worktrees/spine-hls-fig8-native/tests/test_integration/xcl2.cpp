// ============================================================================
// XCL2 — Minimal Xilinx OpenCL utility implementation
// ============================================================================

#include "xcl2.hpp"

#include <cstdlib>

namespace xcl {

static bool xcl_trace_enabled() {
    return std::getenv("SPINE_E2E_TRACE") != nullptr;
}

static void xcl_trace(const std::string &message) {
    if (xcl_trace_enabled()) {
        std::cerr << "[xcl2-trace] " << message << std::endl;
    }
}

std::vector<cl::Device> get_xil_devices() {
    std::vector<cl::Platform> platforms;
    xcl_trace("before_platform_get");
    cl::Platform::get(&platforms);
    xcl_trace("after_platform_get count=" + std::to_string(platforms.size()));

    std::vector<cl::Device> devices;
    for (auto &platform : platforms) {
        std::string name = platform.getInfo<CL_PLATFORM_NAME>();
        xcl_trace("platform=" + name);
        if (name.find("Xilinx") != std::string::npos) {
            std::vector<cl::Device> plat_devices;
            xcl_trace("before_get_devices");
            platform.getDevices(CL_DEVICE_TYPE_ACCELERATOR, &plat_devices);
            xcl_trace("after_get_devices count=" +
                      std::to_string(plat_devices.size()));
            devices.insert(devices.end(), plat_devices.begin(), plat_devices.end());
        }
    }
    if (devices.empty()) {
        std::cerr << "ERROR: No Xilinx devices found." << std::endl;
        exit(EXIT_FAILURE);
    }
    if (const char *env = std::getenv("XCL_DEVICE_INDEX")) {
        char *end = nullptr;
        long requested = std::strtol(env, &end, 10);
        if (end != env && *end == '\0' && requested >= 0 &&
            requested < static_cast<long>(devices.size())) {
            std::swap(devices[0], devices[static_cast<size_t>(requested)]);
            std::cerr << "Using XCL_DEVICE_INDEX=" << requested << std::endl;
        } else {
            std::cerr << "ERROR: invalid XCL_DEVICE_INDEX=" << env
                      << " for " << devices.size() << " Xilinx device(s)."
                      << std::endl;
            exit(EXIT_FAILURE);
        }
    }
    xcl_trace("return_devices count=" + std::to_string(devices.size()));
    return devices;
}

std::vector<unsigned char> read_binary_file(const std::string &xclbin_file) {
    std::ifstream bin_file(xclbin_file, std::ifstream::binary);
    if (!bin_file.is_open()) {
        std::cerr << "ERROR: Cannot open xclbin file: " << xclbin_file << std::endl;
        exit(EXIT_FAILURE);
    }
    bin_file.seekg(0, bin_file.end);
    size_t nb = bin_file.tellg();
    bin_file.seekg(0, bin_file.beg);

    std::vector<unsigned char> buf(nb);
    bin_file.read(reinterpret_cast<char *>(buf.data()), nb);
    return buf;
}

} // namespace xcl
