#ifndef CL_EXT_XILINX_STUB_H
#define CL_EXT_XILINX_STUB_H
// Stub for emulation builds without XRT installed
#ifndef CL_MEM_EXT_PTR_XILINX
#define CL_MEM_EXT_PTR_XILINX (1 << 31)
#endif
#ifndef XCL_MEM_TOPOLOGY
#define XCL_MEM_TOPOLOGY (1 << 31)
#endif
typedef struct { unsigned flags; void *obj; void *param; } cl_mem_ext_ptr_t;
#endif
