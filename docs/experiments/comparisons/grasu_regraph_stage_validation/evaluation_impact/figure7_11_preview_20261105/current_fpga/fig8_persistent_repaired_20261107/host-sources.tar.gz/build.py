#!/usr/bin/env python3
"""Rebuild archived hosts into rebuilt/, never the original build directory."""
import argparse
import json
import os
from pathlib import Path
import shlex
import subprocess

root = Path(__file__).resolve().parent
manifest = json.loads((root / "manifest.json").read_text())
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--arm", choices=("gr", "spine", "all"), default="all")
parser.add_argument("--dry-run", action="store_true")
parser.add_argument("--cxx", default="g++", help="C++ compiler executable")
parser.add_argument("--path-map", action="append", default=[], metavar="OLD=NEW",
                    help="relocate an external SDK prefix, not archived sources")
args = parser.parse_args()
sdk_maps = []
for item in args.path_map:
    old, separator, new = item.partition("=")
    if not separator or not Path(old).is_absolute() or not Path(new).is_absolute():
        parser.error("--path-map requires absolute OLD=NEW paths")
    sdk_maps.append((Path(old), Path(new)))
sdk_maps.sort(key=lambda pair: len(str(pair[0])), reverse=True)
build_root = Path(manifest["build_root"])
sources = {Path(path) for arm in manifest["builds"].values() for path in arm["sources"]}

def relocate(value):
    if not value.startswith("/"):
        return value
    path = Path(os.path.normpath(value))
    if path.is_relative_to(build_root):
        return str(root / "rebuilt" / path.relative_to(build_root))
    if any(source == path or path in source.parents for source in sources):
        return str(root / "files" / path.relative_to("/"))
    for old, new in sdk_maps:
        if path.is_relative_to(old):
            return str(new / path.relative_to(old))
    return value

def argument(value):
    for prefix in ("-I", "-L", "-isystem", "-iquote", "-Wl,-rpath,"):
        if value.startswith(prefix + "/"):
            return prefix + relocate(value[len(prefix):])
    return relocate(value)

for arm, build in manifest["builds"].items():
    if args.arm not in (arm, "all"):
        continue
    work = root / "rebuilt" / arm
    if not args.dry_run:
        work.mkdir(parents=True, exist_ok=True)
    for recorded, compiler in zip(build["commands"], build["compiler_indices"]):
        command = [argument(value) for value in recorded]
        command[compiler] = args.cxx
        if any(Path(value).name == arm + "_persistent.cpp" for value in recorded):
            name, source = build["source_macro"]
            command.insert(compiler + 1, '-D' + name + '="' + relocate(source) + '"')
        print(shlex.join(command), flush=True)
        if not args.dry_run:
            subprocess.run(command, cwd=work, check=True)
