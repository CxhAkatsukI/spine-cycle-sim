#pragma once

// Included by the partitioned algorithm host after its input types.
struct SetupInsertionBatch {
    int vertices = 0;
    std::vector<DynamicUpdate> old_edges;
    std::vector<DynamicUpdate> inserts;
};

static SetupInsertionBatch read_setup_insertion_batch(const std::string &path) {
    std::ifstream in(path);
    uint64_t vertices = 0, edges = 0, updates = 0;
    require(static_cast<bool>(in >> vertices >> edges >> updates) &&
                vertices > 0 && vertices <= MAX_N && edges > 0 && updates > 0 &&
                updates <= HOST_PARTITIONED_RATIO2_MAX_SORT_N,
            "invalid update-setup graph header");
    SetupInsertionBatch batch;
    batch.vertices = (int)vertices;
    auto read_edges = [&](auto &out, uint64_t count, bool update) {
        for (uint64_t i = 0; i < count; ++i) {
            uint64_t src = 0, dst = 0, weight = 0, type = 1;
            require(static_cast<bool>(in >> src >> dst >> weight) &&
                        (!update || static_cast<bool>(in >> type)) &&
                        src < vertices && dst < vertices &&
                        weight > 0 && weight <= 0x0fffU && type == 1,
                    "update setup requires valid weight12 edges and inserts only");
            out.push_back({(uint32_t)src, (uint32_t)dst, (uint16_t)weight, 1});
        }
    };
    read_edges(batch.old_edges, edges, false);
    read_edges(batch.inserts, updates, true);
    std::string trailing;
    require(!(in >> trailing), "unexpected trailing update-setup input");
    return batch;
}

static SliceWorkload setup_baseline_workload(const SetupInsertionBatch &batch) {
    SliceWorkload workload;
    workload.num_vertices = batch.vertices;
    workload.adjacency.resize((size_t)batch.vertices);
    workload.weights.resize((size_t)batch.vertices);
    for (const DynamicUpdate &edge : batch.old_edges) {
        workload.adjacency[edge.src].push_back(edge.dst);
        workload.weights[edge.src].push_back(edge.weight);
    }
    return workload;
}

template <typename Banks, typename Meta>
static size_t check_setup_updated_graph(
    const Banks &banks, const Meta &meta, const SetupInsertionBatch &batch
) {
    using Edge = std::tuple<uint32_t, uint32_t, uint16_t>;
    struct ImageView {
        const Banks &graph_words;
        const Meta &meta_words;
    } view{banks, meta};
    std::vector<Edge> expected, observed;
    const size_t expected_count = batch.old_edges.size() + batch.inserts.size();
    expected.reserve(expected_count);
    observed.reserve(expected_count);
    for (const auto *set : {&batch.old_edges, &batch.inserts}) {
        for (const auto &edge : *set) expected.emplace_back(edge.src, edge.dst, edge.weight);
    }
    std::sort(expected.begin(), expected.end());
    for (size_t i = 1; i < expected.size(); ++i) {
        require(std::get<0>(expected[i - 1]) != std::get<0>(expected[i]) ||
                    std::get<1>(expected[i - 1]) != std::get<1>(expected[i]),
                "update setup expects unique old and inserted endpoints");
    }
    validate_partitioned_page_list_metadata_host(meta);
    for (int family = 0; family < HOST_PARTITIONED_CSR_FAMILY_COUNT; ++family) {
        const int bank = family < HOST_PARTITIONED_HOT_FAMILY_BASE
            ? family : family - HOST_PARTITIONED_HOT_FAMILY_BASE;
        for (int level = 0; level < HOST_PARTITIONED_RATIO2_LEVELS; ++level) {
            const size_t base = ((size_t)family * HOST_PARTITIONED_RATIO2_LEVELS + level) *
                HOST_PARTITIONED_META_WORDS_PER_SLICE;
            if (!meta.at(base + HOST_PARTITIONED_META_OCCUPIED_WORD)) continue;
            const size_t bitmap = meta.at(base + HOST_PARTITIONED_META_PAGE_BITMAP_OFFSET_WORD);
            const size_t before = observed.size();
            const uint32_t pages = partitioned_page_list_count_host(meta, family, level);
            for (uint32_t i = 0; i < pages; ++i) {
                const uint32_t page = partitioned_page_list_id_host(meta, family, level, i);
                for (uint32_t word = 0; word < 4; ++word) {
                    uint64_t bits = banks.at((size_t)bank).at(bitmap + (size_t)page * 4 + word);
                    while (bits) {
                        const uint32_t src = page * PAGE_CSR_VERTICES_PER_PAGE +
                            word * 64 + (uint32_t)__builtin_ctzll(bits);
                        require(src < (uint32_t)batch.vertices,
                                "update setup graph has an out-of-domain source");
                        const auto row = partitioned_range_task_lookup_row_host(
                            view, bank, family, level, src);
                        require(row.present, "update setup listed graph row is not visible");
                        for (uint32_t e = row.start; e < row.end; ++e) {
                            const uint64_t payload = banks.at((size_t)bank).at(row.edge_offset + e);
                            require((uint16_t)payload == 1 && observed.size() < expected_count,
                                    "update setup graph has invalid multiplicity or extent");
                            observed.emplace_back(src, (uint32_t)(payload >> 32),
                                                  (uint16_t)(payload >> 16));
                        }
                        bits &= bits - 1;
                    }
                }
            }
            require(observed.size() - before == meta.at(base + HOST_PARTITIONED_META_EDGE_COUNT_WORD),
                    "update setup graph edge count differs from slice metadata");
        }
    }
    std::sort(observed.begin(), observed.end());
    require(observed == expected, "update setup graph differs from expected weighted edges");
    return observed.size();
}
