open_project -reset project
set_top cache_bank_probe
add_files ../source/cache_bank.cpp -cflags {-D_GTHREAD_USE_COND_INIT_FUNC -I/data/yxx/tools/xilinx/Vitis_HLS/2024.1/include/etc -DCACHE_BANK_REGISTERED}
add_files -tb ../source/cache_bank_control.cpp -cflags {-D_GTHREAD_USE_COND_INIT_FUNC -I/data/yxx/tools/xilinx/Vitis_HLS/2024.1/include/etc -DCACHE_BANK_REGISTERED}
open_solution -reset solution -flow_target vitis
set_part {xcu55c-fsvh2892-2L-e}
create_clock -period 5 -name default
csim_design
csynth_design
cosim_design -rtl verilog -tool xsim
exit
