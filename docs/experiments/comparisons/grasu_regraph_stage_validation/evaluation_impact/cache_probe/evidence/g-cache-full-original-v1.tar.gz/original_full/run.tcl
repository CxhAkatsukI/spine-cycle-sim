open_project -reset project
set_top process_cache
add_files ../source/upstream/kernel_process_cache.cpp -cflags {-D_GTHREAD_USE_COND_INIT_FUNC -I/data/yxx/tools/xilinx/Vitis_HLS/2024.1/include/etc}
add_files -tb ../source/cache_full_control.cpp -cflags {-D_GTHREAD_USE_COND_INIT_FUNC -I/data/yxx/tools/xilinx/Vitis_HLS/2024.1/include/etc}
open_solution -reset solution -flow_target vitis
set_part {xcu55c-fsvh2892-2L-e}
create_clock -period 5 -name default
set_directive_interface -mode m_axi -depth 131072 process_cache pma_cache
config_rtl -deadlock_detection sim
csim_design
csynth_design
cosim_design -rtl verilog -tool xsim
exit
