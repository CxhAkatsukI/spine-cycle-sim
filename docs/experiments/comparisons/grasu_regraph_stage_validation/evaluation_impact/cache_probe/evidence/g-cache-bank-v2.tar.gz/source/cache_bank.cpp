#include "cache_bank.hpp"
#include "upstream/kernel_process_cache.cpp"

namespace {
void lane_update(CacheWord* cache, hls::stream<CacheUpdate>& updates) {
#pragma HLS INLINE off
  candidate_updates:
  while (true) {
#pragma HLS PIPELINE II=1
    const CacheUpdate info = updates.read();
    if (info == END_EDGE) break;
    const ap_uint<23> address = info.range(31, 9);
    const ap_uint<32> key = info.range(63, 32);
    const bool erase = info[95];
    const CacheWord before = cache[address];
    ap_uint<32> words[16];
    ap_uint<1> less[16];
#pragma HLS ARRAY_PARTITION variable=words complete
#pragma HLS ARRAY_PARTITION variable=less complete
    for (unsigned i = 0; i < 16; ++i) {
#pragma HLS UNROLL
      words[i] = before.range(i * 32 + 31, i * 32);
      less[i] = words[i] < key;
    }
    // Sorted inputs make the insertion boundary local. Static lane wiring
    // avoids the original data-dependent 512-bit shifts and prefix sum.
    CacheWord after = 0;
    for (unsigned i = 0; i < 16; ++i) {
#pragma HLS UNROLL
      const ap_uint<32> next = i == 15 ? ap_uint<32>(0x80000000u) : words[i + 1];
      const ap_uint<32> previous = i == 0 ? ap_uint<32>(0) : words[i - 1];
      const bool boundary = !less[i] && (i == 0 || less[i - 1]);
      const ap_uint<32> value = erase ? (less[i] ? words[i] : next)
          : (less[i] ? words[i] : boundary ? key : previous);
      after.range(i * 32 + 31, i * 32) = value;
    }
    cache[address] = after;
  }
}
}  // namespace

extern "C" void cache_bank_probe(CacheWord* memory,
                                  hls::stream<CacheUpdate>& updates) {
#pragma HLS INTERFACE m_axi port=memory offset=slave bundle=gmem0 num_read_outstanding=16 num_write_outstanding=16 max_read_burst_length=16 max_write_burst_length=16
#pragma HLS INTERFACE s_axilite port=memory bundle=control
#pragma HLS INTERFACE s_axilite port=return bundle=control
#pragma HLS INTERFACE axis port=updates
  CacheWord cache[cache_bank_depth];
#pragma HLS BIND_STORAGE variable=cache type=RAM_1P impl=URAM
  preload:
  for (unsigned i = 0; i < cache_bank_depth; ++i) {
#pragma HLS PIPELINE II=1
    cache[i] = memory[i];
  }
#ifdef CACHE_BANK_CANDIDATE
  lane_update(cache, updates);
#else
  process_1(cache, updates);
#endif
  writeback:
  for (unsigned i = 0; i < cache_bank_depth; ++i) {
#pragma HLS PIPELINE II=1
    memory[i] = cache[i];
  }
}
