"""Read-only export and portable packaging of the fixed host follow-up."""

import csv
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess


ROOT = Path('/data/chuxiao/checks/spine-cc-respr-host-20261026')
SIM = Path('/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3')
INTEGRATION = Path('/home/chuxiao/grasu-regraph-sim-aligned')
EXPORTER = Path('/home/chuxiao/grasu-regraph-delivery-review')
RUNTIME = Path('/home/chuxiao/spine-cycle-sim/spine-cycle-sim-production-board')
PRIOR = Path('/data/chuxiao/builds/grasu-cache-extent-20261025/terminal-delivery-v1/evidence')
OLD_PACKAGE = SIM / 'docs/experiments/comparisons/grasu_regraph_stage_validation/evaluation_impact/cache_extent/fpga_results_v1'
ARCHIVER = Path('/data/chuxiao/builds/grasu-cache-extent-20261025/final-roundtrip-review-v2/unpacked/validation/package-fpga-delivery.py')
PYTHON = '/data/tmp/chuxiao/spine-cycle-sim-eval-venv/bin/python'
TERMINAL = ROOT / 'terminal-delivery-v1'
PACKAGE = ROOT / 'portable-delivery-v1'


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def compare(before, after):
    for field in ('workloads', 'boundary', 'repeats', 'memory_gib', 'build_root',
                  'route_directory', 'spine_directory'):
        if read(PRIOR / 'plan.json')[field] != read(TERMINAL / 'evidence/plan.json')[field]:
            raise ValueError('host-only contract changed: ' + field)
    previous = {(row['algorithm'], row['dataset']): row for row in before}
    rows = []
    for row in after:
        key = row['algorithm'], row['dataset']
        old = previous[key]
        if old['status'] != 'RESIDENT_PAIR_PASS' or row['status'] != 'RESIDENT_PAIR_PASS':
            raise ValueError('all fixed comparisons must pass before publishing a full plot')
        for field in ('batch_size', 'input_update_records', 'logical_updates', 'physical_updates',
                      'gr_data_mhz', 'spine_data_mhz', 'gr_rounds_samples', 'spine_rounds_samples'):
            if row[field] != old[field]:
                raise ValueError('workload, clock or propagation count changed: ' + str(key))
        old_wall, new_wall = float(old['spine_ms']), float(row['spine_ms'])
        rows.append({'algorithm': key[0], 'dataset': key[1],
            'prior_spine_ms': old_wall, 'new_spine_ms': new_wall,
            'spine_wall_reduction_ratio': old_wall / new_wall,
            'prior_gr_ms': float(old['gr_ms']), 'new_gr_ms': float(row['gr_ms']),
            'prior_gr_over_spine': float(old['speedup_gr_over_spine']),
            'new_gr_over_spine': float(row['speedup_gr_over_spine']),
            'propagation_scope': row['propagation_scope']})
    with (TERMINAL / 'comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return rows


def main():
    import sys
    sys.path.insert(0, str(SIM))
    from spine_cycle_sim.experiments.evaluation_impact import fpga_plot, fpga_profile
    digest = fpga_plot.digest
    matrix = ROOT / 'full-matrix-v2/results.json'
    report = read(matrix)
    if report['status'] != 'FPGA_MATRIX_PASS' or report['passed_cases'] != 24:
        raise ValueError('complete 24-case terminal matrix required; never restart board jobs here')
    TERMINAL.mkdir(exist_ok=False)
    pins = {str(path): digest(path) for path in (
        matrix, ROOT / 'full-inputs-v1/plan.json',
        PRIOR / 'plan.json', PRIOR / 'summary.csv',
        EXPORTER / 'validation/cache_extent/delivery.py',
        Path(fpga_plot.__file__), Path(fpga_profile.__file__), ARCHIVER,
        OLD_PACKAGE / 'review/review-fpga-delivery-v2.py', Path(__file__))}
    state = {'status': 'EXPORTING', 'source_pins': pins, 'stages': [],
             'scope': 'host_only_fixed_inputs_and_bitstreams_no_timing_fit'}
    save(TERMINAL / 'state.json', state)
    stages = (
        ('evidence', EXPORTER, RUNTIME, 'validation.cache_extent.delivery',
         ['--matrix', str(matrix), '--output', str(TERMINAL / 'evidence')]),
        ('figure', SIM, SIM, 'spine_cycle_sim.experiments.evaluation_impact.fpga_plot',
         ['--delivery', str(TERMINAL / 'evidence'), '--output', str(TERMINAL / 'figure')]),
        ('profile', SIM, SIM, 'spine_cycle_sim.experiments.evaluation_impact.fpga_profile',
         ['--delivery', str(TERMINAL / 'evidence'), '--output', str(TERMINAL / 'profile')]))
    try:
        for name, cwd, pythonpath, module, arguments in stages:
            command = [PYTHON, '-B', '-m', module, *arguments]
            with (TERMINAL / (name + '.log')).open('w') as stream:
                result = subprocess.run(command, cwd=cwd,
                    env=os.environ | {'PYTHONPATH': str(pythonpath)},
                    stdout=stream, stderr=subprocess.STDOUT, timeout=1800)
            state['stages'].append({'name': name, 'command': command,
                                    'cwd': str(cwd), 'exit_code': result.returncode})
            save(TERMINAL / 'state.json', state)
            result.check_returncode()
        before = fpga_plot.load_delivery(PRIOR)
        after = fpga_plot.load_delivery(TERMINAL / 'evidence')
        comparisons = compare(before, after)
        state['wins'] = {algorithm: sum(row['new_gr_over_spine'] > 1 for row in comparisons
            if row['algorithm'] == algorithm) for algorithm in ('sssp', 'cc', 'respr')}
        for path, expected in pins.items():
            if digest(Path(path)) != expected:
                raise ValueError('export source changed: ' + path)
        state['status'] = 'RAW_REPARSE_PLOT_PROFILE_AND_CONTRACT_PASS_NOT_YET_REVIEWED'
        save(TERMINAL / 'state.json', state)
        spec = importlib.util.spec_from_file_location('frozen_archive', ARCHIVER)
        archive_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(archive_module)
        selected = [(path, str(path.relative_to(TERMINAL)))
            for path in sorted((TERMINAL / 'evidence').rglob('*')) if path.is_file()]
        selected += [(TERMINAL / name, 'validation/' + name)
            for name in ('state.json', 'evidence.log', 'figure.log', 'profile.log')]
        selected += [(Path(__file__), 'validation/finalize-host-followup.py'),
            (ARCHIVER, 'validation/archive-implementation.py'),
            (PRIOR / 'summary.csv', 'validation/prior-summary.csv'),
            (ROOT / 'au-matrix-v1/results.json', 'validation/au-gate-results.json'),
            (ROOT / 'full-matrix-v1/results.json', 'validation/retained-pin-schema-failure.json')]
        for name in ('host_followup.py', 'host_matrix.py'):
            selected.append((INTEGRATION / 'validation/cache_extent' / name, 'validation/runtime/' + name))
        for directory in ('default-hosts-v1', 'regression-v1'):
            selected += [(path, 'validation/' + directory + '/' + path.name)
                for path in sorted((ROOT / directory).iterdir())
                if path.is_file() and path.suffix not in ('.host', '.test')]
        records = [{'path': name, 'source': str(path), 'bytes': path.stat().st_size,
                    'sha256': digest(path)} for path, name in selected]
        if any(row['bytes'] > 16 * 1024**2 for row in records) or sum(
                row['bytes'] for row in records) > 256 * 1024**2:
            raise ValueError('portable archive exceeds its finite size budget')
        PACKAGE.mkdir(exist_ok=False)
        archive = PACKAGE / 'raw_evidence.tar.gz'
        archive_module.archive_records(records, archive)
        sources = [(TERMINAL / 'evidence/summary.csv', Path('summary.csv')),
                   (TERMINAL / 'comparison.csv', Path('comparison.csv'))]
        sources += [(Path(module.__file__), Path('code/board_review') / Path(module.__file__).name)
            for module in (fpga_plot, fpga_profile)]
        sources += [(path, path.relative_to(TERMINAL)) for name in ('figure', 'profile')
            for path in sorted((TERMINAL / name).iterdir()) if path.is_file()]
        reviewer = OLD_PACKAGE / 'review/review-fpga-delivery-v2.py'
        sources.append((reviewer, Path('review/review-fpga-delivery-v2.py')))
        copies = []
        for source, relative in sources:
            target = PACKAGE / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            if digest(source) != digest(target):
                raise ValueError('copy changed: ' + str(relative))
            copies.append({'path': str(relative), 'sha256': digest(target), 'bytes': target.stat().st_size})
        save(PACKAGE / 'manifest.json', {'schema': 'cache_extent_host_followup_archive_v1',
            'status': state['status'], 'passed_cases': 24, 'paired_runs': 96,
            'source': str(TERMINAL), 'source_pins': pins,
            'archive': {'path': archive.name, 'sha256': digest(archive), 'bytes': archive.stat().st_size},
            'archive_members': records, 'readable_artifacts': copies})
        print(json.dumps({'status': state['status'], 'wins': state['wins'], 'package': str(PACKAGE)}))
    except BaseException as error:
        state.update(status='FAILED_RETAINED', error=repr(error))
        save(TERMINAL / 'state.json', state)
        raise


if __name__ == '__main__':
    main()
