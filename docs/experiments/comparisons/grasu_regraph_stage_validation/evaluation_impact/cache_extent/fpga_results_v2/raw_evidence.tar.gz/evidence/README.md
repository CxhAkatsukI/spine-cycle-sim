# Revised G+R Versus Spine: Resident FPGA Results

Status: **FPGA_MATRIX_PASS**, 24/24 correctness-admitted pairs.

These are FPGA wall-time measurements, not simulator predictions. Ratios above one favor Spine.
One warmup pair is excluded; values are the medians of three alternating-order measured pairs.

Both systems start with the same resident converged old graph and apply eight logical updates
until new convergence. Timing includes updates, propagation, host launch/wait, inter-round
relaunch and final readback. Initial graph/PMA creation, initial residency, old-state preload,
batch preparation/upload and CPU oracles are excluded symmetrically. This is not application
setup-inclusive latency. Actual DATA clocks are in the CSV; HBM/system clocks remain in each manifest.

The frozen batch size is eight. CC encodes eight undirected insertions as sixteen reciprocal
directed records; SSSP and ResPR each encode eight directed insertions. Both hosts' raw
`logical_updates` and `physical_updates` fields count input records in this matrix. Those
fields are preserved verbatim, not divided by two. `batch_size` and `input_update_records`
in the CSV distinguish the declared batch size from its encoded record count.

The G+R hosts use GCC 15.2 -O2; Spine uses GCC 15.2 -O3. The earlier approximately 2.47x
ReGraph publication-scale gap remains a limitation, not a successful reproduction claim.
Source changes, HLS export, routed artifacts and FPGA measurement are separate gates.
The bounded-cache simulator component passed regression, but this package does not claim
new full-system simulator timing calibration or promotion of the production SST plugin.

## Propagation Scope

The CSV round-count columns retain all three formal samples, in run order, separated by semicolons.
The excluded warmup remains in each copied raw report. Missing or failed cases have blank counts,
not zero. `no_propagation_rounds` means both systems performed zero propagation rounds in every
formal sample. These are update/correction/completion measurements, not evidence of iterative
propagation performance. `includes_propagation_rounds` means at least one formal sample propagated;
the individual counts, rather than that label alone, determine the workload's propagation coverage.

ResPR uses the correctness-checked direct per-vertex epsilon of 1e-6, not epsilon divided by V.
Zero-round cases are retained as measured; neither the threshold nor batch was changed to force work.

| ResPR dataset | G+R formal rounds | Spine formal rounds | Scope or status |
| --- | --- | --- | --- |
| AU | 0;0;0 | 0;0;0 | no_propagation_rounds |
| SU | 0;0;0 | 0;0;0 | no_propagation_rounds |
| WK | 0;0;0 | 0;0;0 | no_propagation_rounds |
| SO | 0;0;0 | 0;0;0 | no_propagation_rounds |
| PK | 0;0;0 | 0;0;0 | no_propagation_rounds |
| LJ | 0;0;0 | 0;0;0 | no_propagation_rounds |
| LJ08 | 0;0;0 | 0;0;0 | no_propagation_rounds |
| R19 | 0;0;0 | 0;0;0 | no_propagation_rounds |

## Results

| Algorithm | Dataset | Status | G+R ms | Spine ms | G+R / Spine |
| --- | --- | --- | ---: | ---: | ---: |
| sssp | AU | RESIDENT_PAIR_PASS | 18.3519 | 4.21358 | 4.35542 |
| sssp | SU | RESIDENT_PAIR_PASS | 27.705 | 4.43167 | 6.2516 |
| sssp | WK | RESIDENT_PAIR_PASS | 27.2573 | 3.83945 | 7.09926 |
| sssp | SO | RESIDENT_PAIR_PASS | 714.618 | 15.5383 | 45.9907 |
| sssp | PK | RESIDENT_PAIR_PASS | 617.042 | 8.3189 | 74.1735 |
| sssp | LJ | RESIDENT_PAIR_PASS | 2885.39 | 29.907 | 96.4789 |
| sssp | LJ08 | RESIDENT_PAIR_PASS | 1846.81 | 20.29 | 91.0208 |
| sssp | R19 | RESIDENT_PAIR_PASS | 78.5128 | 4.02376 | 19.5123 |
| cc | AU | RESIDENT_PAIR_PASS | 11.7999 | 3.05053 | 3.86813 |
| cc | SU | RESIDENT_PAIR_PASS | 15.347 | 2.84689 | 5.39081 |
| cc | WK | RESIDENT_PAIR_PASS | 75.3839 | 7.54539 | 9.99072 |
| cc | SO | RESIDENT_PAIR_PASS | 823.217 | 25.2154 | 32.6474 |
| cc | PK | RESIDENT_PAIR_PASS | 303.919 | 5.27981 | 57.5624 |
| cc | LJ | RESIDENT_PAIR_PASS | 961.402 | 12.2275 | 78.6262 |
| cc | LJ08 | RESIDENT_PAIR_PASS | 922.309 | 12.0289 | 76.6744 |
| cc | R19 | RESIDENT_PAIR_PASS | 91.615 | 5.6908 | 16.0988 |
| respr | AU | RESIDENT_PAIR_PASS | 21.6619 | 7.0269 | 3.08271 |
| respr | SU | RESIDENT_PAIR_PASS | 27.7409 | 8.00611 | 3.46496 |
| respr | WK | RESIDENT_PAIR_PASS | 53.2455 | 13.0845 | 4.06936 |
| respr | SO | RESIDENT_PAIR_PASS | 870.747 | 155.799 | 5.58891 |
| respr | PK | RESIDENT_PAIR_PASS | 334.101 | 100.423 | 3.32693 |
| respr | LJ | RESIDENT_PAIR_PASS | 1023.61 | 200.919 | 5.09462 |
| respr | LJ08 | RESIDENT_PAIR_PASS | 983.11 | 218.772 | 4.49377 |
| respr | R19 | RESIDENT_PAIR_PASS | 45.1511 | 30.2718 | 1.49152 |

## Evidence

`summary.csv` retains every declared case, including failures.
`cases/` contains copied board reports, manifests and raw paired logs; `files.json` records hashes
and original locations. The frozen plan and case manifests identify hosts, bitstreams, workloads
and source pins. Large binaries, graphs and compiler trees stay at those indexed locations.
Passing rows were rechecked against raw logs, binary/source hashes and recomputed medians.
Their saved cgroup limits match the frozen per-dataset budgets, enforce zero swap and group
OOM termination, and agree with the recorded admission and per-process memory policies.
Post-run OOM counters must be present and zero. Pressure counters (`high`/`max`) remain in
the copied reports; nonzero pressure alone is not treated as an OOM or hidden from review.
Incomplete rows are not speedups and may require another build or run. No paper was modified.
