"""Synthetic archive checks; these do not constitute additional board evidence."""

import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import unittest


SOURCE = Path(__file__).with_name("package-fpga-delivery.py")
spec = importlib.util.spec_from_file_location("fpga_archive_recipe", SOURCE)
recipe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recipe)


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source = self.root / "raw.log"
        self.source.write_bytes(b"original bytes  \r\n\x00\xff\n")
        self.row = {"path": "evidence/raw.log", "source": str(self.source),
                    "bytes": self.source.stat().st_size, "sha256": recipe.digest(self.source)}

    def test_byte_exact_and_deterministic_archive(self):
        first, second = self.root / "first.tar.gz", self.root / "second.tar.gz"
        recipe.archive_records([self.row], first)
        recipe.archive_records([self.row], second)
        self.assertEqual(first.read_bytes(), second.read_bytes())
        with tarfile.open(first, "r:gz") as archive:
            member = archive.getmember(self.row["path"])
            self.assertEqual(archive.extractfile(member).read(), self.source.read_bytes())
            self.assertEqual((member.uid, member.gid, member.mode, member.mtime), (0, 0, 0o644, 0))

    def test_changed_source_is_rejected(self):
        self.source.write_bytes(b"changed raw evidence")
        with self.assertRaisesRegex(ValueError, "source changed"):
            recipe.archive_records([self.row], self.root / "changed.tar.gz")

    def test_duplicate_member_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "duplicate archive member"):
            recipe.archive_records([self.row, self.row], self.root / "duplicate.tar.gz")

    def test_path_traversal_is_rejected(self):
        for index, name in enumerate(("../escape", "/absolute")):
            with self.subTest(path=name), self.assertRaisesRegex(ValueError, "unsafe archive path"):
                recipe.archive_records([self.row | {"path": name}], self.root / f"unsafe-{index}.tar.gz")

    def test_symlink_source_is_rejected(self):
        link = self.root / "link.log"
        link.symlink_to(self.source)
        with self.assertRaisesRegex(ValueError, "unsafe archive path"):
            recipe.archive_records([self.row | {"source": str(link)}], self.root / "symlink.tar.gz")

    def test_waiting_delivery_is_not_released(self):
        terminal = self.root / "terminal"
        terminal.mkdir()
        (terminal / "state.json").write_text(json.dumps({"status": "WAITING_FOR_TERMINAL_MATRIX"}))
        output = self.root / "not-a-release"
        with self.assertRaisesRegex(ValueError, "all 24 cases"):
            recipe.package(terminal, output)
        self.assertFalse(output.exists())

    def test_bundled_modules_import_without_simulator_checkout(self):
        code = self.root / "code"
        package = code / "board_review"
        package.mkdir(parents=True)
        for module in (recipe.fpga_plot, recipe.fpga_profile):
            source = Path(module.__file__)
            target = package / source.name
            shutil.copyfile(source, target)
            self.assertEqual(recipe.digest(source), recipe.digest(target))
        command = [sys.executable, "-c", (
            "import sys; from pathlib import Path; "
            "from board_review import fpga_plot, fpga_profile; "
            "assert 'spine_cycle_sim' not in sys.modules; "
            "assert all(Path(module.__file__).is_relative_to(Path.cwd()) "
            "for module in (fpga_plot, fpga_profile))"
        )]
        subprocess.run(command, cwd=self.root, env=os.environ | {"PYTHONPATH": str(code)},
                       check=True, capture_output=True, timeout=10)


if __name__ == "__main__":
    unittest.main(verbosity=2)
