#!/usr/bin/env python3
"""Archive a completed 24-case delivery; never launch or alter FPGA runs."""

import argparse
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

from spine_cycle_sim.experiments.evaluation_impact import fpga_plot, fpga_profile
from spine_cycle_sim.experiments.evaluation_impact.fpga_plot import digest, load_delivery
from spine_cycle_sim.experiments.evaluation_impact.fpga_profile import inspect


def archive_records(records, destination):
    """Preserve source bytes with deterministic, unprivileged tar metadata."""
    if len({row["path"] for row in records}) != len(records):
        raise ValueError("duplicate archive member")
    with destination.open("xb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w|", format=tarfile.PAX_FORMAT) as archive:
                for row in sorted(records, key=lambda item: item["path"]):
                    relative = Path(row["path"])
                    source = Path(row["source"])
                    if relative.is_absolute() or ".." in relative.parts or source.is_symlink():
                        raise ValueError("unsafe archive path")
                    if digest(source) != row["sha256"] or source.stat().st_size != row["bytes"]:
                        raise ValueError("source changed before archive: " + str(source))
                    member = tarfile.TarInfo(relative.as_posix())
                    member.size, member.mode, member.mtime = row["bytes"], 0o644, 0
                    with source.open("rb") as stream:
                        archive.addfile(member, stream)
    expected = {row["path"]: row for row in records}
    with tarfile.open(destination, "r:gz") as archive:
        actual = archive.getmembers()
        if len(actual) != len(expected) or {member.name for member in actual} != set(expected):
            raise ValueError("archive member set differs from source index")
        for member in actual:
            row = expected[member.name]
            if not member.isfile() or member.size != row["bytes"]:
                raise ValueError("archive member is not the indexed regular file")
            with archive.extractfile(member) as stream:
                if hashlib.file_digest(stream, "sha256").hexdigest() != row["sha256"]:
                    raise ValueError("archive payload hash mismatch: " + member.name)
            if digest(Path(row["source"])) != row["sha256"]:
                raise ValueError("source changed during archive: " + row["source"])


def describe(rows):
    datasets = ("AU", "SU", "WK", "SO", "PK", "LJ", "LJ08", "R19")
    by_key = {(row["algorithm"], row["dataset"]): row for row in rows}
    lines = [
        "# Revised G+R Versus Spine: 24 FPGA Comparisons", "",
        "All three algorithms on all eight full-graph workloads pass their recorded correctness gates.",
        "These are actual resident FPGA wall times, not simulator predictions or fitted cycles.",
        "The package does not establish original-publication performance reproduction or new simulator timing calibration.", "",
        "## Read This First", "",
        "- `figure/fpga_speedup.png` is the preview; the PDF is vector output with TX Typewriter (txtt).",
        "- `summary.csv` contains all 24 measured ratios, actual DATA clocks and formal propagation counts.",
        "- `profile/` retains event diagnostics and every formal wall sample, including outliers.",
        "- `code/board_review/` contains byte-identical snapshots of the plot and profile module owners.",
        "- `raw_evidence.tar.gz` contains `evidence/` (raw logs, case reports, matrix, plan and file hashes)",
        "  and `validation/` (original finalizer records, archive recipe and isolated reproduction reviewer).",
        "- `manifest.json` records hashes of every archive payload and readable artifact.",
        "- The adjacent `../implementation_evidence/` package retains implementation checks and failed attempts.", "",
        "## Measured Ratios", "",
        "Each value is median G+R wall divided by median Spine wall. Above one favors Spine; below one favors G+R.",
        "No frequency scaling, timing fit or outlier removal is applied.", "",
        "| Graph | SSSP | CC | ResPR |", "| --- | ---: | ---: | ---: |",
    ]
    for dataset in datasets:
        values = [format(float(by_key[algorithm, dataset]["speedup_gr_over_spine"]), ".3f")
                  for algorithm in ("sssp", "cc", "respr")]
        lines.append("| " + " | ".join([dataset, *values]) + " |")
    lines += ["", "## Timing And Workload Contract", "",
        "Both implementations start from the same converged old-graph state and process the same frozen batch",
        "to the checked new result. There is one excluded warmup and three measured pairs with alternating order.",
        "The interval includes update, correction/propagation, host launch/wait, inter-round relaunch and final readback.",
        "Initial graph/PMA creation, initial residency, old-state preload, batch preparation/upload and CPU oracles",
        "are excluded on both sides. This is resident update-to-result latency, not whole-startup latency.", "",
        "There are eight batch edits: eight directed records for SSSP/ResPR and sixteen reciprocal records for CC.",
        "ResPR uses alpha 0.85 and direct per-vertex epsilon 1e-6, not epsilon divided by V. The frozen PR inputs",
        "are sink-completed transformed workloads. Consult the recorded round counts before claiming propagation.", "",
        "SSSP/CC DATA clocks are 150 MHz on both sides. ResPR G+R uses DATA 149/HBM 432 MHz; Spine uses",
        "DATA 150/HBM 448 MHz after automatic clock scaling. G+R hosts use GCC 15.2 -O2; Spine uses -O3.",
        "The tiny SSSP source-active preparation is outside G+R's interval but inside Spine's device path.", "",
        "## Reproduce Without A Board", "",
        "Extract into a fresh review directory. The bundled modules need no simulator checkout:", "",
        "```bash",
        "tar -xzf /path/to/this-package/raw_evidence.tar.gz -C /path/to/fresh-review",
        "PYTHONPATH=/path/to/this-package/code python3 -m board_review.fpga_plot \\",
        "  --delivery /path/to/fresh-review/evidence --output /path/to/fresh-figure",
        "PYTHONPATH=/path/to/this-package/code python3 -m board_review.fpga_profile \\",
        "  --delivery /path/to/fresh-review/evidence --output /path/to/fresh-profile",
        "```", "",
        "The `board_review` namespace only packages the two original modules; it adds no numerical logic.",
        "Rendering requires Matplotlib and a working LaTeX installation with txfonts. The provenance files pin",
        "the renderer and analyzer. Both commands verify the copied evidence hashes; neither reruns FPGA jobs.",
        "Rechecking original bitstream/input/source pins additionally requires the external paths in the frozen plan",
        "and the integration repository's `validation/cache_extent/delivery.py`. Large binaries and graphs are not in Git.", "",
        "The original raw evidence bytes are unchanged. Event unions are not additive stage times, and resident wall",
        "minus event union is not pure host time. The approximately 2.47x ReGraph publication-scale control gap",
        "remains a disclosed limitation. No paper was changed. See the parent `REPORT.md` for conclusions.", "",
    ]
    return "\n".join(lines)


def package(terminal, output):
    terminal = terminal.resolve(strict=True)
    output = output.resolve()
    if output.exists() or output.is_relative_to(terminal):
        raise ValueError("use a fresh output outside the original delivery")
    state = json.loads((terminal / "state.json").read_text())
    if state["status"] != "TERMINAL_DELIVERY_TOOLS_PASS_NOT_YET_REVIEWED" or \
            state["matrix_status"] != "FPGA_MATRIX_PASS" or state["passed_cases"] != 24 or \
            [(row["name"], row["exit_code"]) for row in state["stages"]] != \
            [("evidence", 0), ("figure", 0), ("profile", 0)]:
        raise ValueError("all 24 cases and all original delivery stages must pass first")
    for path, expected in state["source_pins"].items():
        if digest(Path(path)) != expected:
            raise ValueError("original delivery source pin changed: " + path)
    evidence = terminal / "evidence"
    rows = load_delivery(evidence)
    if len(rows) != 24 or any(row["status"] != "RESIDENT_PAIR_PASS" for row in rows):
        raise ValueError("this release requires 24 measured comparisons, without substitutions")
    profile = json.loads((terminal / "profile/profile.json").read_text())
    if profile != inspect(evidence):
        raise ValueError("saved event diagnostics differ from raw-log recomputation")
    figure = json.loads((terminal / "figure/provenance.json").read_text())
    if figure["passed_cases"] != 24 or figure["missing"] or \
            figure["source_sha256"] != profile["source_sha256"]:
        raise ValueError("figure and profile do not use the same complete evidence")
    selected = [(path, str(path.relative_to(terminal)))
                for path in sorted(evidence.rglob("*")) if path.is_file()]
    selected += [(terminal / name, "validation/" + name) for name in
                 ("state.json", "finalize-terminal-delivery.py", "evidence.log", "figure.log", "profile.log")]
    selected.append((Path(__file__), "validation/package-fpga-delivery.py"))
    selected += [(Path(__file__).with_name(name), "validation/" + name)
                 for name in ("test-fpga-delivery-archive.py", "archive-preflight-final.log",
                              "archive-preflight-final-v2.log",
                              "review-fpga-delivery.py")]
    records = [{"path": name, "source": str(path), "bytes": path.stat().st_size,
                "sha256": digest(path)} for path, name in selected]
    if any(row["bytes"] > 16 * 1024**2 for row in records) or \
            sum(row["bytes"] for row in records) > 256 * 1024**2:
        raise ValueError("portable evidence exceeds its finite size budget")
    output.mkdir(parents=True)
    archive = output / "raw_evidence.tar.gz"
    archive_records(records, archive)
    readable = [(evidence / "summary.csv", Path("summary.csv"))]
    readable += [(Path(module.__file__), Path("code/board_review") / Path(module.__file__).name)
                 for module in (fpga_plot, fpga_profile)]
    readable += [(path, path.relative_to(terminal)) for name in ("figure", "profile")
                 for path in sorted((terminal / name).iterdir()) if path.is_file()]
    copies = []
    for source, relative in readable:
        target = output / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        if digest(source) != digest(target):
            raise ValueError("readable artifact changed while copying")
        copies.append({"path": relative.as_posix(), "sha256": digest(target), "bytes": target.stat().st_size})
    (output / "README.md").write_text(describe(rows))
    manifest = {"schema": "cache_extent_fpga_delivery_archive_v1",
                "status": "24_CASES_ARCHIVED_AND_HASH_VERIFIED_VISUAL_REVIEW_STILL_REQUIRED",
                "source": str(terminal), "passed_cases": 24, "paired_runs": 96,
                "archive": {"path": archive.name, "bytes": archive.stat().st_size, "sha256": digest(archive)},
                "archive_members": records, "readable_artifacts": copies,
                "scope": "actual_resident_FPGA_results_not_new_simulator_timing_calibration"}
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"status": manifest["status"], "archive_members": len(records),
                      "archive_bytes": archive.stat().st_size, "output": str(output)}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--terminal", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    package(args.terminal, args.output)
