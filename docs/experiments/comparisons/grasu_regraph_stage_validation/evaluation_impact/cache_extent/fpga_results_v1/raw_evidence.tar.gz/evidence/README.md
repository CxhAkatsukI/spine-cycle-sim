# Revised G+R Versus Spine: Resident FPGA Results

Status: **FPGA_MATRIX_PASS**, 24/24 correctness-admitted pairs.

These are FPGA wall-time measurements, not simulator predictions. Ratios above one favor Spine.
One warmup pair is excluded; values are the medians of three alternating-order measured pairs.

Both systems start with the same resident converged old graph and apply eight logical updates
until new convergence. Timing includes updates, propagation, host launch/wait, inter-round
relaunch and final readback. Initial graph/PMA creation, initial residency, old-state preload,
batch preparation/upload and CPU oracles are excluded symmetrically. This is not application
setup-inclusive latency. Actual DATA clocks are in the CSV; HBM/system clocks remain in each manifest.

The frozen batch size is eight. CC encodes eight undirected insertions as sixteen reciprocal
directed records; SSSP and ResPR each encode eight directed insertions. Both hosts' raw
`logical_updates` and `physical_updates` fields count input records in this matrix. Those
fields are preserved verbatim, not divided by two. `batch_size` and `input_update_records`
in the CSV distinguish the declared batch size from its encoded record count.

The G+R hosts use GCC 15.2 -O2; Spine uses GCC 15.2 -O3. The earlier approximately 2.47x
ReGraph publication-scale gap remains a limitation, not a successful reproduction claim.
Source changes, HLS export, routed artifacts and FPGA measurement are separate gates.
The bounded-cache simulator component passed regression, but this package does not claim
new full-system simulator timing calibration or promotion of the production SST plugin.

## Propagation Scope

The CSV round-count columns retain all three formal samples, in run order, separated by semicolons.
The excluded warmup remains in each copied raw report. Missing or failed cases have blank counts,
not zero. `no_propagation_rounds` means both systems performed zero propagation rounds in every
formal sample. These are update/correction/completion measurements, not evidence of iterative
propagation performance. `includes_propagation_rounds` means at least one formal sample propagated;
the individual counts, rather than that label alone, determine the workload's propagation coverage.

ResPR uses the correctness-checked direct per-vertex epsilon of 1e-6, not epsilon divided by V.
Zero-round cases are retained as measured; neither the threshold nor batch was changed to force work.

| ResPR dataset | G+R formal rounds | Spine formal rounds | Scope or status |
| --- | --- | --- | --- |
| AU | 0;0;0 | 0;0;0 | no_propagation_rounds |
| SU | 0;0;0 | 0;0;0 | no_propagation_rounds |
| WK | 0;0;0 | 0;0;0 | no_propagation_rounds |
| SO | 0;0;0 | 0;0;0 | no_propagation_rounds |
| PK | 0;0;0 | 0;0;0 | no_propagation_rounds |
| LJ | 0;0;0 | 0;0;0 | no_propagation_rounds |
| LJ08 | 0;0;0 | 0;0;0 | no_propagation_rounds |
| R19 | 0;0;0 | 0;0;0 | no_propagation_rounds |

## Results

| Algorithm | Dataset | Status | G+R ms | Spine ms | G+R / Spine |
| --- | --- | --- | ---: | ---: | ---: |
| sssp | AU | RESIDENT_PAIR_PASS | 18.5194 | 4.30279 | 4.30404 |
| sssp | SU | RESIDENT_PAIR_PASS | 27.6834 | 4.33528 | 6.38562 |
| sssp | WK | RESIDENT_PAIR_PASS | 27.489 | 4.52501 | 6.07491 |
| sssp | SO | RESIDENT_PAIR_PASS | 751.955 | 18.0336 | 41.6975 |
| sssp | PK | RESIDENT_PAIR_PASS | 617.563 | 8.19789 | 75.3319 |
| sssp | LJ | RESIDENT_PAIR_PASS | 2891.51 | 32.4276 | 89.1682 |
| sssp | LJ08 | RESIDENT_PAIR_PASS | 1851.97 | 20.4468 | 90.575 |
| sssp | R19 | RESIDENT_PAIR_PASS | 78.4117 | 4.04465 | 19.3865 |
| cc | AU | RESIDENT_PAIR_PASS | 11.8733 | 82.3447 | 0.14419 |
| cc | SU | RESIDENT_PAIR_PASS | 15.155 | 81.7356 | 0.185415 |
| cc | WK | RESIDENT_PAIR_PASS | 75.3552 | 132.312 | 0.569526 |
| cc | SO | RESIDENT_PAIR_PASS | 823.085 | 112.63 | 7.30787 |
| cc | PK | RESIDENT_PAIR_PASS | 305.14 | 89.5507 | 3.40746 |
| cc | LJ | RESIDENT_PAIR_PASS | 960.585 | 95.9961 | 10.0065 |
| cc | LJ08 | RESIDENT_PAIR_PASS | 923.045 | 100.254 | 9.20706 |
| cc | R19 | RESIDENT_PAIR_PASS | 91.5924 | 109.287 | 0.83809 |
| respr | AU | RESIDENT_PAIR_PASS | 21.4074 | 53.8355 | 0.397645 |
| respr | SU | RESIDENT_PAIR_PASS | 27.2422 | 52.6526 | 0.517395 |
| respr | WK | RESIDENT_PAIR_PASS | 52.6606 | 64.2815 | 0.819219 |
| respr | SO | RESIDENT_PAIR_PASS | 867.179 | 193.487 | 4.48185 |
| respr | PK | RESIDENT_PAIR_PASS | 332.676 | 154.473 | 2.15362 |
| respr | LJ | RESIDENT_PAIR_PASS | 1020.83 | 256.296 | 3.98302 |
| respr | LJ08 | RESIDENT_PAIR_PASS | 984.922 | 279.133 | 3.5285 |
| respr | R19 | RESIDENT_PAIR_PASS | 44.8685 | 86.63 | 0.517933 |

## Evidence

`summary.csv` retains every declared case, including failures.
`cases/` contains copied board reports, manifests and raw paired logs; `files.json` records hashes
and original locations. The frozen plan and case manifests identify hosts, bitstreams, workloads
and source pins. Large binaries, graphs and compiler trees stay at those indexed locations.
Passing rows were rechecked against raw logs, binary/source hashes and recomputed medians.
Their saved cgroup limits match the frozen per-dataset budgets, enforce zero swap and group
OOM termination, and agree with the recorded admission and per-process memory policies.
Post-run OOM counters must be present and zero. Pressure counters (`high`/`max`) remain in
the copied reports; nonzero pressure alone is not treated as an OOM or hidden from review.
Incomplete rows are not speedups and may require another build or run. No paper was modified.
