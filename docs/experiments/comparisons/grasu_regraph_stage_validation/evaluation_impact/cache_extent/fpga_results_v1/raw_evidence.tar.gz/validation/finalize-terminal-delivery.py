"""Wait for the frozen board matrix, then run existing read-only delivery CLIs."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time


ROOT = Path('/data/chuxiao/builds/grasu-cache-extent-20261025')
OUTPUT = ROOT / 'terminal-delivery-v1'
SIM = Path('/home/chuxiao/spine-cycle-sim/spine-cycle-sim-sharded-k4-v3')
REVIEW = Path('/home/chuxiao/grasu-regraph-delivery-review')
RUNTIME = Path('/home/chuxiao/spine-cycle-sim/spine-cycle-sim-production-board')
PYTHON = '/data/tmp/chuxiao/spine-cycle-sim-eval-venv/bin/python'
UNIT = 'gr-cache-extent-matrix-zfs-20261025-v3.service'
MATRIX = ROOT / 'matrix-zfs-v3/results.json'
PINS = {
    ROOT / 'matrix-inputs-zfs-v3/plan.json': 'dcfa6e48f3db23f7ab6c213207c8f4a733093a1d8dd082ab055cc19bf5e57a92',
    REVIEW / 'validation/cache_extent/delivery.py': 'd9139af14ec591d32ed5eb0524de066b2f7dc7686e8d8997a4f3f4ff463a5dad',
    SIM / 'spine_cycle_sim/experiments/evaluation_impact/fpga_plot.py': '4583f2f1d89458d3747263c81a2cbb4f7b9f937346948669cde55580f6936341',
    SIM / 'spine_cycle_sim/experiments/evaluation_impact/fpga_profile.py': '2414d13e2eedf880d655a049f07cae4b5e2e5d8b35a326fcf8da84f5568847c2',
}


def check_pins():
    for path, expected in PINS.items():
        with path.open('rb') as stream:
            actual = hashlib.file_digest(stream, 'sha256').hexdigest()
        if actual != expected:
            raise ValueError('changed delivery input: ' + str(path))


def save(state):
    temporary = OUTPUT / 'state.json.tmp'
    temporary.write_text(json.dumps(state, indent=2, allow_nan=False) + '\n')
    temporary.replace(OUTPUT / 'state.json')


def main():
    OUTPUT.mkdir(exist_ok=False)
    shutil.copyfile(__file__, OUTPUT / 'finalize-terminal-delivery.py')
    state = {'status': 'WAITING_FOR_TERMINAL_MATRIX', 'matrix': str(MATRIX),
             'source_pins': {str(path): digest for path, digest in PINS.items()},
             'scope': 'read_only_packaging_not_board_rerun_or_goal_completion', 'stages': []}
    save(state)
    try:
        deadline = time.monotonic() + 6 * 3600
        while True:
            check_pins()
            matrix = json.loads(MATRIX.read_text())
            if matrix['status'] in ('FPGA_MATRIX_PASS', 'FPGA_MATRIX_INCOMPLETE_RETAINED'):
                break
            live = subprocess.run(['systemctl', '--user', 'show', UNIT, '-p', 'ActiveState',
                                   '--value'], capture_output=True, text=True, check=True, timeout=10)
            if live.stdout.strip() != 'active':
                raise RuntimeError('matrix supervisor is not live and has no terminal report')
            if time.monotonic() >= deadline:
                raise TimeoutError('six-hour delivery observation limit; do not restart board jobs')
            state['observed_passed_cases'] = matrix['passed_cases']
            state['observed_at_unix'] = time.time()
            save(state)
            time.sleep(20)
        state.update(status='PACKAGING_TERMINAL_MATRIX', matrix_status=matrix['status'],
                     passed_cases=matrix['passed_cases'])
        save(state)
        stages = [
            ('evidence', REVIEW, RUNTIME, 'validation.cache_extent.delivery',
             ['--matrix', str(MATRIX), '--output', str(OUTPUT / 'evidence')]),
            ('figure', SIM, SIM, 'spine_cycle_sim.experiments.evaluation_impact.fpga_plot',
             ['--delivery', str(OUTPUT / 'evidence'), '--output', str(OUTPUT / 'figure')]),
            ('profile', SIM, SIM, 'spine_cycle_sim.experiments.evaluation_impact.fpga_profile',
             ['--delivery', str(OUTPUT / 'evidence'), '--output', str(OUTPUT / 'profile')]),
        ]
        for name, cwd, pythonpath, module, arguments in stages:
            check_pins()
            command = [PYTHON, '-m', module, *arguments]
            environment = os.environ.copy()
            environment['PYTHONPATH'] = str(pythonpath)
            started = time.monotonic()
            with (OUTPUT / (name + '.log')).open('w') as log:
                process = subprocess.run(command, cwd=cwd, env=environment, stdout=log,
                                         stderr=subprocess.STDOUT, timeout=600)
            state['stages'].append({'name': name, 'command': command, 'cwd': str(cwd),
                                    'exit_code': process.returncode,
                                    'wall_seconds': time.monotonic() - started})
            save(state)
            if process.returncode:
                raise RuntimeError('delivery stage failed: ' + name)
            check_pins()
        state['status'] = 'TERMINAL_DELIVERY_TOOLS_PASS_NOT_YET_REVIEWED'
        save(state)
    except Exception as error:
        state.update(status='FAILED_RETAINED', error=repr(error))
        save(state)
        raise


if __name__ == '__main__':
    main()
