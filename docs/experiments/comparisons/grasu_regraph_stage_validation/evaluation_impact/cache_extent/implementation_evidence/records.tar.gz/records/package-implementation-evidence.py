#!/usr/bin/env python3
"""Copy completed supporting records without touching live FPGA experiments."""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def package(root, output):
    root = root.resolve(strict=True)
    output = output.resolve()
    if output.exists():
        raise ValueError("output must be fresh")
    selected = {}

    def include(path, role):
        if path.is_symlink():
            raise ValueError(f"refusing a symlink: {path}")
        path = path.resolve(strict=True)
        relative = path.relative_to(root)
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"not a regular source file: {path}")
        size = path.stat().st_size
        if size > 16 * 1024 * 1024:
            raise ValueError(f"unexpectedly large supporting record: {path}")
        record = {"source": str(path), "path": str(relative),
                  "bytes": size, "sha256": digest(path), "role": role}
        if path.name == "results.json":
            data = json.loads(path.read_text())
            record["recorded_status"] = data.get("status")
        selected[str(relative)] = record

    # Earlier matrix observers stopped with WAITING snapshots; preserve that text.
    # The active matrix-zfs-v3 and finalizer are deliberately outside this list.
    for prefix in ("source-", "hls-", "route-", "spine-respr-", "matrix-v"):
        for folder in sorted(root.glob(prefix + "*")):
            if not folder.is_dir():
                continue
            reports = [folder / "results.json"]
            if prefix == "route-":
                reports += [folder / name / "results.json"
                            for name in ("sssp", "cc", "respr")]
            for path in reports:
                if path.is_file():
                    data = json.loads(path.read_text())
                    status = data.get("status", "")
                    historical_wait = (prefix == "matrix-v"
                                       and folder.name in ("matrix-v1", "matrix-v2", "matrix-v3", "matrix-v4")
                                       and status == "WAITING_FOR_REMAINING_HARDWARE")
                    if status.startswith(("RUNNING", "QUEUED", "WAITING")) and not historical_wait:
                        raise ValueError(f"refusing a nonterminal record: {path}")
                    role = ("superseded_observer_snapshot_not_current_matrix_status"
                            if historical_wait else "terminal_stage_record_including_failed_attempts")
                    include(path, role)

    for name in ("source-zfs-v3", "hls-zfs-v3"):
        for path in sorted((root / name / "raw").iterdir()):
            if path.is_file():
                include(path, "source_or_hls_raw_log_and_resource_record")
    for name in ("cache-plain-bounded", "cache-token-bounded"):
        base = root / "hls-zfs-v3" / name / "project"
        for suffix in ("kernel.xml", "solution/syn/report/csynth.xml"):
            include(base / suffix, "exported_interface_or_hls_synthesis_report")
    for algorithm in ("sssp", "cc", "respr"):
        folder = root / "route-zfs-v2" / algorithm
        for name in ("manifest.json", "master-budget.json", "link.cfg"):
            include(folder / name, "routed_input_and_resource_contract")
        for path in sorted(folder.glob("*.xclbin.info")):
            include(path, "routed_artifact_metadata")
        for path in sorted((folder / "raw").iterdir()):
            if path.is_file():
                include(path, "route_raw_log_and_resource_record")
    for relative in (
        "respr-artifact-audit-v1/results.json",
        "spine-respr-zfs-audit-v1/clocks.json",
        "spine-respr-zfs-audit-v1/embedded-metadata.xml",
        "sim-sharded-v1/regression.xml",
        "sim-sharded-v1/Testing/Temporary/LastTest.log",
        "sim-sharded-v1/ctest.log",
        "sim-sharded-v1/source-review.patch",
        "sst-bounded-verification-v2/stderr.log",
        "terminal-tool-preflight-v2/results.json",
        "terminal-tool-preflight-v2/delivery.log",
        "terminal-tool-preflight-v2/plot.log",
        "terminal-tool-preflight-v2/profile.log",
    ):
        include(root / relative, "functional_regression_or_independent_artifact_audit")
    include(Path(__file__), "supporting_record_copy_recipe_not_experiment_runner")

    total = sum(row["bytes"] for row in selected.values())
    if total > 64 * 1024 * 1024:
        raise ValueError("supporting evidence exceeds the 64-MiB portable budget")
    tests = ET.parse(root / "sim-sharded-v1/regression.xml").getroot()
    cases = list(tests.iter("testcase"))
    failed = [case.attrib.get("name") for case in cases
              if case.find("failure") is not None or case.find("error") is not None
              or case.find("skipped") is not None]
    if len(cases) != 31 or failed:
        raise ValueError(f"core regression is not 31 passing tests: {failed}")

    output.mkdir(parents=True)
    for record in selected.values():
        destination = output / "records" / record["path"]
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(record["source"], destination)
        if digest(destination) != record["sha256"]:
            raise ValueError(f"copy hash mismatch: {destination}")
        if digest(Path(record["source"])) != record["sha256"]:
            raise ValueError(f"source changed during packaging: {record['source']}")
    manifest = {
        "schema": "cache_extent_implementation_evidence_v1",
        "status": "COPIED_AND_HASH_VERIFIED_NOT_TIMING_CALIBRATION",
        "scope": "supporting_records_not_terminal_board_matrix_or_publication_match",
        "root": str(root), "bytes": total, "file_count": len(selected),
        "core_tests_passed": len(cases),
        "large_artifacts": "External paths and hashes remain in original stage records; no bitstream or build tree is copied.",
        "files": list(selected.values()),
    }
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({key: manifest[key] for key in
                      ("status", "bytes", "file_count", "core_tests_passed")}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    package(args.root, args.output)
